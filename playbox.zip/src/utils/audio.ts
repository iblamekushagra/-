/**
 * Web Audio API Retro synthesizer for PlayBox
 * High-fidelity, self-contained chiptune audio and music engine!
 */

class PlayBoxAudioEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private bgmInterval: NodeJS.Timeout | null = null;
  private step: number = 0;
  private activeBgmId: string | null = null;
  private compressor: DynamicsCompressorNode | null = null;

  constructor() {
    // Lazy initialize to bypass browser autoplay policies
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
        // Create master compressor
        this.compressor = this.ctx.createDynamicsCompressor();
        this.compressor.threshold.setValueAtTime(-12, this.ctx.currentTime);
        this.compressor.knee.setValueAtTime(30, this.ctx.currentTime);
        this.compressor.ratio.setValueAtTime(12, this.ctx.currentTime);
        this.compressor.attack.setValueAtTime(0.003, this.ctx.currentTime);
        this.compressor.release.setValueAtTime(0.08, this.ctx.currentTime);
        this.compressor.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setMute(mute: boolean) {
    this.isMuted = mute;
    if (mute) {
      this.stopBGM();
    } else {
      this.initCtx();
    }
  }

  public toggleMute() {
    const nextState = !this.isMuted;
    this.setMute(nextState);
    return nextState;
  }

  public getMute() {
    return this.isMuted;
  }

  // --- Retro Sound Triggers ---

  /**
   * Sound of a cute, friendly sport whistle / musical starting flute (soft and pleasant)
   */
  public playWhistle() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.compressor) return;

    try {
      const now = this.ctx.currentTime;
      
      // Gentle flute harmony (two sine waves spaced perfectly)
      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gainNode = this.ctx.createGain();

      osc1.type = 'sine';
      osc2.type = 'sine';

      // Harmonious, soft frequencies (perfect major third: 880Hz and 1100Hz)
      osc1.frequency.setValueAtTime(880, now);
      osc2.frequency.setValueAtTime(1100, now);

      // Soft vibrato
      const lfo = this.ctx.createOscillator();
      const lfoGain = this.ctx.createGain();
      lfo.frequency.value = 8; // gently vibrate
      lfoGain.gain.value = 10;
      lfo.connect(lfoGain);
      lfoGain.connect(osc1.frequency);
      lfoGain.connect(osc2.frequency);

      // Smooth attack and pleasant envelope decay (no sudden pop)
      gainNode.gain.setValueAtTime(0, now);
      gainNode.gain.linearRampToValueAtTime(0.2, now + 0.05);
      gainNode.gain.setValueAtTime(0.2, now + 0.15);
      gainNode.gain.linearRampToValueAtTime(0.01, now + 0.22);
      
      gainNode.gain.linearRampToValueAtTime(0.25, now + 0.26);
      gainNode.gain.setValueAtTime(0.25, now + 0.38);
      gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

      osc1.connect(gainNode);
      osc2.connect(gainNode);
      gainNode.connect(this.compressor);

      lfo.start(now);
      osc1.start(now);
      osc2.start(now);

      lfo.stop(now + 0.55);
      osc1.stop(now + 0.55);
      osc2.stop(now + 0.55);
    } catch (e) {
      console.warn("Audio Context Whistle play issue: ", e);
    }
  }

  /**
   * Smooth, round bubble jump or ping
   */
  public playJump() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.compressor) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(330, now);
      osc.frequency.exponentialRampToValueAtTime(660, now + 0.15);

      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);

      osc.connect(gain);
      gain.connect(this.compressor);

      osc.start(now);
      osc.stop(now + 0.18);
    } catch (e) {}
  }

  /**
   * Soft wooden woodblock tap (card flipping sound)
   */
  public playFlip() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.compressor) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.linearRampToValueAtTime(220, now + 0.05);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

      osc.connect(gain);
      gain.connect(this.compressor);

      osc.start(now);
      osc.stop(now + 0.06);
    } catch (e) {}
  }

  /**
   * Deep, pillow-soft bass thump explosion
   */
  public playExplosion() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.compressor) return;

    try {
      const now = this.ctx.currentTime;
      
      // Extremely warm low-pass filtered noise
      const bufferSize = this.ctx.sampleRate * 0.45;
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const noiseSource = this.ctx.createBufferSource();
      noiseSource.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(280, now);
      filter.frequency.exponentialRampToValueAtTime(10, now + 0.4);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.42);

      noiseSource.connect(filter);
      filter.connect(gain);
      gain.connect(this.compressor);

      // Deep, comforting warm sub sine wave instead of sawtooth
      const subOsc = this.ctx.createOscillator();
      const subGain = this.ctx.createGain();
      subOsc.type = 'sine';
      subOsc.frequency.setValueAtTime(90, now);
      subOsc.frequency.linearRampToValueAtTime(30, now + 0.35);
      subGain.gain.setValueAtTime(0.25, now);
      subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

      subOsc.connect(subGain);
      subGain.connect(this.compressor);

      noiseSource.start(now);
      subOsc.start(now);
      noiseSource.stop(now + 0.45);
      subOsc.stop(now + 0.45);
    } catch (e) {}
  }

  /**
   * Dreamy, sweet crystal arpeggio major chime
   */
  public playSuccess() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.compressor) return;

    try {
      const now = this.ctx.currentTime;
      // C Major 9 chord arpeggio: C5 (523Hz), E5 (659Hz), G5 (784Hz), B5 (987Hz), D6 (1174Hz)
      const notes = [523.25, 659.25, 783.99, 987.77, 1174.66];
      notes.forEach((freq, index) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;
        
        const noteStart = now + index * 0.05;
        gain.gain.setValueAtTime(0, now);
        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.08, noteStart + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + 0.3);

        osc.connect(gain);
        gain.connect(this.compressor!);
        osc.start(noteStart);
        osc.stop(noteStart + 0.35);
      });
    } catch (e) {}
  }

  /**
   * Smooth, gentle jazzy descending sad phrase (mellower and comforting)
   */
  public playFail() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.compressor) return;

    try {
      const now = this.ctx.currentTime;
      // Soft minor-seventh fall
      const notes = [392.00, 349.23, 293.66, 220.00]; 
      notes.forEach((freq, index) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;

        const noteStart = now + index * 0.12;
        gain.gain.setValueAtTime(0, now);
        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.08, noteStart + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + 0.35);

        osc.connect(gain);
        gain.connect(this.compressor!);
        osc.start(noteStart);
        osc.stop(noteStart + 0.50);
      });
    } catch (e) {}
  }

  /**
   * Bubbly water drop plop sound (replaces harsh splat)
   */
  public playSplat() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.compressor) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(220, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.1);

      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

      osc.connect(gain);
      gain.connect(this.compressor);

      osc.start(now);
      osc.stop(now + 0.15);
    } catch (e) {}
  }

  /**
   * Soft, light double-clap or soft woodblock pop (replaces slaps/punches)
   */
  public playSlap() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.compressor) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(560, now);
      osc.frequency.exponentialRampToValueAtTime(140, now + 0.06);

      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.05);

      osc.connect(gain);
      gain.connect(this.compressor);

      osc.start(now);
      osc.stop(now + 0.08);
    } catch (e) {}
  }

  // --- Music Loops / Background Chiptune Generator ---

  /**
   * Select and run background synthesizer rhythm loops
   */
  public startBGM(id: string) {
    if (this.isMuted) return;
    this.initCtx();
    
    // Stop any existing BGM loop
    this.stopBGM();
    this.activeBgmId = id;
    this.step = 0;

    // Define simple notes for retro chords
    // Funny, fast tempos for specific mini-games!
    let tempo = 120; // BPM
    let scale = [261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88]; // C root Major Scale

    switch(id) {
      case 'home':
        tempo = 90; // relaxing, comforting, warm tempo
        scale = [261.63, 293.66, 329.63, 392.00, 440.00, 523.25]; // C Major Pentatonic (highly pleasant and cheerful)
        break;
      case 'memory':
        tempo = 115; // light mystery bouncing chord
        scale = [220.00, 261.63, 293.66, 329.63, 392.00]; // A Minor Pentatonic
        break;
      case 'chicken_jump':
        tempo = 150; // fast-paced stress chiptune
        scale = [261.63, 277.18, 311.13, 349.23, 392.00]; // Phrygian stress
        break;
      case 'sashimi':
        tempo = 165; // ticking panic hot potato music!
        scale = [261.63, 293.66, 311.13, 392.00, 415.30]; // tense scale
        break;
      case 'chili':
        tempo = 140; // bouncy retro feast
        scale = [196.00, 246.94, 293.66, 349.23, 392.00]; // G Major / Dom7 Bouncy
        break;
      default:
        tempo = 130;
        break;
    }

    const intervalTime = (60 / tempo) * 250; // sixteenth or eighth notes spacing (millisecond conversion)

    const scheduleNextStep = () => {
      if (this.isMuted || !this.ctx || !this.compressor || this.activeBgmId !== id) {
        return;
      }

      try {
        const now = this.ctx.currentTime;
        const noteIndex = this.step % 8;

        // BASSLINE (Beat 1, 3, 5, 7)
        if (noteIndex % 2 === 0) {
          const bassOsc = this.ctx.createOscillator();
          const bassGain = this.ctx.createGain();
          bassOsc.type = 'triangle';
          
          // Simple walking bassline based on step scale
          const bassRoot = scale[Math.floor((this.step / 8) % 3)];
          bassOsc.frequency.setValueAtTime(bassRoot / 2, now); // drop one octave

          bassGain.gain.setValueAtTime(0.08, now);
          bassGain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

          bassOsc.connect(bassGain);
          bassGain.connect(this.compressor);
          bassOsc.start(now);
          bassOsc.stop(now + 0.2);
        }

        // MELODY ARPEGGIATOR
        const melodyPattern = [0, 2, 4, 3, 2, 5, 4, 6];
        const doMelody = (this.step % 4 === 0) || (noteIndex === 5 || noteIndex === 7);
        if (doMelody && id !== 'sashimi') {
          const mOsc = this.ctx.createOscillator();
          const mGain = this.ctx.createGain();
          
          mOsc.type = 'sine';
          const frequency = scale[melodyPattern[noteIndex] % scale.length];
          mOsc.frequency.setValueAtTime(frequency, now);

          mGain.gain.setValueAtTime(0.04, now);
          mGain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

          mOsc.connect(mGain);
          mGain.connect(this.compressor);
          mOsc.start(now);
          mOsc.stop(now + 0.17);
        }

        // CHIP CHEEZ DRUM NOISE (simulated high-hat) on off-beats (step 2, 4, 6, 8)
        if (noteIndex % 2 === 1) {
          const snareOsc = this.ctx.createOscillator();
          const snareGain = this.ctx.createGain();
          snareOsc.type = 'triangle';
          snareOsc.frequency.setValueAtTime(Math.random() * 600 + 400, now);

          snareGain.gain.setValueAtTime(0.02, now);
          snareGain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

          snareOsc.connect(snareGain);
          snareGain.connect(this.compressor);
          snareOsc.start(now);
          snareOsc.stop(now + 0.06);
        }

        this.step++;
      } catch (err) {
        console.warn("BGM Engine schedule error: ", err);
      }

      this.bgmInterval = setTimeout(scheduleNextStep, intervalTime);
    };

    scheduleNextStep();
  }

  public stopBGM() {
    if (this.bgmInterval) {
      clearTimeout(this.bgmInterval);
      this.bgmInterval = null;
    }
    this.activeBgmId = null;
  }
}

export const playBoxAudio = new PlayBoxAudioEngine();
export default playBoxAudio;
