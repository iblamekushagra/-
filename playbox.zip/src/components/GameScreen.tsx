import React, { useState, useEffect, useRef } from 'react';
import { Player, Minigame, GameSettings } from '../types';
import playBoxAudio from '../utils/audio';
import { renderAvatarSvg } from './AvatarCustomizer';
import { 
  WobblyTowerGame, 
  WackyMathGame, 
  LaserDodgeGame, 
  SushiTrainGame, 
  RocketDriftGame, 
  AlienInvaderGame, 
  BurgerStackGame, 
  BalloonPopGame, 
  FruitSlashGame, 
  SimonGlowGame 
} from './NewMinigames';

interface GameScreenProps {
  players: Player[];
  settings: GameSettings;
  activeGame: Minigame;
  onExit: () => void;
  onGameOver: (winnerId: number, earnedCoins: number) => void;
  onUnlockMilestone: (awardId: string) => void;
}

export default function GameScreen({
  players,
  settings,
  activeGame,
  onExit,
  onGameOver,
  onUnlockMilestone,
}: GameScreenProps) {
  // Initialize general scoring & game progression
  const [scores, setScores] = useState<Record<number, number>>(() => {
    const s: Record<number, number> = {};
    players.forEach(p => s[p.id] = 0);
    return s;
  });

  const [gameEnded, setGameEnded] = useState(false);
  const [winnerName, setWinnerName] = useState('');
  const [gameStarted, setGameStarted] = useState(false);
  const [countdown, setCountdown] = useState(3);

  // FPS tracking state
  const [fps, setFps] = useState(0);
  const frameCountRef = useRef(0);
  const lastTimeRef = useRef(performance.now());
  const animationRef = useRef<number | null>(null);

  // Play music when a minigame is selected & mounted
  useEffect(() => {
    if (settings.soundEnabled) {
      playBoxAudio.startBGM(activeGame.id);
    }
    return () => {
      playBoxAudio.stopBGM();
    };
  }, [activeGame.id, settings.soundEnabled]);

  // Handle countdown setup
  useEffect(() => {
    if (!gameStarted && countdown > 0) {
      const t = setTimeout(() => {
        setCountdown(prev => prev - 1);
      }, 1000);
      return () => clearTimeout(t);
    } else if (countdown === 0 && !gameStarted) {
      setGameStarted(true);
      playBoxAudio.playWhistle();
    }
  }, [countdown, gameStarted]);

  // FPS implementation hook utilizing requestAnimationFrame
  useEffect(() => {
    let lastFrameTime = performance.now();
    const targetFps = settings.fpsCap === 'unlimited' ? 9999 : settings.fpsCap;
    const frameInterval = 1000 / targetFps;

    const tick = (now: number) => {
      const elapsed = now - lastFrameTime;

      if (elapsed >= frameInterval) {
        lastFrameTime = now - (elapsed % frameInterval);

        // Calculate actual FPS count
        frameCountRef.current++;
        if (now > lastTimeRef.current + 1000) {
          setFps(Math.round((frameCountRef.current * 1000) / (now - lastTimeRef.current)));
          frameCountRef.current = 0;
          lastTimeRef.current = now;
        }
      }

      animationRef.current = requestAnimationFrame(tick);
    };

    animationRef.current = requestAnimationFrame(tick);
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [settings.fpsCap]);

  // Resolve winner selection
  const declareWinner = (winnerId: number) => {
    setGameEnded(true);
    const winnerPlayer = players.find(p => p.id === winnerId);
    if (winnerPlayer) {
      setWinnerName(winnerPlayer.name);
      onGameOver(winnerId, 15); // Hand over 15 precious coins for winning!
    } else {
      setWinnerName('All Toys!');
      onGameOver(999, 5); // Consolation points
    }
    playBoxAudio.playSuccess();
  };

  // Resolution visual modifier class
  const getResolutionClass = () => {
    switch (settings.resolutionScale) {
      case 'low': return 'filter blur-[1.5px] contrast-[1.25] image-render-pixelated scale-95';
      case 'medium': return '';
      case 'high': return 'shadow-[0_0_15px_rgba(255,215,0,0.15)] ring-2 ring-primary/10 scale-100';
    }
  };

  return (
    <div className="w-full h-full flex flex-col gap-6" id="game-arena">
      {/* Top Console Bar */}
      <div className="flex justify-between items-center bg-surface-container px-4 py-2 rounded-xl border-4 border-surface-variant shadow-sm bubbly-card">
        <div className="flex items-center gap-3">
          <button 
            onClick={onExit}
            className="px-3 py-1 bg-red-500 text-white rounded-lg text-xs font-bold border-b-2 border-red-700 hover:scale-105 active:translate-y-0.5"
            id="exit-game-arena-btn"
          >
            ← Exit PlayBox
          </button>
          <span className="font-sans font-bold text-sm text-on-surface flex items-center gap-1 bg-white px-2 py-0.5 rounded border">
            {activeGame.emoji} {activeGame.name}
          </span>
        </div>

        {/* Console Stats */}
        <div className="flex items-center gap-4 text-xs font-mono text-gray-700">
          <span className="bg-primary-container px-2 py-0.5 rounded text-on-primary-container font-bold flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-ping" />
            {fps} FPS
          </span>
          <span className="capitalize font-bold bg-white px-2 py-0.5 rounded border border-gray-300">
            Res: {settings.resolutionScale}
          </span>
        </div>
      </div>

      {/* Main Container Stage */}
      <div className={`relative flex-grow min-h-[500px] w-full bg-inverse-surface text-white rounded-2xl border-4 border-surface-container-highest flex flex-col justify-center items-center overflow-hidden transition-all duration-300 ${getResolutionClass()}`}>
        
        {/* Intro Countdown Banner */}
        {!gameStarted && !gameEnded && (
          <div className="absolute inset-0 z-40 bg-black/90 flex flex-col justify-center items-center gap-4">
            <h2 className="font-display-lg text-6xl text-primary-container tracking-wider animate-bounce">
              {countdown > 0 ? countdown : 'GET READY!'}
            </h2>
            <p className="text-sm font-sans italic text-white/80 uppercase tracking-widest">
              Prepare your thumbs!
            </p>
            {/* Short dynamic description cards */}
            <div className="bg-white/10 p-5 rounded-xl border border-white/20 text-center max-w-sm">
              <span className="text-4xl">{activeGame.emoji}</span>
              <h4 className="font-sans font-bold text-lg text-yellow-300 mt-2">{activeGame.name}</h4>
              <p className="text-xs font-sans text-white/90 leading-relaxed mt-1">{activeGame.desc}</p>
            </div>
          </div>
        )}

        {/* Global Game Win Slate overlay */}
        {gameEnded && (
          <div className="absolute inset-0 z-40 bg-black/85 flex flex-col justify-center items-center gap-6 p-6 animate-fade-in text-center">
            <div className="w-24 h-24 bg-primary-container rounded-full flex items-center justify-center p-2 border-4 border-white animate-bounce">
              <span className="text-5xl">🏆</span>
            </div>
            <div className="flex flex-col gap-1 items-center">
              <h2 className="font-display-lg text-4xl text-yellow-300 uppercase tracking-tight">
                {winnerName} wins the match!
              </h2>
              <p className="text-sm text-white/80 font-sans italic">
                Awesome match! Got 15 premium shop coins!
              </p>
            </div>
            <button
              onClick={onExit}
              className="bg-primary text-on-primary font-display-lg text-xl tracking-widest px-10 py-4 rounded-full border-b-4 border-yellow-600 play-button"
              id="game-over-done-btn"
            >
              MIGHTY HOME!
            </button>
          </div>
        )}

        {/* Rendering Minigames Router based on selected ID */}
        {gameStarted && (
          <div className="w-full h-full flex flex-col relative" id="active-minigame-container">
            {activeGame.id === 'memory' && (
              <MemoryGame players={players} scores={scores} onScore={setScores} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'chicken_jump' && (
              <ChickenJump players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'sashimi' && (
              <SashimiGame players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'cooper_kick' && (
              <SoccerPool players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'chili_chomp' && (
              <ChiliChomp players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'flappy' && (
              <FlappyBalloon players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'spike' && (
              <SpikeSqueeze players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'dino' && (
              <DinoReact players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'poop' && (
              <WhackAPoop players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'sumo' && (
              <SumoSlap players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'tower' && (
              <WobblyTowerGame players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'math' && (
              <WackyMathGame players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'laser' && (
              <LaserDodgeGame players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'train' && (
              <SushiTrainGame players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'space' && (
              <RocketDriftGame players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'zap' && (
              <AlienInvaderGame players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'burger' && (
              <BurgerStackGame players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'pop' && (
              <BalloonPopGame players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'slash' && (
              <FruitSlashGame players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
            {activeGame.id === 'simon' && (
              <SimonGlowGame players={players} onWin={declareWinner} onUnlock={onUnlockMilestone} />
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ==========================================
// 1. MINIGAME: CRAZY MEMORY CARDS
// ==========================================
interface MemoryComponentProps {
  players: Player[];
  scores: Record<number, number>;
  onScore: React.Dispatch<React.SetStateAction<Record<number, number>>>;
  onWin: (winnerId: number) => void;
  onUnlock: (awardId: string) => void;
}

const CARDS_DECK = [
  { face: '💩', label: 'poop' },
  { face: '🌈', label: 'rainbow' },
  { face: '🐥', label: 'chick' },
  { face: '👽', label: 'alien' },
  { face: '🌶️', label: 'chili' },
  { face: '🧀', label: 'cheese' },
  { face: '🐱', label: 'cat' },
  { face: '🍌', label: 'banana' },
];

function MemoryGame({ players, scores, onScore, onWin, onUnlock }: MemoryComponentProps) {
  const [deck, setDeck] = useState<{ id: number; icon: string; matched: boolean; flipped: boolean }[]>([]);
  const [currentPlayerIdx, setCurrentPlayerIdx] = useState(0);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [lastTurnAnnouncement, setLastTurnAnnouncement] = useState('');
  const [flipLock, setFlipLock] = useState(false);

  const activePlayer = players[currentPlayerIdx];

  // Initialize randomized memory deck
  useEffect(() => {
    const shuffleDeck = [...CARDS_DECK, ...CARDS_DECK]
      .map((item, idx) => ({ id: idx, icon: item.face, matched: false, flipped: false }))
      .sort(() => Math.random() - 0.5);
    setDeck(shuffleDeck);
    
    // Announce red starts
    const colorLabel = activePlayer.color.includes('a04100') ? 'ORANGE' : activePlayer.id === 1 ? 'BLUE' : 'RED';
    setLastTurnAnnouncement(`${activePlayer.name.toUpperCase()} STARTS!`);
    playBoxAudio.playWhistle();

    setTimeout(() => {
      setLastTurnAnnouncement('');
    }, 2000);
  }, []);

  const handleFlipCard = (index: number) => {
    if (flipLock || deck[index].matched || deck[index].flipped || flippedIndices.includes(index)) return;

    playBoxAudio.playFlip();

    const nextDeck = [...deck];
    nextDeck[index].flipped = true;
    setDeck(nextDeck);

    const nextFlipped = [...flippedIndices, index];
    setFlippedIndices(nextFlipped);

    // Evaluate matching when two cards are flipped
    if (nextFlipped.length === 2) {
      setFlipLock(true);
      const [first, second] = nextFlipped;

      if (deck[first].icon === deck[second].icon) {
        // Pairs matched!
        setTimeout(() => {
          const matchedDeck = nextDeck.map((card, i) => {
            if (i === first || i === second) {
              return { ...card, matched: true, flipped: false };
            }
            return card;
          });
          setDeck(matchedDeck);
          onScore(curr => ({ ...curr, [activePlayer.id]: (curr[activePlayer.id] || 0) + 1 }));
          setFlippedIndices([]);
          setFlipLock(false);
          
          playBoxAudio.playSuccess();
          onUnlock('memory_master');

          // Check Win Condition
          if (matchedDeck.every(c => c.matched)) {
            // Find highest scorer
            let bestId = activePlayer.id;
            let bestSc = -1;
            players.forEach(p => {
              const pScore = scores[p.id] + (p.id === activePlayer.id ? 1 : 0);
              if (pScore > bestSc) {
                bestSc = pScore;
                bestId = p.id;
              }
            });
            onWin(bestId);
          }
        }, 800);
      } else {
        // No match found - turn goes back
        setTimeout(() => {
          const resetDeck = nextDeck.map((card, i) => {
            if (i === first || i === second) {
              return { ...card, flipped: false };
            }
            return card;
          });
          setDeck(resetDeck);
          setFlippedIndices([]);
          
          // Switch Turn with whistling
          const nextIdx = (currentPlayerIdx + 1) % players.length;
          setCurrentPlayerIdx(nextIdx);
          setLastTurnAnnouncement(`${players[nextIdx].name.toUpperCase()}'S TURN!`);
          playBoxAudio.playWhistle();
          setFlipLock(false);

          setTimeout(() => {
            setLastTurnAnnouncement('');
          }, 1500);
        }, 1200);
      }
    }
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-6 bg-amber-950/20" id="memory-game-sandbox">
      {/* HUD Board */}
      <div className="flex justify-around items-center bg-black/40 py-2 px-4 rounded-xl border border-white/10 text-sm">
        {players.map((p, idx) => (
          <div 
            key={p.id} 
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border-2 transition-transform duration-150 ${
              idx === currentPlayerIdx ? 'border-yellow-400 bg-yellow-400/20 scale-105' : 'border-transparent opacity-60'
            }`}
          >
            {renderAvatarSvg(p.avatar, 24)}
            <span className="font-semibold text-xs leading-none">{p.name}: <b className="text-yellow-300">{scores[p.id]} Pairs</b></span>
          </div>
        ))}
      </div>

      {/* Grid Canvas */}
      <div className="relative flex-grow flex items-center justify-center p-4">
        {lastTurnAnnouncement && (
          <div className="absolute inset-0 bg-black/60 z-10 flex items-center justify-center pointer-events-none animate-scale-up">
            <div className="bg-red-500 text-white font-display-lg text-3xl tracking-wide px-8 py-4 rounded-full border-4 border-white shadow-lg rotate-[-3deg]">
              {lastTurnAnnouncement}
            </div>
          </div>
        )}

        <div className="grid grid-cols-4 gap-3 max-w-sm w-full">
          {deck.map((card, index) => (
            <button
              key={card.id}
              onClick={() => handleFlipCard(index)}
              className={`aspect-square rounded-xl border-4 bubbly-card transition-all duration-300 flex items-center justify-center relative select-none ${
                card.matched 
                  ? 'bg-transparent border-transparent opacity-30 cursor-default' 
                  : card.flipped 
                  ? 'bg-white border-yellow-400 rotate-y-180 scale-102' 
                  : 'bg-primary-container border-yellow-600 hover:scale-103'
              }`}
              id={`memory-card-${index}`}
            >
              {card.matched ? null : card.flipped ? (
                <span className="text-3xl filter drop-shadow font-sans">{card.icon}</span>
              ) : (
                <div className="flex flex-col items-center">
                  <span className="text-lg text-on-primary-container">🎁</span>
                </div>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 2. MINIGAME: HORIZONTAL CHICKEN JUMP
// ==========================================
function ChickenJump({ players, onWin, onUnlock }: { players: Player[]; onWin: (winnerId: number) => void; onUnlock: (awardId: string) => void }) {
  const [alive, setAlive] = useState<Record<number, boolean>>(() => {
    const a: Record<number, boolean> = {};
    players.forEach(p => a[p.id] = true);
    return a;
  });

  const [chickenHeights, setChickenHeights] = useState<Record<number, number>>(() => {
    const h: Record<number, number> = {};
    players.forEach(p => h[p.id] = 0);
    return h;
  });

  const [chickenRotations, setChickenRotations] = useState<Record<number, number>>(() => {
    const r: Record<number, number> = {};
    players.forEach(p => r[p.id] = 0);
    return r;
  });

  // Track independent watermelons for each player lane
  const [watermelonX, setWatermelonX] = useState<Record<number, number>>(() => {
    const x: Record<number, number> = {};
    players.forEach(p => x[p.id] = 100 + Math.random() * 30);
    return x;
  });

  const [watermelonSpeeds, setWatermelonSpeeds] = useState<Record<number, number>>(() => {
    const s: Record<number, number> = {};
    players.forEach(p => s[p.id] = 1.3 + Math.random() * 0.5);
    return s;
  });

  const [scoreCounts, setScoreCounts] = useState<Record<number, number>>(() => {
    const sc: Record<number, number> = {};
    players.forEach(p => sc[p.id] = 0);
    return sc;
  });

  const [impactFlashes, setImpactFlashes] = useState<Record<number, boolean>>(() => {
    const f: Record<number, boolean> = {};
    players.forEach(p => f[p.id] = false);
    return f;
  });

  const jumpVelocityRef = useRef<Record<number, number>>({});
  const isJumpingRef = useRef<Record<number, boolean>>({});
  const jumpsLeftRef = useRef<Record<number, number>>({});

  // Initialize jump counts
  useEffect(() => {
    players.forEach(p => {
      jumpsLeftRef.current[p.id] = 2;
    });
  }, [players]);

  // Main physics loop (using requestAnimationFrame via setInterval at 60fps)
  useEffect(() => {
    const interval = setInterval(() => {
      // 1. Move independent watermelons
      setWatermelonX(prev => {
        const next = { ...prev };
        players.forEach(p => {
          if (!alive[p.id]) return;
          next[p.id] = next[p.id] - (1.6 * watermelonSpeeds[p.id]);

          // Recycled / Dodged successfully!
          if (next[p.id] <= -5) {
            next[p.id] = 100 + Math.random() * 20; // reset
            // Increase speed slightly
            setWatermelonSpeeds(speeds => ({
              ...speeds,
              [p.id]: Math.min(speeds[p.id] + 0.16, 4.0)
            }));
            // Award point for dodging
            setScoreCounts(sc => {
              const u = { ...sc, [p.id]: sc[p.id] + 1 };
              if (u[p.id] >= 10) {
                onUnlock('jumper'); // unlocked dodger/jumper badge
              }
              return u;
            });
          }
        });
        return next;
      });

      // 2. Physics & Gravity
      setChickenHeights(prev => {
        const next = { ...prev };
        players.forEach(p => {
          if (!alive[p.id]) return;
          if (isJumpingRef.current[p.id]) {
            const vel = jumpVelocityRef.current[p.id] || 0;
            const nextH = Math.max(0, next[p.id] + vel);

            if (nextH === 0) {
              // Landed!
              next[p.id] = 0;
              isJumpingRef.current[p.id] = false;
              jumpVelocityRef.current[p.id] = 0;
              jumpsLeftRef.current[p.id] = 2; // reset double jump
              setChickenRotations(rot => ({ ...rot, [p.id]: 0 }));
            } else {
              next[p.id] = nextH;
              jumpVelocityRef.current[p.id] = vel - 0.75; // gravity pull
              
              // If in air, apply rotation spin
              if (jumpsLeftRef.current[p.id] === 0) {
                setChickenRotations(rot => ({ ...rot, [p.id]: rot[p.id] + 16 }));
              }
            }
          }
        });
        return next;
      });
    }, 16);

    return () => clearInterval(interval);
  }, [players, alive, watermelonSpeeds, onUnlock]);

  // Continuous collision checking
  useEffect(() => {
    players.forEach(p => {
      if (!alive[p.id]) return;

      const wx = watermelonX[p.id];
      const height = chickenHeights[p.id];

      // Safe collision window: standard avatar sits between x=17% and x=23%
      if (wx >= 16 && wx <= 22) {
        // Must jump higher than 18px to clear the hurdle
        if (height < 22) {
          // Smash hit!
          playBoxAudio.playExplosion();
          
          // Flash red on this lane
          setImpactFlashes(f => ({ ...f, [p.id]: true }));
          setTimeout(() => {
            setImpactFlashes(f => ({ ...f, [p.id]: false }));
          }, 300);

          setAlive(curr => {
            const next = { ...curr, [p.id]: false };
            const survivors = Object.keys(next).filter(id => next[Number(id)]);

            if (survivors.length === 1) {
              setTimeout(() => {
                onUnlock('survivor');
                onWin(Number(survivors[0]));
              }, 600);
            } else if (survivors.length === 0) {
              // Last person to die wins or simple draw decider
              setTimeout(() => onWin(p.id), 600);
            }
            return next;
          });
        }
      }
    });
  }, [watermelonX, chickenHeights, alive, players, onWin, onUnlock]);

  const triggerJump = (pId: number) => {
    if (!alive[pId]) return;
    const currentJumps = jumpsLeftRef.current[pId] ?? 2;

    if (currentJumps > 0) {
      playBoxAudio.playJump();
      isJumpingRef.current[pId] = true;
      
      if (currentJumps === 2) {
        // High Single Jump
        jumpVelocityRef.current[pId] = 11.0;
      } else {
        // Double Jump acrobatics flip!
        jumpVelocityRef.current[pId] = 8.5;
        playBoxAudio.playWhistle(); // chirp flip sound!
      }
      
      jumpsLeftRef.current[pId] = currentJumps - 1;
    }
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 relative bg-slate-900 rounded-3xl border-4 border-primary shadow-[6px_6px_0px_0px_#0f172a]" id="chicken-jump-level">
      {/* Running Tracks grid */}
      <div className="flex-grow flex flex-col justify-center gap-3 w-full relative min-h-[220px]" id="dodge-stage">
        <h4 className="absolute top-2 left-1/2 -translate-x-1/2 text-[10px] font-black uppercase bg-red-500 text-white border-2 border-primary px-3 py-1 rounded-full tracking-wider shadow z-20 flex items-center gap-1.5" id="dodge-logs-warn">
          <span>⚠️</span> HARDCORE JUMP: DODGE WATERMELONS! Double-Jump Active!
        </h4>

        {players.map((p) => {
          const isAlive = alive[p.id];
          const score = scoreCounts[p.id];
          const flashing = impactFlashes[p.id];

          return (
            <div 
              key={p.id} 
              className={`h-22 w-full flex items-center border-[3px] border-primary rounded-2xl relative transition-all overflow-hidden ${
                flashing 
                  ? 'bg-red-500 border-red-200 animate-pulse' 
                  : isAlive 
                  ? 'bg-slate-950/40 border-slate-700/50' 
                  : 'bg-red-950/20 opacity-30 border-slate-800'
              }`}
              id={`lane-player-${p.id}`}
            >
              {/* Lane track background details */}
              <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:20px_100%] opacity-40 pointer-events-none" />

              {/* Lane Info display tag */}
              <div className="absolute left-3 top-2 text-[9px] font-black leading-none flex items-center gap-1.5 z-15 bg-slate-800/90 text-white px-2 py-1 rounded-md border border-slate-700">
                <span className="w-2 h-2 rounded-full ring-1 ring-white" style={{ backgroundColor: p.color }} />
                <span>{p.name}</span>
                <span className="px-1 bg-green-500 rounded text-slate-950 font-bold ml-1">Score: {score}</span>
              </div>

              {/* Character Chick */}
              {isAlive ? (
                <div 
                  className="absolute left-[18%] transition-transform duration-75 select-none z-10"
                  style={{ 
                    transform: `translateY(-${chickenHeights[p.id]}px) rotate(${chickenRotations[p.id]}deg)` 
                  }}
                >
                  <div className="relative flex flex-col items-center">
                    {/* Shadow scaling down as height climbs */}
                    <div 
                      className="absolute bottom-[-5px] w-8 h-2 bg-black/40 rounded-full blur-[1px] transition-transform" 
                      style={{ transform: `scale(${Math.max(0.3, 1 - chickenHeights[p.id]/150)})` }}
                    />
                    
                    {renderAvatarSvg(p.avatar, 44)}
                    {/* Character Tag Overlay */}
                    <span className="absolute -top-3 right-[-4px] text-xs">🐥</span>
                  </div>
                </div>
              ) : (
                <div className="absolute left-[18%] flex items-center gap-1 text-sm font-black text-rose-500 select-none z-10">
                  <span>🍗</span>
                  <span className="uppercase tracking-tighter">ROASTED</span>
                </div>
              )}

              {/* Lane Obstacle */}
              {isAlive && (
                <div 
                  className="absolute text-3xl select-none filter drop-shadow animate-spin"
                  style={{ 
                    left: `${watermelonX[p.id]}%`, 
                    bottom: '12px',
                    animationDuration: `${0.8 / watermelonSpeeds[p.id]}s`
                  }}
                >
                  🍉
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Touch Command Board */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-black/65 p-3 rounded-2xl border-2 border-slate-800 mt-2">
        {players.map((p) => (
          <button
            key={p.id}
            onClick={() => triggerJump(p.id)}
            disabled={!alive[p.id]}
            className={`py-3.5 rounded-2xl text-xs uppercase flex flex-col items-center justify-center gap-1 border-3 font-black transition-all shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] active:translate-x-[2px] active:translate-y-[2px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] ${
              alive[p.id] 
                ? 'bg-yellow-400 border-primary text-primary hover:bg-yellow-300' 
                : 'bg-slate-800 text-slate-600 border-slate-900 pointer-events-none'
            }`}
            id={`jump-btn-player-${p.id}`}
          >
            <span className="text-[10px] opacity-75">{p.name}</span>
            <span className="text-sm font-black flex items-center gap-1">Jump 🦘</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ==========================================
// 3. MINIGAME: SASHIMI HOT POTATO BOMB
// ==========================================
function SashimiGame({ players, onWin, onUnlock }: { players: Player[]; onWin: (winnerId: number) => void; onUnlock: (awardId: string) => void }) {
  const [alive, setAlive] = useState<Record<number, boolean>>(() => {
    const a: Record<number, boolean> = {};
    players.forEach(p => a[p.id] = true);
    return a;
  });

  const [holderIdx, setHolderIdx] = useState(0);
  const [timer, setTimer] = useState(12); // seconds until nuclear sushi blow

  // Timer run down
  useEffect(() => {
    const interval = setInterval(() => {
      setTimer(t => {
        if (t <= 0.1) {
          // EXPLOSION! Explode the holder
          playBoxAudio.playExplosion();
          const targetPlayerId = players[holderIdx].id;
          
          setAlive(curr => {
            const next = { ...curr, [targetPlayerId]: false };
            const survivors = Object.keys(next).filter(id => next[Number(id)]);
            
            if (survivors.length === 1) {
              setTimeout(() => {
                onUnlock('sushibomb');
                onWin(Number(survivors[0]));
              }, 600);
            } else if (survivors.length === 0) {
              // Draw
              setTimeout(() => onWin(targetPlayerId), 600);
            } else {
              // Next round with fresh timer!
              const nextRunner = players.findIndex((p, idx) => next[p.id]);
              setHolderIdx(nextRunner !== -1 ? nextRunner : 0);
              setTimer(10);
            }
            return next;
          });
          return 10;
        }
        return Number((t - 0.1).toFixed(1));
      });
    }, 100);

    return () => clearInterval(interval);
  }, [holderIdx, players]);

  const passSashimi = (pIdx: number) => {
    if (pIdx !== holderIdx || !alive[players[pIdx].id]) return;
    
    // Find next alive player
    let nextIdx = (pIdx + 1) % players.length;
    for (let i = 0; i < players.length; i++) {
      if (alive[players[nextIdx].id]) {
        break;
      }
      nextIdx = (nextIdx + 1) % players.length;
    }

    if (nextIdx !== pIdx) {
      setHolderIdx(nextIdx);
      playBoxAudio.playWhistle(); // Pass whistle!
    }
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-6 bg-[#2a1325]" id="sashimi-hot-potato">
      {/* Ticking score card */}
      <div className="text-center bg-black/40 p-3 rounded-lg border border-white/10 max-w-sm mx-auto">
        <span className="text-xs font-mono uppercase tracking-widest text-red-400">🚨 SPICY SASHIMI TIMER</span>
        <h3 className="font-display-lg text-4xl text-white tracking-widest leading-none mt-1">
          {timer.toFixed(1)}s
        </h3>
      </div>

      {/* Round-about arena layout representation */}
      <div className="flex-grow flex items-center justify-center p-4 relative" id="circle-table">
        <div className="w-56 h-56 rounded-full border-4 border-dashed border-white/20 bg-pink-950/20 flex items-center justify-center relative">
          
          {/* Central Sashimi bomb */}
          <div className="text-5xl filter drop-shadow animate-ping">
            🌶️🍣💨
          </div>

          {/* Connected players surrounding */}
          {players.map((p, idx) => {
            const isAlive = alive[p.id];
            const isHolding = idx === holderIdx;
            const angle = (idx * (360 / players.length)) * (Math.PI / 180);
            const x = Math.cos(angle) * 105;
            const y = Math.sin(angle) * 105;

            return (
              <div 
                key={p.id}
                className="absolute transition-transform duration-100 flex flex-col items-center"
                style={{ transform: `translate(${x}px, ${y}px)` }}
              >
                <div className={`p-1 bg-black rounded-full border-2 ${isHolding ? 'border-red-500 ring-4 ring-red-500/50 animate-bounce' : 'border-transparent'}`}>
                  {renderAvatarSvg(p.avatar, 38)}
                </div>
                <span className="text-[10px] font-sans font-bold bg-black/80 text-white px-2 py-0.5 rounded mt-1 shadow-sm leading-none whitespace-nowrap">
                  {p.name} {isHolding && '🔥'}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Corner Pass triggers */}
      <div className="grid grid-cols-2 gap-4">
        {players.map((p, idx) => {
          const isHolding = idx === holderIdx;
          const isAlive = alive[p.id];

          return (
            <button
              key={p.id}
              onClick={() => passSashimi(idx)}
              disabled={!isHolding || !isAlive}
              className={`py-5 px-3 rounded-full font-display-lg text-md uppercase tracking-wider flex items-center justify-center gap-2 border-b-4 bouncy-button bubbly-card ${
                !isAlive 
                  ? 'bg-gray-700 text-gray-500 border-gray-900 cursor-not-allowed opacity-30'
                  : isHolding 
                  ? 'bg-red-500 border-red-800 text-white animate-pulse' 
                  : 'bg-gray-400 border-gray-600 text-gray-700'
              }`}
            >
              <span className="text-xs font-sans leading-none">{p.name} :</span>
              <span>PASS SUSHIBOMB!</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ==========================================
// 4. MINIGAME: SOCCER POOL (BUMPER COOPER KICK)
// ==========================================
function SoccerPool({ players, onWin, onUnlock }: { players: Player[]; onWin: (winnerId: number) => void; onUnlock: (awardId: string) => void }) {
  const [bScores, setBScores] = useState<Record<number, number>>(() => {
    const s: Record<number, number> = {};
    players.forEach(p => s[p.id] = 0);
    return s;
  });

  const [ball, setBall] = useState({ x: 50, y: 50, vx: 0.5, vy: -0.5 });
  const [playersBumper, setPlayersBumper] = useState<Record<number, { x: number; y: number; vx: number; vy: number }>>(() => {
    const b: Record<number, { x: number; y: number; vx: number; vy: number }> = {};
    players.forEach((p, idx) => {
      // Starting positions for up to 4 corner players
      const corners = [
        { x: 18, y: 18 },
        { x: 82, y: 18 },
        { x: 18, y: 82 },
        { x: 82, y: 82 },
      ];
      const startPos = corners[idx] || { x: 50, y: 50 };
      b[p.id] = { ...startPos, vx: 0, vy: 0 };
    });
    return b;
  });

  const [lastBumperTouchId, setLastBumperTouchId] = useState<number | null>(null);
  const [goalFlash, setGoalFlash] = useState<string | null>(null);

  // Ball & Player kinematics loop
  useEffect(() => {
    const interval = setInterval(() => {
      // 1. Move Player Bumpers & Resolve Wall Bounces
      setPlayersBumper(curr => {
        const next = { ...curr };
        const ids = Object.keys(next).map(Number);
        
        ids.forEach(id => {
          const bp = next[id];
          if (!bp) return;

          let nx = bp.x + bp.vx;
          let ny = bp.y + bp.vy;
          let nvx = bp.vx * 0.93; // Kinetic friction decay
          let nvy = bp.vy * 0.93;

          // Wall rigid constraints with deflection
          if (nx <= 6) { nx = 6.1; nvx = -nvx * 0.5; }
          if (nx >= 94) { nx = 93.9; nvx = -nvx * 0.5; }
          if (ny <= 6) { ny = 6.1; nvy = -nvy * 0.5; }
          if (ny >= 94) { ny = 93.9; nvy = -nvy * 0.5; }

          next[id] = { x: nx, y: ny, vx: nvx, vy: nvy };
        });

        // Resolve Inter-Bumper collisions (Player vs Player bounce back!)
        for (let i = 0; i < ids.length; i++) {
          for (let j = i + 1; j < ids.length; j++) {
            const idA = ids[i];
            const idB = ids[j];
            const bpA = next[idA];
            const bpB = next[idB];

            const dx = bpB.x - bpA.x;
            const dy = bpB.y - bpA.y;
            const dist = Math.sqrt(dx * dx + dy * dy);

            if (dist < 12.5) { // Solid radial overlap
              playBoxAudio.playSlap();

              // Deflection vectors
              const nxVec = dx / (dist || 1);
              const nyVec = dy / (dist || 1);

              // Relative velocity
              const rvx = bpB.vx - bpA.vx;
              const rvy = bpB.vy - bpA.vy;

              // Velocity along normal
              const velocityNormal = rvx * nxVec + rvy * nyVec;

              if (velocityNormal < 0) {
                const restitution = 0.85; // highly bouncy elastic coefficient
                const impulse = -(1 + restitution) * velocityNormal / 2;

                next[idA].vx -= impulse * nxVec;
                next[idA].vy -= impulse * nyVec;
                next[idB].vx += impulse * nxVec;
                next[idB].vy += impulse * nyVec;

                // Nudge apart to prevent overlapping sticky frames
                const overlap = 12.6 - dist;
                next[idA].x -= nxVec * (overlap / 2);
                next[idA].y -= nyVec * (overlap / 2);
                next[idB].x += nxVec * (overlap / 2);
                next[idB].y += nyVec * (overlap / 2);
              }
            }
          }
        }

        return next;
      });

      // 2. Drive Ball Physics
      setBall(b => {
        let nx = b.x + b.vx;
        let ny = b.y + b.vy;
        let nvx = b.vx * 0.985; // Low friction rolling drag
        let nvy = b.vy * 0.985;

        // Bounce from walls mapping
        if (nx <= 4) { nvx = -nvx * 0.9; nx = 4.1; }
        if (nx >= 96) { nvx = -nvx * 0.9; nx = 95.9; }
        if (ny <= 4) { nvy = -nvy * 0.9; ny = 4.1; }
        if (ny >= 96) { nvy = -nvy * 0.9; ny = 95.9; }

        return { x: nx, y: ny, vx: nvx, vy: nvy };
      });

      // 3. Resolve Bumper vs Ball collisions (Dynamic Action and Reaction bounce-back!)
      setPlayersBumper(currBumpers => {
        setBall(b => {
          let bvx = b.vx;
          let bvy = b.vy;
          let bx = b.x;
          let by = b.y;

          players.forEach(p => {
            const bump = currBumpers[p.id];
            if (!bump) return;

            const dx = bx - bump.x;
            const dy = by - bump.y;
            const dist = Math.sqrt(dx * dx + dy * dy);

            if (dist < 10.5) { // Bumper-to-Ball boundary contact
              playBoxAudio.playSuccess();
              setLastBumperTouchId(p.id);

              const nxVec = dx / (dist || 1);
              const nyVec = dy / (dist || 1);

              // Boost the ball away at high momentum!
              bvx = nxVec * 2.8 + bump.vx * 0.35;
              bvy = nyVec * 2.8 + bump.vy * 0.35;

              // Newton's Third Law Bounce-Back: Throw the player's bumper BACKWARDS!
              currBumpers[p.id].vx = -nxVec * 1.6;
              currBumpers[p.id].vy = -nyVec * 1.6;

              // Nudge ball outward to prevent sticking
              const overlap = 10.6 - dist;
              bx += nxVec * overlap;
              by += nyVec * overlap;
            }
          });

          return { x: bx, y: by, vx: bvx, vy: bvy };
        });
        return currBumpers;
      });

    }, 24);

    return () => clearInterval(interval);
  }, [players]);

  // Goal trigger and score tracker
  useEffect(() => {
    const goalChecker = setInterval(() => {
      setBall(b => {
        // Goal mouth centers: top (ny <= 8, x is 38-62) and bottom (ny >= 92, x is 38-62)
        const topGoal = b.y <= 9 && b.x >= 38 && b.x <= 62;
        const bottomGoal = b.y >= 91 && b.x >= 38 && b.x <= 62;

        if (topGoal || bottomGoal) {
          playBoxAudio.playExplosion();
          
          let scorerId = lastBumperTouchId;
          if (!scorerId) {
            // Fallback: scorer is the closest active player
            let minDist = 9999;
            players.forEach(p => {
              const bState = playersBumper[p.id];
              if (bState) {
                const d = Math.sqrt((bState.x - b.x)*(bState.x - b.x) + (bState.y - b.y)*(bState.y - b.y));
                if (d < minDist) {
                  minDist = d;
                  scorerId = p.id;
                }
              }
            });
          }

          if (scorerId) {
            const finalScorer = scorerId;
            setGoalFlash(`⚽ GOAL BY ${players.find(p => p.id === finalScorer)?.name || 'PLAYER'}!`);
            
            setBScores(curr => {
              const next = { ...curr, [finalScorer]: curr[finalScorer] + 1 };
              if (next[finalScorer] >= 3) {
                setTimeout(() => {
                  onUnlock('survivor');
                  onWin(finalScorer);
                }, 1100);
              }
              return next;
            });
          }

          setTimeout(() => setGoalFlash(null), 1400);

          // Reset the ball center
          return {
            x: 50,
            y: 50,
            vx: (Math.random() - 0.5) * 1.6,
            vy: (Math.random() - 0.5) * 1.6,
          };
        }
        return b;
      });
    }, 100);

    return () => clearInterval(goalChecker);
  }, [players, lastBumperTouchId, playersBumper]);

  const dashBumper = (pId: number) => {
    playBoxAudio.playJump();
    setPlayersBumper(curr => {
      const next = { ...curr };
      const pos = next[pId];
      if (pos) {
        // Calculate physics direction vector from player bumper to ball
        const dx = ball.x - pos.x;
        const dy = ball.y - pos.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        
        // Massive momentum boost (dash) towards ball
        const kickPower = 3.2;
        const addVx = (dx / (dist || 1)) * kickPower;
        const addVy = (dy / (dist || 1)) * kickPower;
        
        next[pId] = {
          ...pos,
          vx: pos.vx + addVx,
          vy: pos.vy + addVy,
        };
      }
      return next;
    });
  };

  const pId = players[0]?.id || 1;

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-[#0a1f11] rounded-3xl border-4 border-primary shadow-[6px_6px_0px_0px_#0f172a]" id="soccer-pool-arena">
      
      {/* High-Contrast Player Scorecards (Extreme Legibility) */}
      <div className="flex justify-around bg-black/60 p-3 rounded-2xl border-2 border-primary/20 gap-2 mb-2 w-full max-w-md mx-auto">
        {players.map((p) => (
          <div key={p.id} className="flex flex-col items-center p-1.5 rounded-xl border border-white/10" style={{ backgroundColor: `${p.color}25` }}>
            <span className="px-3 py-1 rounded-lg text-white font-black text-[11px] uppercase tracking-wider shadow-sm border border-white/20" style={{ backgroundColor: p.color }}>
              {p.name}
            </span>
            <b className="text-yellow-400 font-extrabold text-[13px] mt-1 text-center">{bScores[p.id]} GOALS</b>
          </div>
        ))}
      </div>

      {/* Physics Pool Box Canvas */}
      <div className="flex-grow flex items-center justify-center p-2 relative">
        <div className="w-64 h-64 border-4 border-white/30 bg-green-950/40 relative rounded-2xl overflow-hidden shadow-inner">
          {/* Goal lines */}
          <div className="absolute top-0 left-[38%] right-[38%] h-2.5 bg-yellow-400 animate-pulse rounded-b-md" />
          <div className="absolute bottom-0 left-[38%] right-[38%] h-2.5 bg-yellow-400 animate-pulse rounded-t-md" />

          {/* Goal Flash Banner */}
          {goalFlash && (
            <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 bg-yellow-400 text-primary uppercase text-center font-black text-xs py-2 border-y-4 border-primary rotate-[-4deg] scale-110 z-20 shadow-lg animate-bounce">
              {goalFlash}
            </div>
          )}

          {/* Bouncing ball */}
          <div 
            className="absolute w-8 h-8 rounded-full bg-white text-md flex items-center justify-center border-2 border-black z-10 transition-all select-none duration-75 shadow-lg"
            style={{ left: `calc(${ball.x}% - 16px)`, top: `calc(${ball.y}% - 16px)` }}
          >
            ⚽
          </div>

          {/* Connected players bumper disks */}
          {players.map((p) => {
            const pos = playersBumper[p.id];
            if (!pos) return null;
            return (
              <div
                key={p.id}
                className="absolute w-11 h-11 rounded-full flex items-center justify-center border-[3px] border-black shadow-lg transition-all duration-75 p-0.5 animate-scale-up"
                style={{ 
                  left: `calc(${pos.x}% - 22px)`, 
                  top: `calc(${pos.y}% - 22px)`,
                  backgroundColor: p.color,
                }}
              >
                <div className="w-full h-full bg-white/10 rounded-full flex items-center justify-center relative">
                  {renderAvatarSvg(p.avatar, 32)}
                  <span className="absolute -bottom-1 text-[8px] font-black bg-stone-900 text-white rounded px-1 scale-90 border border-white/20 truncate max-w-[34px]">
                    {p.name[0]}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Tapping trigger keys with colored labels */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full mt-3">
        {players.map((p) => (
          <button
            key={p.id}
            onClick={() => dashBumper(p.id)}
            className="py-3 px-1 rounded-2xl text-white font-black text-xs uppercase border-b-6 active:scale-95 transition-all text-center flex flex-col items-center gap-1 shadow-md hover:brightness-110"
            style={{ 
              backgroundColor: p.color, 
              borderColor: `${p.color}dd`,
              textShadow: '0px 1px 2px rgba(0,0,0,0.6)'
            }}
            id={`dash-bumper-btn-player-${p.id}`}
          >
            <span className="bg-black/40 text-white rounded-lg px-2.5 py-0.5 text-[9px] font-bold tracking-wider uppercase mb-0.5">
              {p.name}
            </span>
            <span className="tracking-tight text-[11px]">KICK BUMPER!</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ==========================================
// 5. MINIGAME: CHILI CHOMP
// ==========================================
function ChiliChomp({ players, onWin, onUnlock }: { players: Player[]; onWin: (winnerId: number) => void; onUnlock: (awardId: string) => void }) {
  const [plates, setPlates] = useState<{ id: number; icon: '🍬' | '🌶️' | '🍩'; x: number }[]>([]);
  const [score, setScore] = useState<Record<number, number>>(() => {
    const s: Record<number, number> = {};
    players.forEach(p => s[p.id] = 0);
    return s;
  });

  const [stunList, setStunList] = useState<Record<number, boolean>>(() => {
    const sl: Record<number, boolean> = {};
    players.forEach(p => sl[p.id] = false);
    return sl;
  });

  // Food dropping generator
  useEffect(() => {
    const interval = setInterval(() => {
      setPlates(p => {
        // Randomly drop sweets/chili
        const items = ['🍬', '🌶️', '🍩'] as const;
        return [
          ...p,
          { 
            id: Math.random(), 
            icon: items[Math.floor(Math.random() * items.length)], 
            x: Math.floor(Math.random() * 80) + 10 
          }
        ].slice(-10); // keep limits high
      });
    }, 1200);

    return () => clearInterval(interval);
  }, []);

  const triggerEat = (pId: number) => {
    if (stunList[pId]) return;

    // Grab first element popped in plates and eat it
    if (plates.length > 0) {
      const target = plates[0];
      setPlates(p => p.slice(1));

      if (target.icon === '🌶️') {
        playBoxAudio.playSplat();
        // Spiced! Stun for 2 seconds and lose points
        setStunList(curr => ({ ...curr, [pId]: true }));
        setScore(curr => ({ ...curr, [pId]: Math.max(0, curr[pId] - 15) }));
        
        // Remove stun after timeout
        setTimeout(() => {
          setStunList(curr => ({ ...curr, [pId]: false }));
        }, 1800);
      } else {
        // Munch points!
        playBoxAudio.playJump();
        setScore(curr => {
          const next = { ...curr, [pId]: curr[pId] + 10 };
          if (next[pId] >= 60) {
            setTimeout(() => onWin(pId), 400);
          }
          return next;
        });
      }
    }
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-red-950/20" id="chili-chomp-arena">
      {/* Feasting Leaderboard */}
      <div className="flex justify-around bg-black/45 py-2 px-4 rounded-xl text-xs">
        {players.map((p) => (
          <span key={p.id} className="font-semibold">{p.name}: <b className="text-yellow-300">{score[p.id]} XP</b></span>
        ))}
      </div>

      {/* Main Dinner plate table */}
      <div className="flex-grow flex items-center justify-center relative p-4">
        <div className="w-56 h-56 rounded-full border-4 border-white/30 bg-orange-950/20 flex flex-col items-center justify-center relative overflow-hidden">
          
          <span className="text-xs uppercase font-mono tracking-widest text-yellow-300 animate-pulse select-none" id="munch-warn">
            🍛 SLURP DELIGHTS!
          </span>

          <div className="flex flex-col gap-2 mt-4 max-h-36 overflow-hidden">
            {plates.map((p) => (
              <div 
                key={p.id} 
                className="text-3xl filter drop-shadow animate-bounce select-none"
              >
                {p.icon}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Action munch tools */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {players.map((p) => {
          const isStunned = stunList[p.id];
          return (
            <button
              key={p.id}
              onClick={() => triggerEat(p.id)}
              disabled={isStunned}
              className={`py-4 rounded-xl font-display-lg text-xs uppercase border-b-4 bubbly-card active:scale-95 flex flex-col items-center justify-center ${
                isStunned 
                  ? 'bg-amber-900 border-amber-950 text-red-300 cursor-not-allowed animate-shake' 
                  : 'bg-emerald-600 border-emerald-800 text-white'
              }`}
              id={`eat-btn-player-${p.id}`}
            >
              <span className="font-sans text-[10px] opacity-80">{p.name}</span>
              <span>{isStunned ? '🔥 BURNING!!' : 'GOBBLE SWEETS!'}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ==========================================
// 6. MINIGAME: FLAPPY BALLOON Survival
// ==========================================
function FlappyBalloon({ players, onWin, onUnlock }: { players: Player[]; onWin: (winnerId: number) => void; onUnlock: (awardId: string) => void }) {
  const [alive, setAlive] = useState<Record<number, boolean>>(() => {
    const a: Record<number, boolean> = {};
    players.forEach(p => a[p.id] = true);
    return a;
  });

  const [yPositions, setYPositions] = useState<Record<number, number>>(() => {
    const y: Record<number, number> = {};
    players.forEach(p => y[p.id] = 50);
    return y;
  });

  const [ringX, setRingX] = useState(100);
  const [ringGapY, setRingGapY] = useState(50);
  const [ringSpeed, setRingSpeed] = useState(1);

  // Flight tick loop
  useEffect(() => {
    const interval = setInterval(() => {
      // Advance incoming hoop ring
      setRingX(prev => {
        if (prev <= -5) {
          setRingGapY(Math.floor(Math.random() * 50) + 25);
          setRingSpeed(s => Math.min(s + 0.1, 2.2));
          return 100;
        }
        return prev - (1.1 * ringSpeed);
      });

      // Gravity pulls floats down
      setYPositions(prev => {
        const next = { ...prev };
        players.forEach(p => {
          if (alive[p.id]) {
            next[p.id] = Math.min(Math.max(next[p.id] + 0.9, 10), 90);
          }
        });
        return next;
      });
    }, 25);

    return () => clearInterval(interval);
  }, [players, alive, ringSpeed]);

  // Hoop hit check
  useEffect(() => {
    if (ringX >= 18 && ringX <= 25) {
      players.forEach(p => {
        if (alive[p.id]) {
          const y = yPositions[p.id];
          const insideGap = Math.abs(y - ringGapY) <= 15;
          if (!insideGap) {
            // Explode pop!
            playBoxAudio.playExplosion();
            setAlive(curr => {
              const next = { ...curr, [p.id]: false };
              const survivors = Object.keys(next).filter(id => next[Number(id)]);
              if (survivors.length === 1) {
                setTimeout(() => {
                  onUnlock('survivor');
                  onWin(Number(survivors[0]));
                }, 500);
              } else if (survivors.length === 0) {
                setTimeout(() => onWin(p.id), 500);
              }
              return next;
            });
          }
        }
      });
    }
  }, [ringX, ringGapY, yPositions, alive, players]);

  const triggerFlap = (pId: number) => {
    if (!alive[pId]) return;
    playBoxAudio.playJump();
    setYPositions(curr => ({
      ...curr,
      [pId]: Math.max(curr[pId] - 13, 10), // Flap higher
    }));
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-sky-950/20" id="flappy-balloon-level">
      {/* Survival sky arena */}
      <div className="flex-grow flex items-center justify-center p-2 relative h-48">
        <div className="w-full h-full border-4 border-white/20 bg-sky-900/10 rounded-xl relative overflow-hidden">
          
          <span className="absolute top-2 left-1/2 -translate-x-1/2 text-xs font-mono uppercase bg-black/60 p-2 rounded tracking-widest text-[#4ade80]" id="sky-hoop-warn">
            🎈 FLAP THROUGH ROTATING HOOPS!
          </span>

          {/* Active ring hoop ring */}
          <div 
            className="absolute top-0 bottom-0 w-8 bg-yellow-400 border-l-4 border-r-4 border-yellow-600 opacity-60 flex items-center justify-center z-15"
            style={{ left: `${ringX}%` }}
          >
            {/* Opening ring gap */}
            <div 
              className="absolute w-12 h-16 bg-transparent border-t-4 border-b-4 border-white/80"
              style={{ top: `calc(${ringGapY}% - 32px)` }}
            />
          </div>

          {/* Floating player avatars */}
          {players.map((p) => {
            const isAlive = alive[p.id];
            if (!isAlive) return null;

            return (
              <div
                key={p.id}
                className="absolute left-[18%] text-3xl transition-all duration-75 select-none filter drop-shadow z-20"
                style={{ top: `calc(${yPositions[p.id]}% - 20px)` }}
              >
                <div className="relative">
                  {renderAvatarSvg(p.avatar, 38)}
                  <span className="absolute bottom-[-8px] right-[-6px] text-xs">🎈</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Command trigger board */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {players.map((p) => (
          <button
            key={p.id}
            onClick={() => triggerFlap(p.id)}
            disabled={!alive[p.id]}
            className={`py-4 rounded-xl font-display-lg text-xs uppercase border-b-4 bubbly-card active:scale-95 flex flex-col items-center ${
              alive[p.id] 
                ? 'bg-rose-500 border-rose-800 text-white animate-pulse' 
                : 'bg-gray-600 text-gray-500 border-gray-800'
            }`}
            id={`flap-btn-player-${p.id}`}
          >
            <span className="font-sans text-[10px] opacity-80">{p.name}</span>
            <span>FLAP HIGH!</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ==========================================
// 7. MINIGAME: SPIKE SQUEEZE Survival
// ==========================================
function SpikeSqueeze({ players, onWin, onUnlock }: { players: Player[]; onWin: (winnerId: number) => void; onUnlock: (awardId: string) => void }) {
  const [alive, setAlive] = useState<Record<number, boolean>>(() => {
    const a: Record<number, boolean> = {};
    players.forEach(p => a[p.id] = true);
    return a;
  });

  const [xPositions, setXPositions] = useState<Record<number, number>>(() => {
    const x: Record<number, number> = {};
    players.forEach(p => x[p.id] = 50);
    return x;
  });

  const [spikes, setSpikes] = useState<{ id: number; x: number; y: number }[]>([]);

  // Rocks falling interval
  useEffect(() => {
    const fallInterval = setInterval(() => {
      setSpikes(curr => {
        // Fall down
        const advanced = curr.map(s => ({ ...s, y: s.y + 4.5 })).filter(s => s.y < 100);
        // Add random rock spike
        if (Math.random() < 0.45) {
          advanced.push({ id: Math.random(), x: Math.floor(Math.random() * 85) + 5, y: 0 });
        }
        return advanced;
      });
    }, 120);

    return () => clearInterval(fallInterval);
  }, []);

  // Spike Collision check
  useEffect(() => {
    spikes.forEach(s => {
      if (s.y >= 75 && s.y <= 90) {
        players.forEach(p => {
          if (alive[p.id]) {
            const px = xPositions[p.id];
            const dist = Math.abs(px - s.x);
            if (dist < 12) {
              // Collided rock spike!
              playBoxAudio.playExplosion();
              setAlive(curr => {
                const next = { ...curr, [p.id]: false };
                const survivors = Object.keys(next).filter(id => next[Number(id)]);
                if (survivors.length === 1) {
                  setTimeout(() => {
                    onUnlock('survivor');
                    onWin(Number(survivors[0]));
                  }, 500);
                } else if (survivors.length === 0) {
                  setTimeout(() => onWin(p.id), 500);
                }
                return next;
              });
            }
          }
        });
      }
    });
  }, [spikes, xPositions, alive, players]);

  const movePlayer = (pId: number, direction: 'L' | 'R') => {
    if (!alive[pId]) return;
    setXPositions(curr => {
      const offset = direction === 'L' ? -12 : 12;
      return {
        ...curr,
        [pId]: Math.min(Math.max(curr[pId] + offset, 8), 92),
      };
    });
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-orange-950/20" id="spike-squeeze-level">
      {/* Bolder Falling ground track */}
      <div className="flex-grow flex items-center justify-center p-2 relative h-52">
        <div className="w-full h-full border-4 border-white/20 bg-orange-900/10 rounded-xl relative overflow-hidden">
          
          <span className="absolute top-2 left-1/2 -translate-x-1/2 text-[10px] font-mono uppercase bg-black/60 p-2 rounded tracking-widest text-red-400" id="falling-boulders-warn">
            🚨 AVOID CRUSHING ANVILS!
          </span>

          {/* Falling Spikes / Anvils */}
          {spikes.map((s) => (
            <div 
              key={s.id}
              className="absolute text-2xl select-none"
              style={{ left: `${s.x}%`, top: `${s.y}%` }}
            >
              ⚙️
            </div>
          ))}

          {/* Ground sliding heroes */}
          {players.map((p) => {
            const isAlive = alive[p.id];
            if (!isAlive) return null;

            return (
              <div
                key={p.id}
                className="absolute bottom-2 text-3xl transition-all duration-100 select-none filter drop-shadow z-20"
                style={{ left: `${xPositions[p.id]}%`, transform: 'translateX(-50%)' }}
              >
                <div className="relative">
                  {renderAvatarSvg(p.avatar, 38)}
                  <div className="absolute top-[-10px] left-0 right-0 h-1 rounded" style={{ backgroundColor: p.color }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Control steering buttons */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-black/40 p-3 rounded-b-xl border">
        {players.map((p) => (
          <div key={p.id} className="flex flex-col gap-1 items-center bg-white/5 p-1.5 rounded-lg border border-white/10">
            <span className="text-[10px] font-sans font-semibold uppercase text-yellow-300 leading-none">{p.name}</span>
            <div className="flex gap-2 w-full">
              <button
                onClick={() => movePlayer(p.id, 'L')}
                disabled={!alive[p.id]}
                className="flex-1 py-2 bg-sky-500 rounded font-bold hover:bg-sky-600 disabled:opacity-30 border-b-2 border-sky-700"
                id={`steer-l-player-${p.id}`}
              >
                ◀
              </button>
              <button
                onClick={() => movePlayer(p.id, 'R')}
                disabled={!alive[p.id]}
                className="flex-1 py-2 bg-sky-500 rounded font-bold hover:bg-sky-600 disabled:opacity-30 border-b-2 border-sky-700"
                id={`steer-r-player-${p.id}`}
              >
                ▶
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ==========================================
// 8. MINIGAME: QUICK DINO REACT
// ==========================================
function DinoReact({ players, onWin, onUnlock }: { players: Player[]; onWin: (winnerId: number) => void; onUnlock: (awardId: string) => void }) {
  // Dino running track states per player
  const [distance, setDistance] = useState<Record<number, number>>(() => {
    const d: Record<number, number> = {};
    players.forEach(p => d[p.id] = 0);
    return d;
  });

  const [dinoY, setDinoY] = useState<Record<number, number>>(() => {
    const y: Record<number, number> = {};
    players.forEach(p => y[p.id] = 0);
    return y;
  });

  const [dinoVy, setDinoVy] = useState<Record<number, number>>(() => {
    const vy: Record<number, number> = {};
    players.forEach(p => vy[p.id] = 0);
    return vy;
  });

  const [alive, setAlive] = useState<Record<number, boolean>>(() => {
    const a: Record<number, boolean> = {};
    players.forEach(p => a[p.id] = true);
    return a;
  });

  // Active obstacle per lane: list of obstacles { id: number, x: number, type: 'cactus' | 'bird' }
  const [laneObstacles, setLaneObstacles] = useState<Record<number, { id: number; x: number; type: 'cactus' | 'bird' }[]>>(() => {
    const o: Record<number, { id: number; x: number; type: 'cactus' | 'bird' }[]> = {};
    players.forEach(p => o[p.id] = [{ id: 1, x: 100, type: 'cactus' }]);
    return o;
  });

  const [runningTick, setRunningTick] = useState(0);

  // Core side-scroller game ticks
  useEffect(() => {
    const timer = setInterval(() => {
      setRunningTick(t => t + 1);

      // Jump gravity calculations
      setDinoY(currY => {
        const nextY = { ...currY };
        setDinoVy(currVy => {
          const nextVy = { ...currVy };
          players.forEach(p => {
            if (currY[p.id] > 0 || currVy[p.id] !== 0) {
              const ny = Math.max(0, currY[p.id] + currVy[p.id]);
              nextY[p.id] = ny;
              if (ny === 0) {
                nextVy[p.id] = 0;
              } else {
                nextVy[p.id] = currVy[p.id] - 0.7; // gravity pull
              }
            }
          });
          return nextVy;
        });
        return nextY;
      });

      // Update distance and obstacles
      setDistance(currDist => {
        const nextDist = { ...currDist };
        players.forEach(p => {
          if (alive[p.id]) {
            nextDist[p.id] = currDist[p.id] + 1;
            
            // Winning distance check (e.g. 150 meters wins!)
            if (nextDist[p.id] >= 150) {
              setTimeout(() => {
                onUnlock('fashion');
                onWin(p.id);
              }, 100);
            }
          }
        });
        return nextDist;
      });

      // Slide obstacles left and collision check
      setLaneObstacles(currObs => {
        const nextObs = { ...currObs };
        players.forEach(p => {
          if (!alive[p.id]) return;

          const activeList = currObs[p.id] || [];
          
          // Slide obstacles to the left
          let updatedList = activeList.map(o => ({ ...o, x: o.x - 3.2 }));

          // Spawn new obstacles dynamically
          if (updatedList.length === 0 || updatedList.every(o => o.x < 45)) {
            if (Math.random() < 0.3) {
              updatedList.push({
                id: Math.random(),
                x: 105,
                type: Math.random() < 0.65 ? 'cactus' : 'bird'
              });
            }
          }

          // Filter out of bounds obstacles
          updatedList = updatedList.filter(o => o.x > -10);

          // Collision Check! Dino sits around x = 12% in the horizontal lane
          setDinoY(currY => {
            const dy = currY[p.id] || 0;
            updatedList.forEach(obs => {
              const dxDist = Math.abs(obs.x - 12);
              if (dxDist < 6) { // collision sweep overlap x
                if (obs.type === 'cactus' && dy < 12) {
                  // Collided cactus!
                  playBoxAudio.playExplosion();
                  setAlive(prev => {
                    const next = { ...prev, [p.id]: false };
                    // If last survivor, handle victory
                    const survivors = players.filter(pl => next[pl.id]);
                    if (survivors.length === 1) {
                      setTimeout(() => onWin(survivors[0].id), 900);
                    } else if (survivors.length === 0) {
                      setTimeout(() => onWin(p.id), 900);
                    }
                    return next;
                  });
                } else if (obs.type === 'bird' && dy > 16) {
                  // Collided high flying bird (jumping too high hit a bird!)
                  playBoxAudio.playExplosion();
                  setAlive(prev => {
                    const next = { ...prev, [p.id]: false };
                    const survivors = players.filter(pl => next[pl.id]);
                    if (survivors.length === 1) {
                      setTimeout(() => onWin(survivors[0].id), 900);
                    } else if (survivors.length === 0) {
                      setTimeout(() => onWin(p.id), 900);
                    }
                    return next;
                  });
                }
              }
            });
            return currY;
          });

          nextObs[p.id] = updatedList;
        });
        return nextObs;
      });

    }, 36);

    return () => clearInterval(timer);
  }, [players, alive, onWin]);

  const triggerJump = (pId: number) => {
    if (!alive[pId]) return;
    setDinoY(curr => {
      if (curr[pId] === 0) {
        setDinoVy(vy => ({ ...vy, [pId]: 7.5 }));
        playBoxAudio.playJump();
      }
      return curr;
    });
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-[#0d1b1e] rounded-3xl border-4 border-primary shadow-[6px_6px_0px_0px_#0f172a]" id="dino-runner-split">
      <div className="text-center mb-1">
        <span className="text-[10px] font-mono tracking-widest text-emerald-400 bg-black/60 px-3 py-1 rounded-xl uppercase">
          🏃‍♂️ DINO DASH: RUN 150M!
        </span>
      </div>

      {/* Lane stacks container */}
      <div className="flex-grow flex flex-col gap-2 relative justify-center">
        {players.map((p) => {
          const isAlive = alive[p.id];
          const dy = dinoY[p.id] || 0;
          const dist = distance[p.id] || 0;
          const obsList = laneObstacles[p.id] || [];

          return (
            <div 
              key={p.id} 
              className="relative h-14 bg-stone-950/70 border border-white/10 rounded-xl overflow-hidden flex items-end px-2"
              style={{ borderLeft: `5px solid ${p.color}` }}
            >
              {/* Lane Info display */}
              <div className="absolute top-1.5 left-2.5 flex items-center gap-2 z-10">
                <span className="text-[10px] font-black text-white px-2 py-0.5 rounded-md uppercase" style={{ backgroundColor: p.color }}>
                  {p.name}
                </span>
                <span className="text-[9px] font-mono font-bold text-yellow-300 bg-black/50 px-1.5 py-0.5 rounded">
                  {dist}m
                </span>
                {!isAlive && (
                  <span className="text-[8px] font-black text-white uppercase bg-red-600 px-1 rounded animate-pulse scale-90">
                    💥 CRASHED
                  </span>
                )}
              </div>

              {/* Grid-Ground Line decoration */}
              <div className="absolute bottom-0 inset-x-0 h-1.5 bg-stone-700/60 border-t border-stone-600" />

              {/* The Dino Runner element */}
              {isAlive && (
                <div 
                  className="absolute bottom-[2px] transition-transform duration-75 text-2xl"
                  style={{ 
                    left: '12%', 
                    bottom: `${dy}px`,
                    transform: 'translateX(-50%)'
                  }}
                >
                  <div className="relative flex flex-col items-center">
                    {renderAvatarSvg(p.avatar, 34)}
                    {/* Animated running indicators */}
                    <span className="text-[9px] absolute -top-1 opacity-80 select-none">
                      {dy > 0 ? '✈️' : (runningTick % 2 === 0 ? '🏃‍♂️' : '🚶‍♂️')}
                    </span>
                  </div>
                </div>
              )}

              {/* Running lane sliding obstacles */}
              {obsList.map(obs => (
                <div 
                  key={obs.id}
                  className="absolute text-xl select-none"
                  style={{ 
                    left: `${obs.x}%`,
                    bottom: obs.type === 'bird' ? '22px' : '4px',
                    transform: 'translateX(-50%)'
                  }}
                >
                  {obs.type === 'bird' ? '🦅' : '🌵'}
                </div>
              ))}
            </div>
          );
        })}
      </div>

      {/* Dynamic Action Leap keys */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full mt-2">
        {players.map((p) => (
          <button
            key={p.id}
            onClick={() => triggerJump(p.id)}
            disabled={!alive[p.id]}
            className="py-3 font-black text-white rounded-2xl active:scale-95 transition-all uppercase flex flex-col items-center gap-0.5 border-b-6 shadow-md hover:brightness-110 disabled:opacity-30 disabled:pointer-events-none"
            style={{ 
              backgroundColor: p.color, 
              borderColor: `${p.color}aa`,
              textShadow: '0px 1px 2px rgba(0,0,0,0.6)'
            }}
            id={`dino-jump-btn-${p.id}`}
          >
            <span className="bg-black/30 rounded px-1.5 py-0.5 text-[8px] font-mono tracking-wide mb-0.5">
              {p.name}
            </span>
            <span className="text-xs">🦕 LEAP JUMP!</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ==========================================
// 9. MINIGAME: DONTS TOUCH THE POOP (Whack-A-Poop)
// ==========================================
function WhackAPoop({ players, onWin, onUnlock }: { players: Player[]; onWin: (winnerId: number) => void; onUnlock: (awardId: string) => void }) {
  const [scores, setScores] = useState<Record<number, number>>(() => {
    const s: Record<number, number> = {};
    players.forEach(p => s[p.id] = 0);
    return s;
  });

  // Track pops list per individual player!
  const [laneItems, setLaneItems] = useState<Record<number, { id: number; icon: '🍪' | '💩' | '🧁' | '🌈'; x: number; y: number }[]>>(() => {
    const li: Record<number, { id: number; icon: '🍪' | '💩' | '🧁' | '🌈'; x: number; y: number }[]> = {};
    players.forEach(p => li[p.id] = []);
    return li;
  });

  // Dynamic spawner interval per player lane
  useEffect(() => {
    const types: ('🍪' | '💩' | '🧁' | '🌈')[] = ['🍪', '🍪', '💩', '🧁', '🌈'];
    
    const popInterval = setInterval(() => {
      setLaneItems(curr => {
        const next = { ...curr };
        players.forEach(p => {
          const list = curr[p.id] || [];
          
          // Clear older ones to prevent overcrowding
          let nextList = list.filter(() => Math.random() < 0.82).slice(-4);

          // Randomize spawn
          if (nextList.length < 3 && Math.random() < 0.6) {
            nextList.push({
              id: Math.random(),
              icon: types[Math.floor(Math.random() * types.length)],
              x: Math.floor(Math.random() * 65) + 15,
              y: Math.floor(Math.random() * 55) + 15,
            });
          }
          next[p.id] = nextList;
        });
        return next;
      });
    }, 850);

    return () => clearInterval(popInterval);
  }, [players]);

  const clickLaneItem = (pId: number, itemId: number, icon: string) => {
    // Safely remove the tapped item
    setLaneItems(curr => ({
      ...curr,
      [pId]: (curr[pId] || []).filter(item => item.id !== itemId)
    }));

    if (icon === '💩') {
      playBoxAudio.playSplat();
      onUnlock('poop_toucher');
      setScores(curr => ({ ...curr, [pId]: Math.max(0, curr[pId] - 3) }));
    } else {
      playBoxAudio.playSuccess();
      const points = icon === '🌈' ? 3 : (icon === '🧁' ? 2 : 1);
      
      setScores(curr => {
        const next = { ...curr, [pId]: curr[pId] + points };
        if (next[pId] >= 15) {
          setTimeout(() => onWin(pId), 400);
        }
        return next;
      });
    }
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-[#1f1610] rounded-3xl border-4 border-primary shadow-[6px_6px_0px_0px_#0f172a]" id="whack-a-poop-level">
      
      {/* Target score indicator header */}
      <div className="text-center mb-1">
        <span className="text-[10px] font-mono tracking-wider bg-black/60 text-yellow-300 px-3 py-1 rounded-xl uppercase">
          🍪 WHACK-A-POP: REACH 15 PTS!
        </span>
      </div>

      {/* Lanes side-by-side! */}
      <div className="flex-grow grid grid-cols-2 lg:grid-cols-4 gap-2 items-stretch select-none my-1">
        {players.map((p) => {
          const items = laneItems[p.id] || [];
          const pScore = scores[p.id] || 0;

          return (
            <div 
              key={p.id}
              className="flex flex-col bg-stone-900/40 rounded-2xl p-1.5 border border-white/5 relative overflow-hidden"
              style={{ borderTop: `4px solid ${p.color}` }}
            >
              {/* Lane Header */}
              <div className="flex items-center justify-between px-1 mb-1">
                <span className="text-[9px] font-black uppercase tracking-wider text-white truncate max-w-[55px]" style={{ color: p.color }}>
                  {p.name}
                </span>
                <span className="text-[10px] font-black text-yellow-400 font-mono">
                  {pScore} PTS
                </span>
              </div>

              {/* The active items area for this player */}
              <div className="flex-grow relative bg-black/40 rounded-xl overflow-hidden min-h-[140px]">
                {items.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => clickLaneItem(p.id, item.id, item.icon)}
                    className="absolute text-5xl hover:scale-110 active:scale-95 transition-transform duration-75 filter drop-shadow select-none animate-bounce"
                    style={{ left: `${item.x}%`, top: `${item.y}%`, transform: 'translate(-50%, -50%)' }}
                    id={`lane-item-${p.id}-${item.id}`}
                  >
                    {item.icon}
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <div className="text-[10px] text-stone-400 italic text-center font-bold tracking-wide mt-1 uppercase">
        🍭 TAP COOKIES 🍪, CUPCAKES 🧁 & RAINBOWS 🌈! DO NOT TAP POOP 💩!
      </div>
    </div>
  );
}

// ==========================================
// 10. MINIGAME: SUMO SLAP BUBBLE RING
// ==========================================
function SumoSlap({ players, onWin, onUnlock }: { players: Player[]; onWin: (winnerId: number) => void; onUnlock: (awardId: string) => void }) {
  const [sizes, setSizes] = useState<Record<number, number>>(() => {
    const s: Record<number, number> = {};
    players.forEach(p => s[p.id] = 40); // base percentage size
    return s;
  });

  const triggerSlap = (pId: number) => {
    playBoxAudio.playSlap();

    setSizes(curr => {
      const next = { ...curr };
      // Push others down, get larger!
      next[pId] = Math.min(next[pId] + 4, 100);

      players.forEach(p => {
        if (p.id !== pId) {
          next[p.id] = Math.max(next[p.id] - 2, 8);
        }
      });

      // Win threshold check
      if (next[pId] >= 92) {
        setTimeout(() => {
          onUnlock('survivor');
          onWin(pId);
        }, 400);
      }
      return next;
    });
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-emerald-950/20" id="sumo-slap-arena">
      {/* Ring visual stage representation */}
      <div className="flex-grow flex items-center justify-center p-4 relative" id="ring-board">
        <div className="w-56 h-56 rounded-full border-4 border-double border-red-500 bg-red-950/20 flex items-center justify-center relative overflow-hidden animate-pulse">
          
          <span className="absolute top-2 text-[10px] font-mono tracking-widest text-[#4ade80]" id="sumo-squeeze-warn">
            🥊 RAPID SMASH POPPERS!
          </span>

          <div className="grid grid-cols-2 gap-4" id="ring-combatants">
            {players.map((p) => {
              const sz = sizes[p.id] || 40;
              return (
                <div 
                  key={p.id} 
                  className="transition-all duration-100 flex flex-col items-center"
                  style={{ transform: `scale(${sz / 55})` }}
                  id={`combatant-scale-${p.id}`}
                >
                  <div className="p-1 rounded-full border-4 border-black" style={{ backgroundColor: p.color }}>
                    {renderAvatarSvg(p.avatar, 42)}
                  </div>
                  <span className="text-[10px] font-bold font-sans uppercase animate-bounce leading-none mt-1">
                    {p.name}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Slam buttons command deck */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {players.map((p) => (
          <button
            key={p.id}
            onClick={() => triggerSlap(p.id)}
            className="py-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-display-lg text-xs uppercase border-b-4 border-red-950 bubbly-card active:scale-95 flex flex-col items-center justify-center"
            id={`slap-btn-player-${p.id}`}
          >
            <span className="font-sans text-[10px] opacity-80">{p.name}</span>
            <span>SMASH SLAP!</span>
          </button>
        ))}
      </div>
    </div>
  );
}
