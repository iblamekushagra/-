import React from 'react';
import { Player } from '../types';

interface AvatarCustomizerProps {
  player: Player;
  onUpdate: (updated: Player) => void;
  onClose: () => void;
  unlockedAccessories?: string[]; // Accessories unlocked in shop
}

const PRESET_COLORS = [
  '#00658d', // Sky Blue
  '#a04100', // Energetic Orange
  '#16a34a', // Lime Green
  '#b91c1c', // Crimson Red
  '#7c3aed', // Grape Purple
  '#db2777', // Sweet Pink
  '#ca8a04', // Bright Gold
  '#0d9488', // Teal Blue
];

const EYE_TYPES: Player['avatar']['eyeType'][] = ['happy', 'wacky', 'sunglasses', 'angry', 'dizzy'];
const MOUTH_TYPES: Player['avatar']['mouthType'][] = ['smile', 'gasp', 'silly', 'mustache', 'grump'];
const ACCESSORY_TYPES: Player['avatar']['accessory'][] = ['none', 'crown', 'party', 'chef', 'horns', 'halo', 'ninja'];

export function renderAvatarSvg(avatar: Player['avatar'], size: number = 100) {
  const { faceColor, eyeType, mouthType, accessory } = avatar;
  
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 100 100" 
      className="overflow-visible" 
      id={`avatar-svg-${faceColor.replace('#', '')}`}
    >
      {/* Background/Shadow of body */}
      <circle cx="50" cy="53" r="38" fill="rgba(0,0,0,0.15)" />
      
      {/* Main Base Face */}
      <circle cx="50" cy="50" r="38" fill={faceColor} stroke="#161d1f" strokeWidth="3" />
      {/* Face Highlight */}
      <path d="M 22 30 A 30 30 0 0 1 78 30 A 33 33 0 0 0 22 30" fill="rgba(255,255,255,0.25)" />

      {/* Eyes */}
      {eyeType === 'happy' && (
        <g stroke="#161d1f" strokeWidth="3.5" strokeLinecap="round" fill="none">
          {/* Laughing arcs */}
          <path d="M 32 45 Q 38 38 43 45" />
          <path d="M 57 45 Q 62 38 68 45" />
        </g>
      )}

      {eyeType === 'wacky' && (
        <g>
          {/* Big left googly eye, small right */}
          <circle cx="36" cy="44" r="10" fill="#ffffff" stroke="#161d1f" strokeWidth="2.5" />
          <circle cx="34" cy="44" r="4.5" fill="#161d1f" />
          
          <circle cx="62" cy="44" r="6" fill="#ffffff" stroke="#161d1f" strokeWidth="2.5" />
          <circle cx="64" cy="42" r="2.5" fill="#161d1f" />
        </g>
      )}

      {eyeType === 'sunglasses' && (
        <g>
          {/* Cool sunglasses */}
          <path d="M 22 38 L 78 38 L 74 50 C 72 54 62 54 60 50 L 50 42 L 40 50 C 38 54 28 54 26 50 Z" fill="#161d1f" stroke="#ffffff" strokeWidth="1.5" />
          {/* Lens reflections */}
          <line x1="28" y1="41" x2="34" y2="47" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
          <line x1="62" y1="41" x2="68" y2="47" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
        </g>
      )}

      {eyeType === 'angry' && (
        <g>
          <circle cx="36" cy="45" r="7" fill="#ffffff" stroke="#161d1f" strokeWidth="2.5" />
          <circle cx="64" cy="45" r="7" fill="#ffffff" stroke="#161d1f" strokeWidth="2.5" />
          <circle cx="38" cy="45" r="3" fill="#161d1f" />
          <circle cx="62" cy="45" r="3" fill="#161d1f" />
          {/* Slanted eyebrows */}
          <path d="M 26 36 L 44 42" stroke="#161d1f" strokeWidth="4.5" strokeLinecap="round" />
          <path d="M 74 36 L 56 42" stroke="#161d1f" strokeWidth="4.5" strokeLinecap="round" />
        </g>
      )}

      {eyeType === 'dizzy' && (
        <g stroke="#161d1f" strokeWidth="3" strokeLinecap="round" fill="none">
          {/* X eye left */}
          <path d="M 31 39 L 41 49" />
          <path d="M 41 39 L 31 49" />
          {/* X eye right */}
          <path d="M 59 39 L 69 49" />
          <path d="M 69 39 L 59 49" />
        </g>
      )}

      {/* Mouths */}
      {mouthType === 'smile' && (
        <g>
          {/* Thick curve with a little tooth! */}
          <path d="M 38 60 Q 50 78 62 60" fill="#ba1a1a" stroke="#161d1f" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M 44 61 L 56 61 L 50 66 Z" fill="#ffffff" stroke="#161d1f" strokeWidth="1.5" />
        </g>
      )}

      {mouthType === 'gasp' && (
        <ellipse cx="50" cy="65" rx="7" ry="9" fill="#161d1f" stroke="#161d1f" strokeWidth="1.5" />
      )}

      {mouthType === 'silly' && (
        <g>
          {/* Smiling line + big floppy pink tongue */}
          <path d="M 36 60 Q 50 63 64 60" stroke="#161d1f" strokeWidth="3" strokeLinecap="round" fill="none" />
          <path d="M 44 61 Q 50 78 56 61 Z" fill="#ff7da8" stroke="#161d1f" strokeWidth="2" />
          {/* Line divisor on tongue */}
          <line x1="50" y1="62" x2="50" y2="70" stroke="#161d1f" strokeWidth="1.5" />
        </g>
      )}

      {mouthType === 'mustache' && (
        <g fill="#5c4033" stroke="#161d1f" strokeWidth="2" strokeLinecap="round">
          {/* Heavy curly mustache */}
          <path d="M 50 58 Q 62 52 68 58 Q 50 68 50 58 Z" />
          <path d="M 50 58 Q 38 52 32 58 Q 50 68 50 58 Z" />
        </g>
      )}

      {mouthType === 'grump' && (
        <path d="M 38 68 Q 50 56 62 68" stroke="#161d1f" strokeWidth="3" strokeLinecap="round" fill="none" />
      )}

      {/* Accessories */}
      {accessory === 'crown' && (
        <g>
          {/* King Crown */}
          <path d="M 24 25 L 30 10 L 45 19 L 50 6 L 55 19 L 70 10 L 76 25 Z" fill="#ffd700" stroke="#161d1f" strokeWidth="2.5" />
          {/* Red jewels */}
          <circle cx="30" cy="9" r="2.5" fill="#ba1a1a" />
          <circle cx="50" cy="5" r="2.5" fill="#00658d" />
          <circle cx="70" cy="9" r="2.5" fill="#16a34a" />
          <rect x="44" y="20" width="12" height="4" fill="#16a34a" rx="1" />
        </g>
      )}

      {accessory === 'party' && (
        <g>
          {/* Cone Hat */}
          <path d="M 32 20 L 50 -8 L 68 20 Z" fill="#a04100" stroke="#161d1f" strokeWidth="2.5" />
          {/* Polka dots */}
          <circle cx="45" cy="12" r="3" fill="#ffd700" />
          <circle cx="55" cy="8" r="2" fill="#81cfff" />
          <circle cx="50" cy="17" r="2.5" fill="#ffffff" />
          {/* Fluffy pompom */}
          <circle cx="50" cy="-9" r="5" fill="#ba1a1a" stroke="#161d1f" strokeWidth="1.5" />
        </g>
      )}

      {accessory === 'chef' && (
        <g>
          {/* Puffy Chef Hat */}
          <path d="M 28 18 Q 20 -2 50 4 Q 80 -2 72 18 L 68 24 L 32 24 Z" fill="#ffffff" stroke="#161d1f" strokeWidth="2.5" />
          {/* Hat band */}
          <rect x="32" y="20" width="36" height="5" fill="#ffffff" stroke="#161d1f" strokeWidth="2" />
        </g>
      )}

      {accessory === 'horns' && (
        <g fill="#ba1a1a" stroke="#161d1f" strokeWidth="2.5">
          {/* Left horn */}
          <path d="M 26 18 Q 12 6 22 2 Q 22 10 32 14 Z" />
          {/* Right horn */}
          <path d="M 74 18 Q 88 6 78 2 Q 78 10 68 14 Z" />
        </g>
      )}

      {accessory === 'halo' && (
        <g>
          {/* Glow and angel halo */}
          <ellipse cx="50" cy="5" rx="22" ry="5" fill="none" stroke="#ffd700" strokeWidth="5.5" opacity="0.4" />
          <ellipse cx="50" cy="5" rx="22" ry="5" fill="none" stroke="#ffe16d" strokeWidth="3" />
        </g>
      )}

      {accessory === 'ninja' && (
        <g>
          {/* Headband cloth wrapping */}
          <path d="M 23 26 Q 50 31 77 26 L 75 35 Q 50 40 25 35 Z" fill="#1e293b" stroke="#0f172a" strokeWidth="2.5" />
          {/* Long flowy tie ribbons on the left side of the face */}
          <path d="M 23 30 Q 10 38 12 52 Q 18 45 23 35 Z" fill="#1e293b" stroke="#0f172a" strokeWidth="2" strokeLinecap="round" />
          <path d="M 24 32 Q 5 28 8 42 Q 13 36 21 34 Z" fill="#334155" stroke="#0f172a" strokeWidth="2" strokeLinecap="round" />
          {/* Silver forehead metal plate */}
          <path d="M 38 25 L 62 25 Q 64 25 64 27 L 64 33 Q 64 35 62 35 L 38 35 Q 36 35 36 33 L 36 27 Q 36 25 38 25 Z" fill="#cbd5e1" stroke="#0f172a" strokeWidth="2" />
          {/* Plate details (2 rivets + slash symbol) */}
          <circle cx="39" cy="30" r="1.2" fill="#475569" />
          <circle cx="61" cy="30" r="1.2" fill="#475569" />
          {/* Shinobi leaf/spiral slash symbol */}
          <path d="M 46 30 Q 50 27 54 30 Q 50 33 46 30" fill="none" stroke="#475569" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="44" y1="32" x2="56" y2="28" stroke="#475569" strokeWidth="1.5" strokeLinecap="round" />
        </g>
      )}
    </svg>
  );
}

export default function AvatarCustomizer({
  player,
  onUpdate,
  onClose,
  unlockedAccessories = ['none', 'party', 'horns', 'halo', 'ninja', 'crown', 'chef'], // default all available for fun customization
}: AvatarCustomizerProps) {
  
  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdate({
      ...player,
      name: e.target.value.slice(0, 12), // Limit to 12 chars
    });
  };

  const selectColor = (color: string) => {
    onUpdate({
      ...player,
      color,
      avatar: {
        ...player.avatar,
        faceColor: color,
      },
    });
  };

  const selectEye = (eyeType: Player['avatar']['eyeType']) => {
    onUpdate({
      ...player,
      avatar: {
        ...player.avatar,
        eyeType,
      },
    });
  };

  const selectMouth = (mouthType: Player['avatar']['mouthType']) => {
    onUpdate({
      ...player,
      avatar: {
        ...player.avatar,
        mouthType,
      },
    });
  };

  const selectAccessory = (accessory: Player['avatar']['accessory']) => {
    onUpdate({
      ...player,
      avatar: {
        ...player.avatar,
        accessory,
      },
    });
  };

  const randomize = () => {
    const randomColor = PRESET_COLORS[Math.floor(Math.random() * PRESET_COLORS.length)];
    const randomEye = EYE_TYPES[Math.floor(Math.random() * EYE_TYPES.length)];
    const randomMouth = MOUTH_TYPES[Math.floor(Math.random() * MOUTH_TYPES.length)];
    const filteredAcc = ACCESSORY_TYPES.filter(acc => unlockedAccessories.includes(acc));
    const randomAcc = filteredAcc[Math.floor(Math.random() * filteredAcc.length)] || 'none';

    onUpdate({
      ...player,
      color: randomColor,
      avatar: {
        faceColor: randomColor,
        eyeType: randomEye,
        mouthType: randomMouth,
        accessory: randomAcc,
      },
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in" id="avatar-customizer-modal">
      <div 
        className="w-full max-w-lg bg-white flex flex-col rounded-3xl border-[6px] border-[#0f172a] shadow-[12px_12px_0px_0px_rgba(15,23,42,1)] overflow-hidden bubbly-card scale-95 md:scale-100 transition-transform"
        id="avatar-customizer-container"
      >
        {/* Header */}
        <div className="bg-[#0f172a] p-4 flex justify-between items-center text-white border-b-4 border-primary">
          <h3 className="font-black text-xl uppercase tracking-tight flex items-center gap-2">
            <span className="material-symbols-outlined text-[24px]">palette</span>
            Customize {player.name}
          </h3>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/20 hover:bg-white/40 flex items-center justify-center transition border-2 border-white/40"
            title="Close"
            id="close-customizer-btn"
          >
            <span className="material-symbols-outlined text-sm font-bold">close</span>
          </button>
        </div>

        {/* Content body */}
        <div className="p-6 overflow-y-auto flex-grow max-h-[70vh] flex flex-col gap-6 scrollbar-thin bg-white">
          {/* Avatar Preview & Name Input */}
          <div className="flex flex-col sm:flex-row items-center gap-6 bg-stone-50 p-4 rounded-3xl border-4 border-primary shadow-[4px_4px_0px_0px_rgba(15,23,42,1)]">
            <div className="w-28 h-28 bg-white rounded-2xl flex items-center justify-center shadow-[4px_4px_0px_0px_rgba(15,23,42,1)] border-4 border-primary p-2 animate-bounce-slow shrink-0">
              {renderAvatarSvg(player.avatar, 90)}
            </div>
            
            <div className="flex-1 w-full flex flex-col gap-3">
              <label className="text-xs font-black text-primary uppercase tracking-wider">
                Toy Tag (Name)
              </label>
              <input
                type="text"
                value={player.name}
                onChange={handleNameChange}
                placeholder="Enter Wacky Name..."
                className="w-full px-4 py-3 rounded-2xl bg-white border-4 border-primary focus:outline-none text-xl font-black text-primary text-center sm:text-left shadow-[2px_2px_0px_0px_rgba(15,23,42,1)] transition-all font-sans"
                id={`player-name-input-${player.id}`}
              />
              
              <button
                onClick={randomize}
                className="w-full py-2.5 bg-[#0f172a] text-white rounded-2xl font-black flex items-center justify-center gap-2 border-4 border-primary shadow-[4px_4px_0px_0px_#f472b6] hover:translate-y-[-1px] transition-transform active:translate-x-[2px] active:translate-y-[2px] active:shadow-[2px_2px_0px_0px_#f472b6] uppercase text-xs tracking-wider"
                id="randomize-avatar-btn"
              >
                <span className="material-symbols-outlined text-lg">casino</span>
                Randomize Outfit
              </button>
            </div>
          </div>

          {/* Color Presets */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-black text-primary uppercase tracking-wider">
              Plastik Color
            </span>
            <div className="grid grid-cols-8 gap-2">
              {PRESET_COLORS.map((col) => (
                <button
                  key={col}
                  onClick={() => selectColor(col)}
                  className={`aspect-square rounded-full transition-transform active:scale-95 border-4 relative ${
                    player.avatar.faceColor === col 
                      ? 'scale-110 border-primary ring-2 ring-yellow-400' 
                      : 'border-[#0f172a]'
                  }`}
                  style={{ backgroundColor: col }}
                  title={col}
                  id={`color-btn-${col.replace('#', '')}`}
                />
              ))}
            </div>
          </div>

          {/* Eye Options */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-black text-primary uppercase tracking-wider">
              Crazy Peepers (Eyes)
            </span>
            <div className="grid grid-cols-5 gap-2">
              {EYE_TYPES.map((eye) => (
                <button
                  key={eye}
                  onClick={() => selectEye(eye)}
                  className={`bg-white border-3 py-2 rounded-2xl flex items-center justify-center transition font-black text-xs uppercase tracking-tight border-primary shadow-[2px_2px_0px_0px_#0f172a] ${
                    player.avatar.eyeType === eye 
                      ? 'bg-yellow-400 text-primary translate-y-[1px] shadow-[1px_1px_0px_0px_#0f172a]' 
                      : 'text-stone-600 hover:bg-stone-50'
                  }`}
                  id={`eye-option-${eye}`}
                >
                  <span>{eye}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Mouth Options */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-black text-primary uppercase tracking-wider">
              Snack Gobblers (Mouths)
            </span>
            <div className="grid grid-cols-5 gap-2">
              {MOUTH_TYPES.map((mouth) => (
                <button
                  key={mouth}
                  onClick={() => selectMouth(mouth)}
                  className={`bg-white border-3 py-2 rounded-2xl flex items-center justify-center transition font-black text-xs uppercase tracking-tight border-primary shadow-[2px_2px_0px_0px_#0f172a] ${
                    player.avatar.mouthType === mouth 
                      ? 'bg-yellow-400 text-primary translate-y-[1px] shadow-[1px_1px_0px_0px_#0f172a]' 
                      : 'text-stone-600 hover:bg-stone-50'
                  }`}
                  id={`mouth-option-${mouth}`}
                >
                  <span>{mouth}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Accessory option */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-black text-primary uppercase tracking-wider">
              Head Toppings (Accessories)
            </span>
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
              {ACCESSORY_TYPES.map((acc) => {
                const isUnlocked = unlockedAccessories.includes(acc);
                return (
                  <button
                    key={acc}
                    onClick={() => isUnlocked && selectAccessory(acc)}
                    disabled={!isUnlocked}
                    className={`bg-white border-3 py-2 rounded-2xl flex flex-col items-center justify-center gap-1 transition font-black text-[10px] uppercase tracking-tight border-primary shadow-[2px_2px_0px_0px_#0f172a] ${
                      !isUnlocked 
                        ? 'opacity-40 bg-stone-100 cursor-not-allowed text-stone-400 border-stone-300 shadow-none' 
                        : player.avatar.accessory === acc 
                        ? 'bg-yellow-400 text-primary translate-y-[1px] shadow-[1px_1px_0px_0px_#0f172a]' 
                        : 'text-stone-600 hover:bg-stone-50'
                    }`}
                    title={isUnlocked ? acc : 'Locked in shop'}
                    id={`accessory-option-${acc}`}
                  >
                    <span className="truncate max-w-[50px]">
                      {acc === 'none' ? 'None' : acc}
                    </span>
                    {!isUnlocked && <span className="material-symbols-outlined text-[12px] font-black">lock</span>}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Action Bottom Bar */}
        <div className="bg-stone-100 p-4 flex justify-end gap-2 border-t-4 border-primary">
          <button
            onClick={onClose}
            className="bg-yellow-400 hover:bg-yellow-500 text-primary font-black text-base tracking-wide px-8 py-3 rounded-2xl border-4 border-primary shadow-[4px_4px_0px_0px_#0f172a] active:translate-x-[2px] active:translate-y-[2px] active:shadow-[2px_2px_0px_0px_#0f172a] uppercase"
            id="done-customizer-btn"
          >
            MIGHTY DONE!
          </button>
        </div>
      </div>
    </div>
  );
}
