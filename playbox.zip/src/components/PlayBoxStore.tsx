import React from 'react';
import { Player, StoreItem } from '../types';
import playBoxAudio from '../utils/audio';

interface PlayBoxStoreProps {
  coins: number;
  onUnlockAccessory: (acc: string, cost: number) => void;
  unlockedList: string[];
}

const STORE_ITEMS: StoreItem[] = [
  { id: 'ninja', name: 'Ninja Headband', cost: 10, type: 'accessory', value: 'ninja', emoji: '🥷', unlocked: false },
  { id: 'chef', name: 'Master Chef Hat', cost: 20, type: 'accessory', value: 'chef', emoji: '👨‍🍳', unlocked: false },
  { id: 'crown', name: 'Golden King Crown', cost: 40, type: 'accessory', value: 'crown', emoji: '👑', unlocked: false },
  { id: 'halo', name: 'Holy Floating Halo', cost: 50, type: 'accessory', value: 'halo', emoji: '😇', unlocked: false },
];

export default function PlayBoxStore({
  coins,
  onUnlockAccessory,
  unlockedList,
}: PlayBoxStoreProps) {

  const handleBuy = (item: StoreItem) => {
    if (coins >= item.cost) {
      onUnlockAccessory(item.value, item.cost);
      playBoxAudio.playSuccess();
    } else {
      playBoxAudio.playFail();
    }
  };

  return (
    <div className="w-full flex flex-col gap-6 animate-fade-in" id="playbox-store-tab">
      {/* Coins Banner */}
      <div className="bg-white p-6 rounded-3xl border-4 border-primary flex flex-col sm:flex-row justify-between items-center gap-4 shadow-[8px_8px_0px_0px_rgba(15,23,42,1)] bubbly-card relative overflow-hidden">
        <div className="absolute top-[-20%] left-[-10%] w-36 h-36 bg-pink-400/20 rounded-full blur-xl pointer-events-none" />
        <div className="flex flex-col gap-1 text-center sm:text-left">
          <h3 className="font-black text-2xl text-primary leading-none uppercase tracking-tight">
            Plastik Cosmetic Shop 👑
          </h3>
          <p className="text-xs font-semibold text-slate-700 italic">
            Win minigames to harvest shiny gold coins! No real money required!
          </p>
        </div>
        
        <div className="flex items-center gap-2 bg-[#0f172a] px-4 py-2.5 rounded-2xl text-yellow-300 font-black text-lg border-4 border-primary shadow-[4px_4px_0px_0px_rgba(15,23,42,0.15)]">
          <span className="material-symbols-outlined text-[28px]" style={{ fontVariationSettings: "'FILL' 1" }}>monetization_on</span>
          <span>{coins} COINS</span>
        </div>
      </div>

      {/* Grid of Items */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {STORE_ITEMS.map((item) => {
          const isOwned = unlockedList.includes(item.value);
          const canAfford = coins >= item.cost;

          return (
            <div 
              key={item.id} 
              className={`bg-white border-4 p-5 rounded-3xl flex items-center justify-between gap-4 bubbly-card relative ${
                isOwned ? '!bg-emerald-50' : 'border-[#0f172a]'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-stone-50 rounded-2xl flex items-center justify-center text-3xl border-4 border-primary shadow-[2px_2px_0px_0px_rgba(15,23,42,1)] p-1">
                  {item.emoji}
                </div>
                <div className="flex flex-col">
                  <span className="font-black text-lg text-primary tracking-tight">
                    {item.name}
                  </span>
                  <span className="text-xs text-slate-500 font-bold capitalize">
                    {item.type} cosmetic
                  </span>
                </div>
              </div>

              {/* Purchase Trigger */}
              <div>
                {isOwned ? (
                  <div className="bg-emerald-100 text-emerald-800 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1 border-3 border-emerald-600 shadow-[2px_2px_0px_0px_rgba(16,185,129,0.2)]">
                    <span className="material-symbols-outlined text-sm font-bold">check_circle</span>
                    Owned
                  </div>
                ) : (
                  <button
                    onClick={() => handleBuy(item)}
                    disabled={!canAfford}
                    className={`px-4 py-2.5 rounded-2xl font-black flex items-center gap-1.5 text-xs uppercase tracking-tight transition-transform border-3 border-primary shadow-[3px_3px_0px_0px_#0f172a] ${
                      canAfford 
                        ? 'bg-yellow-400 text-primary active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_#0f172a]' 
                        : 'bg-stone-100 text-stone-400 cursor-not-allowed border-stone-300 shadow-none'
                    }`}
                  >
                    <span className="material-symbols-outlined text-sm">monetization_on</span>
                    {item.cost} Coins
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
