import { Award } from '../types';

interface PlayBoxAwardsProps {
  unlockedAwards: string[]; // list of award IDs already unlocked
}

const AWARDS_LIST: Award[] = [
  {
    id: 'fashion',
    title: 'Visual Fashion Master',
    desc: 'Wrote a brand new destiny of style by customizing your player avatar in the creator.',
    icon: 'palette',
    unlocked: false,
    condition: 'Open the customization panel and save an outfit.',
  },
  {
    id: 'memory_master',
    title: 'Ultimate Brain Slinger',
    desc: 'Found a perfect match in Crazy Memory game without missing a single turn!',
    icon: 'emoji_objects',
    unlocked: false,
    condition: 'Match 2 cards correctly in under 10 seconds.',
  },
  {
    id: 'survivor',
    title: 'Brave Chicken Flyer',
    desc: 'Floated higher and jumped quicker than any other fluffy chick on the track.',
    icon: 'sports_esports',
    unlocked: false,
    condition: 'Complete any survival run with a winning score.',
  },
  {
    id: 'poop_toucher',
    title: 'Plastik Pile Toucher',
    desc: 'Eew! You couldn\'t resist of tapping the hot steaming pile of poop in Reaction game.',
    icon: 'delete_outline',
    unlocked: false,
    condition: 'Tap on a poop obstacle during Whack-A-Poop.',
  },
  {
    id: 'sushibomb',
    title: 'Sashimi Juggler',
    desc: 'Dodged the seaweed dynamite by passing the spicy wasabi roll just in time.',
    icon: 'timer',
    unlocked: false,
    condition: 'Pass the hot potato sashimi in under 0.5s before the blast.',
  },
  {
    id: 'milestone_match',
    title: 'Tournament Gladiator',
    desc: 'Crowned as the supreme emperor of the PlayBox console compilation after 3 matches.',
    icon: 'workspace_premium',
    unlocked: false,
    condition: 'Win a total of 1 tournament match against robotic/humoid opponents.',
  },
];

export default function PlayBoxAwards({ unlockedAwards }: PlayBoxAwardsProps) {
  return (
    <div className="w-full flex flex-col gap-6 animate-fade-in" id="playbox-awards-tab">
      <div className="bg-slate-900 p-6 rounded-3xl border-4 border-primary flex flex-col gap-2 shadow-[6px_6px_0px_0px_rgba(15,23,42,1)] bubbly-card">
        <h3 className="font-black text-2xl text-yellow-300 tracking-tight leading-none uppercase">
          🏆 Mighty Hall of Fame
        </h3>
        <p className="text-xs font-semibold text-slate-300 italic">
          Achieve ridiculously funny milestones to show who is the true monarch of the toy box grid!
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {AWARDS_LIST.map((award) => {
          const isUnlocked = unlockedAwards.includes(award.id);

          return (
            <div 
              key={award.id} 
              className={`border-4 p-5 rounded-3xl flex items-start gap-4 transition-all bubbly-card border-[#0f172a] shadow-[4px_4px_0px_0px_rgba(15,23,42,1)] ${
                isUnlocked 
                  ? 'bg-white' 
                  : 'bg-stone-50 opacity-60'
              }`}
            >
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border-4 border-primary shadow-[2px_2px_0px_0px_rgba(15,23,42,1)] p-1 shrink-0 ${
                isUnlocked ? 'bg-yellow-400 text-primary' : 'bg-stone-200 text-stone-500'
              }`}>
                <span className="material-symbols-outlined text-2xl" style={{ fontVariationSettings: isUnlocked ? "'FILL' 1" : "'FILL' 0" }}>
                  {award.icon}
                </span>
              </div>

              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-black text-base text-primary uppercase tracking-tight">
                    {award.title}
                  </span>
                  {isUnlocked && (
                    <span className="bg-emerald-100 text-emerald-800 font-black text-[10px] px-2 py-0.5 rounded-lg border-2 border-emerald-600 uppercase shrink-0">
                      Unlocked
                    </span>
                  )}
                </div>
                <p className="text-xs font-medium text-slate-700 leading-relaxed">
                  {award.desc}
                </p>
                <div className="text-[11px] font-black text-blue-800 mt-1 flex items-center gap-1.5 bg-blue-50 px-2.5 py-1 rounded-xl border-2 border-blue-200">
                  <span className="material-symbols-outlined text-[14px]">info</span>
                  <span>How: {award.condition}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
