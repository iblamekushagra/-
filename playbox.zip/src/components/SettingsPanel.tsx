import { GameSettings, FpsCap, ResolutionScale, GameDifficulty } from '../types';

interface SettingsPanelProps {
  settings: GameSettings;
  onUpdate: (updated: GameSettings) => void;
  onClose: () => void;
}

export default function SettingsPanel({
  settings,
  onUpdate,
  onClose,
}: SettingsPanelProps) {
  
  const setFps = (fpsCap: FpsCap) => {
    onUpdate({ ...settings, fpsCap });
  };

  const setRes = (resolutionScale: ResolutionScale) => {
    onUpdate({ ...settings, resolutionScale });
  };

  const toggleSound = () => {
    onUpdate({ ...settings, soundEnabled: !settings.soundEnabled });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in" id="settings-panel-modal">
      <div 
        className="w-full max-w-md bg-white flex flex-col rounded-3xl border-[6px] border-[#0f172a] shadow-[12px_12px_0px_0px_rgba(15,23,42,1)] overflow-hidden bubbly-card scale-95 md:scale-100 transition-transform"
        id="settings-container"
      >
        {/* Header */}
        <div className="bg-[#0f172a] p-4 flex justify-between items-center text-white border-b-4 border-primary">
          <h3 className="font-black text-xl uppercase tracking-tight flex items-center gap-2">
            <span className="material-symbols-outlined text-[24px]">settings</span>
            Console Settings
          </h3>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/20 hover:bg-white/40 flex items-center justify-center transition border-2 border-white/40"
            id="close-settings-btn"
          >
            <span className="material-symbols-outlined text-sm font-bold">close</span>
          </button>
        </div>

        {/* Content body */}
        <div className="p-6 flex flex-col gap-6 bg-white overflow-y-auto max-h-[70vh]">
          {/* Sounds */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-black text-primary uppercase tracking-wider">
              Audio Synthesizer
            </span>
            <button
              onClick={toggleSound}
              className={`w-full py-3 px-4 rounded-2xl border-3 flex items-center justify-between transition-all border-primary shadow-[3px_3px_0px_0px_#0f172a] ${
                settings.soundEnabled 
                  ? 'bg-yellow-400 text-primary' 
                  : 'bg-white text-stone-500'
              }`}
              id="toggle-synth-audio-btn"
            >
              <span className="font-black text-sm flex items-center gap-2 uppercase tracking-tight">
                <span className="material-symbols-outlined">
                  {settings.soundEnabled ? 'volume_up' : 'volume_off'}
                </span>
                {settings.soundEnabled ? 'Synthesizer Active' : 'Synthesizer Muted'}
              </span>
              <div className={`w-12 h-6 rounded-full p-0.5 transition-colors border-2 border-primary ${settings.soundEnabled ? 'bg-[#0f172a]' : 'bg-stone-200'}`}>
                <div className={`w-4 h-4 rounded-full bg-white transition-transform ${settings.soundEnabled ? 'translate-x-[22px]' : 'translate-x-0'}`} />
              </div>
            </button>
          </div>

          {/* FPS Cap */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-black text-primary uppercase tracking-wider">
              PlayBox Engine FPS Limiter
            </span>
            <div className="grid grid-cols-4 gap-2">
              {([30, 60, 120, 'unlimited'] as FpsCap[]).map((fps) => (
                <button
                  key={fps}
                  onClick={() => setFps(fps)}
                  className={`border-3 py-2 rounded-2xl flex flex-col items-center justify-center font-black text-xs uppercase tracking-tight border-primary transition-all shadow-[2px_2px_0px_0px_#0f172a] ${
                    settings.fpsCap === fps 
                      ? 'bg-yellow-400 text-primary translate-y-[1px] shadow-[1px_1px_0px_0px_#0f172a]' 
                      : 'bg-white text-stone-600 hover:bg-stone-50'
                  }`}
                  id={`fps-cap-btn-${fps}`}
                >
                  <span>
                    {fps === 'unlimited' ? 'Max' : `${fps} FPS`}
                  </span>
                </button>
              ))}
            </div>
            <p className="text-[11px] text-slate-500 italic leading-relaxed font-semibold">
              FPS regulation caps the game loop interval dynamically for retro performance scaling.
            </p>
          </div>

          {/* Resolution scale */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-black text-primary uppercase tracking-wider">
              Simulated Display Resolution
            </span>
            <div className="grid grid-cols-3 gap-2">
              {(['low', 'medium', 'high'] as ResolutionScale[]).map((res) => (
                <button
                  key={res}
                  onClick={() => setRes(res)}
                  className={`border-3 py-2 rounded-2xl flex flex-col items-center justify-center font-black text-[10px] uppercase tracking-tighter border-primary transition-all shadow-[2px_2px_0px_0px_#0f172a] ${
                    settings.resolutionScale === res 
                      ? 'bg-yellow-400 text-primary translate-y-[1px] shadow-[1px_1px_0px_0px_#0f172a]' 
                      : 'bg-white text-stone-600 hover:bg-stone-50'
                  }`}
                  id={`res-scale-btn-${res}`}
                >
                  <span>
                    {res === 'low' && '🍕 Low-Fi'}
                    {res === 'medium' && '🍦 Standard'}
                    {res === 'high' && '⭐ Ultra 4K'}
                  </span>
                </button>
              ))}
            </div>
            <p className="text-[11px] text-slate-500 italic leading-relaxed font-semibold">
              Applies a post-process crisp pixel-scaling filter to mock specific system monitors.
            </p>
          </div>

          {/* Tournament Point limit */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-black text-primary uppercase tracking-wider">
              Mighty Points to Win Match
            </span>
            <div className="grid grid-cols-4 gap-2">
              {[1, 3, 5, 10].map((points) => (
                <button
                  key={points}
                  onClick={() => onUpdate({ ...settings, scoreLimit: points })}
                  className={`border-3 py-2 rounded-2xl flex flex-col items-center justify-center font-black text-[10px] uppercase tracking-tighter border-primary transition-all shadow-[2px_2px_0px_0px_#0f172a] ${
                    settings.scoreLimit === points 
                      ? 'bg-yellow-400 text-primary translate-y-[1px] shadow-[1px_1px_0px_0px_#0f172a]' 
                      : 'bg-white text-stone-600 hover:bg-stone-50'
                  }`}
                  id={`score-limit-btn-${points}`}
                >
                  <span>
                    {points} {points === 1 ? 'Rnd' : 'Rnds'}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Gameplay Difficulty */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-black text-primary uppercase tracking-wider">
              Gameplay Difficulty Level
            </span>
            <div className="grid grid-cols-3 gap-2">
              {(['easy', 'medium', 'hard'] as GameDifficulty[]).map((dif) => (
                <button
                  key={dif}
                  onClick={() => onUpdate({ ...settings, difficulty: dif })}
                  className={`border-3 py-2 rounded-2xl flex flex-col items-center justify-center font-black text-xs uppercase tracking-tight border-primary transition-all shadow-[2px_2px_0px_0px_#0f172a] ${
                    settings.difficulty === dif
                      ? 'bg-yellow-400 text-primary translate-y-[1px] shadow-[1px_1px_0px_0px_#0f172a]'
                      : 'bg-white text-stone-600 hover:bg-stone-50'
                  }`}
                  id={`difficulty-btn-${dif}`}
                >
                  <span className="font-extrabold text-[11px]">
                    {dif === 'easy' && '🟢 Easy'}
                    {dif === 'medium' && '🟡 Medium'}
                    {dif === 'hard' && '🔴 Hard'}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Action Bottom Bar */}
        <div className="bg-stone-100 p-4 flex justify-end gap-2 border-t-4 border-primary">
          <button
            onClick={onClose}
            className="bg-yellow-400 hover:bg-yellow-500 text-primary font-black text-xs tracking-wider px-8 py-3.5 rounded-2xl border-4 border-primary shadow-[4px_4px_0px_0px_#0f172a] active:translate-x-[2px] active:translate-y-[2px] active:shadow-[2px_2px_0px_0px_#0f172a] uppercase"
            id="done-settings-btn"
          >
            CONFIRM OPTIONS
          </button>
        </div>
      </div>
    </div>
  );
}
