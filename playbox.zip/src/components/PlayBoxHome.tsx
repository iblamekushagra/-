import React, { useState } from 'react';
import { Player, Minigame, GameSettings } from '../types';
import playBoxAudio from '../utils/audio';
import AvatarCustomizer, { renderAvatarSvg } from './AvatarCustomizer';

interface PlayBoxHomeProps {
  players: Player[];
  onUpdatePlayers: (updated: Player[]) => void;
  selectedCount: number;
  onSelectCount: (count: number) => void;
  onLaunchGame: (game: Minigame) => void;
  onOpenSettings: () => void;
  unlockedAccessories: string[];
  activeBgm: boolean;
  onToggleBgm: () => void;
}

const MINIGAMES_LIST: Minigame[] = [
  {
    id: 'memory',
    name: 'Crazy Memory Match',
    emoji: '🃏',
    desc: 'Flip card by card under turn constraints to match wacky toys. Simple, beautiful brain teaser!',
    color: '#ca8a04',
    bgColor: 'bg-amber-500/10 border-amber-500/25',
  },
  {
    id: 'chicken_jump',
    name: 'Screaming Chicken Jump',
    emoji: '🐥',
    desc: 'Bouncy chickens jumping over sliding giant hurdles, survivor takes all of the glory!',
    color: '#00658d',
    bgColor: 'bg-sky-500/10 border-sky-500/25',
  },
  {
    id: 'sashimi',
    name: 'The Last Sashimi',
    emoji: '🌶️',
    desc: 'Hot potato panic! Pass the ticking wasabi sashimi before it blows and slaps your face!',
    color: '#b91c1c',
    bgColor: 'bg-red-500/10 border-red-500/25',
  },
  {
    id: 'cooper_kick',
    name: 'Soccer Pool',
    emoji: '⚽',
    desc: 'Dash, pop, and bumper-kick the balls into goals to score glorious match points!',
    color: '#16a34a',
    bgColor: 'bg-emerald-500/10 border-emerald-500/25',
  },
  {
    id: 'chili_chomp',
    name: 'Chili Chomp',
    emoji: '🍬',
    desc: 'Gobble delicious sweets falling down. But steer clear of burning red-hot chilies!',
    color: '#7c3aed',
    bgColor: 'bg-purple-500/10 border-purple-500/25',
  },
  {
    id: 'flappy',
    name: 'Flappy Balloon',
    emoji: '🎈',
    desc: 'Floating balloons try to survive through revolving obstacles. Tap to flap and fly!',
    color: '#db2777',
    bgColor: 'bg-pink-500/10 border-pink-500/25',
  },
  {
    id: 'spike',
    name: 'Spike Squeeze',
    emoji: '⚙️',
    desc: 'Move left & right strategically to dodge crushing metal spikes falling from the sky.',
    color: '#ea580c',
    bgColor: 'bg-orange-500/10 border-orange-500/25',
  },
  {
    id: 'dino',
    name: 'Dino Sleep React',
    emoji: '🦖',
    desc: 'Dino sleeps. If it wakes up and roars, react instantly! Click early and get penalized.',
    color: '#0d9488',
    bgColor: 'bg-teal-500/10 border-teal-500/25',
  },
  {
    id: 'poop',
    name: 'Whack-A-Poop',
    emoji: '🍩',
    desc: 'Cookies and rainbows are popping. Click them quickly, but eew, dont tap the steaming poop!',
    color: '#ca8a04',
    bgColor: 'bg-yellow-500/10 border-yellow-500/25',
  },
  {
    id: 'sumo',
    name: 'Sumo Slap poppers',
    emoji: '🥊',
    desc: 'Squeezing contest! Rapidly smash your button to expand and push others out of the bubble ring!',
    color: '#ba1a1a',
    bgColor: 'bg-[#ffdad6]/40 border-error/25',
  },
  {
    id: 'tower',
    name: 'Wobbly Tower Build',
    emoji: '🧱',
    desc: 'Slide and drop bricks perfectly in alignment to build the highest wobbly towers!',
    color: '#8b5cf6',
    bgColor: 'bg-violet-500/10 border-violet-500/25',
  },
  {
    id: 'math',
    name: 'Wacky Quick Math',
    emoji: '🧮',
    desc: 'Verify quirky high-speed arithmetic equations under immense ticking time pressure!',
    color: '#10b981',
    bgColor: 'bg-emerald-500/10 border-emerald-500/25',
  },
  {
    id: 'train',
    name: 'Sushi Train Grab',
    emoji: '🍣',
    desc: 'Tap your colored plates perfectly on target as the conveyor sushi train speeds by!',
    color: '#eab308',
    bgColor: 'bg-yellow-500/10 border-yellow-500/25',
  },
  {
    id: 'space',
    name: 'Rocket Meteor Drift',
    emoji: '🚀',
    desc: 'Steer your fluffy cosmetic spaceships to dodge space meteors in a cosmic shower!',
    color: '#0284c7',
    bgColor: 'bg-[#a5f3fc]/40 border-sky-500/25',
  },
  {
    id: 'burger',
    name: 'Chef Burger Stack',
    emoji: '🍔',
    desc: 'Catch falling burger ingredients in pure perfect recipe orders to construct mega-meals!',
    color: '#ca8a04',
    bgColor: 'bg-amber-500/10 border-amber-500/25',
  },
  {
    id: 'pop',
    name: 'Balloon Pop Rush',
    emoji: '🎈',
    desc: 'Frantic party pumping clicker! Rapid tap to inflate your balloon until it pops first!',
    color: '#a855f7',
    bgColor: 'bg-purple-500/10 border-purple-500/25',
  },
  {
    id: 'slash',
    name: 'Mega Fruit Chop',
    emoji: '🍉',
    desc: 'Chop and slice flying juicy tropical fruits. Dodge high-hazardous explosive black bombs!',
    color: '#22c55e',
    bgColor: 'bg-green-500/10 border-green-500/25',
  },
  {
    id: 'simon',
    name: 'Glow Simon Sounds',
    emoji: '🧠',
    desc: 'Memorize and playback the funny glowing light patterns of cute squishy jelly keys!',
    color: '#ea580c',
    bgColor: 'bg-orange-500/10 border-orange-500/25',
  },
];

export default function PlayBoxHome({
  players,
  onUpdatePlayers,
  selectedCount,
  onSelectCount,
  onLaunchGame,
  onOpenSettings,
  unlockedAccessories,
  activeBgm,
  onToggleBgm,
}: PlayBoxHomeProps) {
  
  const [editingPlayer, setEditingPlayer] = useState<Player | null>(null);

  const startEditPlayer = (p: Player) => {
    setEditingPlayer(p);
  };

  const saveEditedPlayer = (updated: Player) => {
    setEditingPlayer(updated);
    const nextList = players.map(p => p.id === updated.id ? updated : p);
    onUpdatePlayers(nextList);
  };

  const handleLaunchWithIntro = (game: Minigame) => {
    // Start music and mount game screen
    playBoxAudio.playWhistle();
    onLaunchGame(game);
  };

  return (
    <div className="w-full flex flex-col gap-6 animate-fade-in" id="playbox-home-tab">
      
      {/* Hero Illustration block */}
      <div className="w-full h-48 md:h-64 rounded-3xl bg-white flex items-center justify-center bubbly-card relative overflow-hidden group">
        {/* Soft floating background shapes */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#00baff]/15 to-pink-400/20 opacity-80 pointer-events-none" />
        
        {/* Adorable SVG illustration recreating the physical toy box bounce playground */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 200" preserveAspectRatio="xMidYMid slice" id="hero-playground-svg">
          <defs>
            <linearGradient id="bubble-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ffd700" />
              <stop offset="100%" stopColor="#ffd16d" />
            </linearGradient>
            <linearGradient id="cloud-grad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.85" />
              <stop offset="100%" stopColor="#e8eff1" stopOpacity="0.5" />
            </linearGradient>
          </defs>
          
          {/* Clouds */}
          <path d="M 30,50 Q 50,20 80,45 Q 110,20 130,50 Q 150,80 120,80 L 40,80" fill="url(#cloud-grad)" />
          <path d="M 280,30 Q 300,5 320,30 Q 340,5 360,30 Q 380,50 350,55 L 290,55" fill="url(#cloud-grad)" />

          {/* Squeezed 3D Balls bouncing */}
          <circle cx="210" cy="140" r="32" fill="#38bdf8" opacity="0.8" />
          <circle cx="205" cy="135" r="12" fill="rgba(255,255,255,0.4)" />
          
          <circle cx="150" cy="80" r="24" fill="#f472b6" opacity="0.85" />
          <circle cx="145" cy="75" r="8" fill="rgba(255,255,255,0.4)" />
          
          <circle cx="260" cy="90" r="28" fill="#4ade80" opacity="0.7" />
          
          {/* Centered bouncing figure with googly eyes */}
          <g className="animate-bounce" id="bouncing-chick-figure">
            <ellipse cx="200" cy="90" rx="35" ry="38" fill="url(#bubble-grad)" stroke="#0f172a" strokeWidth="4" />
            <circle cx="188" cy="82" r="6" fill="#0f172a" />
            <circle cx="212" cy="82" r="6" fill="#0f172a" />
            <path d="M 190,105 Q 200,115 210,105" fill="none" stroke="#0f172a" strokeWidth="4" strokeLinecap="round" />
            {/* Soft pink blush */}
            <circle cx="178" cy="92" r="5" fill="#f472b6" />
            <circle cx="222" cy="92" r="5" fill="#f472b6" />
          </g>
        </svg>

        <div className="absolute inset-0 flex items-center justify-center">
          <h2 className="text-xl md:text-3xl font-black italic uppercase tracking-tight text-white bg-[#0f172a] px-6 py-3 rounded-2xl border-4 border-[#0f172a] shadow-[4px_4px_0px_0px_#f472b6] transform -rotate-2 select-none">
            Choose Players!
          </h2>
        </div>
      </div>

      {/* Player Selection Grid */}
      <section className="w-full grid grid-cols-2 md:grid-cols-4 gap-4" id="player-grid">
        
        {/* 1 Player */}
        <button 
          onClick={() => onSelectCount(1)}
          className={`bubbly-card p-6 flex flex-col items-center justify-center gap-4 transition-all duration-150 h-40 ${
            selectedCount === 1 
              ? '!bg-yellow-400 !translate-x-[2px] !translate-y-[2px] !shadow-[2px_2px_0px_0px_#0f172a]' 
              : '!bg-white hover:bg-slate-50'
          }`}
          id="select-1-player-btn"
        >
          <div className="w-14 h-14 rounded-2xl bg-sky-200 border-4 border-primary text-primary flex items-center justify-center shadow-[2px_2px_0px_0px_#0f172a]">
            <span className="material-symbols-outlined text-[36px]" style={{ fontVariationSettings: "'FILL' 1" }}>person</span>
          </div>
          <span className="font-black text-lg text-primary uppercase tracking-tight">
            1 Player
          </span>
        </button>

        {/* 2 Players */}
        <button 
          onClick={() => onSelectCount(2)}
          className={`bubbly-card p-6 flex flex-col items-center justify-center gap-4 transition-all duration-150 h-40 ${
            selectedCount === 2 
              ? '!bg-yellow-400 !translate-x-[2px] !translate-y-[2px] !shadow-[2px_2px_0px_0px_#0f172a]' 
              : '!bg-white hover:bg-slate-50'
          }`}
          id="select-2-players-btn"
        >
          <div className="flex -space-x-3">
            <div className="w-11 h-11 rounded-xl bg-sky-200 border-4 border-primary text-primary flex items-center justify-center shadow-[2px_2px_0px_0px_#0f172a]">
              <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>person</span>
            </div>
            <div className="w-11 h-11 rounded-xl bg-pink-200 border-4 border-primary text-primary flex items-center justify-center shadow-[2px_2px_0px_0px_#0f172a]">
              <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>person</span>
            </div>
          </div>
          <span className="font-black text-lg text-primary uppercase tracking-tight">
            2 Players
          </span>
        </button>

        {/* 3 Players */}
        <button 
          onClick={() => onSelectCount(3)}
          className={`bubbly-card p-6 flex flex-col items-center justify-center gap-4 transition-all duration-150 h-40 ${
            selectedCount === 3 
              ? '!bg-yellow-400 !translate-x-[2px] !translate-y-[2px] !shadow-[2px_2px_0px_0px_#0f172a]' 
              : '!bg-white hover:bg-slate-50'
          }`}
          id="select-3-players-btn"
        >
          <div className="flex -space-x-4">
            <div className="w-10 h-10 rounded-xl bg-sky-200 border-4 border-primary text-primary flex items-center justify-center shadow-[2px_2px_0px_0px_#0f172a]">
              <span className="material-symbols-outlined text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>person</span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-pink-200 border-4 border-primary text-primary flex items-center justify-center shadow-[2px_2px_0px_0px_#0f172a]">
              <span className="material-symbols-outlined text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>person</span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-green-200 border-4 border-primary text-primary flex items-center justify-center shadow-[2px_2px_0px_0px_#0f172a]">
              <span className="material-symbols-outlined text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>person</span>
            </div>
          </div>
          <span className="font-black text-lg text-primary uppercase tracking-tight">
            3 Players
          </span>
        </button>

        {/* 4 Players */}
        <button 
          onClick={() => onSelectCount(4)}
          className={`bubbly-card p-6 flex flex-col items-center justify-center gap-4 transition-all duration-150 h-40 ${
            selectedCount === 4 
              ? '!bg-yellow-400 !translate-x-[2px] !translate-y-[2px] !shadow-[2px_2px_0px_0px_#0f172a]' 
              : '!bg-white hover:bg-slate-50'
          }`}
          id="select-4-players-btn"
        >
          <div className="grid grid-cols-2 gap-1 w-11 h-11 rotate-45">
            <div className="w-5 h-5 rounded-full bg-secondary border-2 border-primary shadow-sm" />
            <div className="w-5 h-5 rounded-full bg-tertiary border-2 border-primary shadow-sm" />
            <div className="w-5 h-5 rounded-full bg-error border-2 border-primary shadow-sm" />
            <div className="w-5 h-5 rounded-full bg-green-400 border-2 border-primary shadow-sm" />
          </div>
          <span className="font-black text-lg text-primary uppercase tracking-tight">
            4 Players
          </span>
        </button>
      </section>

      {/* Avatar customization quick launch list */}
      <section className="bg-white p-5 rounded-3xl border-4 border-primary shadow-[6px_6px_0px_0px_rgba(15,23,42,1)] flex flex-col gap-4">
        <h3 className="font-black text-lg text-primary uppercase tracking-tight flex items-center gap-2">
          <span className="bg-pink-400 p-1.5 rounded-xl border-3 border-primary text-sm flex items-center justify-center">🌺</span>
          Customize Current Players
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3" id="player-customization-slots">
          {players.slice(0, selectedCount).map((p) => (
            <div 
              key={p.id} 
              className="bg-stone-50 p-3 rounded-2xl border-4 border-primary flex items-center justify-between gap-4 shadow-[4px_4px_0px_0px_rgba(15,23,42,1)]"
              id={`custom-slot-player-${p.id}`}
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center border-3 border-primary p-1 shadow-[2px_2px_0px_0px_rgba(15,23,42,1)]">
                  {renderAvatarSvg(p.avatar, 36)}
                </div>
                <div className="flex flex-col">
                  <span className="font-black text-sm text-primary leading-tight">{p.name}</span>
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">Player {p.id}</span>
                </div>
              </div>

              <button
                onClick={() => startEditPlayer(p)}
                className="px-3 py-1.5 bg-yellow-400 hover:bg-yellow-500 text-primary text-xs font-black rounded-xl border-3 border-primary shadow-[2px_2px_0px_0px_#0f172a] active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_#0f172a] uppercase tracking-tight"
                id={`customize-avatar-btn-p${p.id}`}
              >
                Outfit Creator
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Mini-Games Carousel Compilation */}
      <section className="flex flex-col gap-4" id="minigames-selection-carousel">
        <div className="flex flex-col gap-0.5">
          <h3 className="font-black text-2xl tracking-tight text-primary uppercase leading-tight bg-slate-900 text-white p-3 text-center rounded-2xl border-4 border-primary shadow-[4px_4px_0px_0px_#0f172a]">
            Mini Games (20)
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {MINIGAMES_LIST.map((game) => (
            <div 
              key={game.id}
              className={`p-4 rounded-3xl flex flex-col justify-between gap-4 bubbly-card transition-all duration-150`}
              style={{ backgroundColor: game.id === 'memory' ? '#f472b6' : '#ffffff' }}
              id={`minigame-card-${game.id}`}
            >
              <div className="flex items-start gap-4">
                <span className="text-4xl filter drop-shadow select-none bg-stone-50 border-3 border-primary p-1.5 rounded-2xl shadow-[2px_2px_0px_0px_#0f172a]">{game.emoji}</span>
                <div className="flex flex-col gap-1">
                  <h4 className="font-black text-lg text-primary uppercase tracking-tight leading-none">{game.name}</h4>
                  <p className="text-xs font-medium text-slate-700 leading-relaxed">
                    {game.desc}
                  </p>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={() => handleLaunchWithIntro(game)}
                  className="bg-yellow-400 hover:bg-yellow-500 hover:scale-102 active:translate-y-0.5 text-primary font-black text-xs leading-none tracking-widest px-4 py-2.5 rounded-xl flex items-center gap-1.5 border-3 border-primary shadow-[3px_3px_0px_0px_#0f172a]"
                  id={`launch-game-btn-${game.id}`}
                >
                  <span className="material-symbols-outlined text-sm font-bold">play_circle</span>
                  CHOOSE
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Editing dialog */}
      {editingPlayer && (
        <AvatarCustomizer
          player={editingPlayer}
          onUpdate={saveEditedPlayer}
          onClose={() => setEditingPlayer(null)}
          unlockedAccessories={unlockedAccessories}
        />
      )}
    </div>
  );
}
