import React, { useState, useEffect, useRef } from 'react';
import { Player } from '../types';
import playBoxAudio from '../utils/audio';
import { renderAvatarSvg } from './AvatarCustomizer';

interface MinigameProps {
  players: Player[];
  onWin: (winnerId: number) => void;
  onUnlock: (awardId: string) => void;
}

// =========================================================================
// 11. MINIGAME: WOBBLY TOWER BUILD (id: 'tower')
// =========================================================================
export function WobblyTowerGame({ players, onWin, onUnlock }: MinigameProps) {
  const [positions, setPositions] = useState<Record<number, number>>(() => {
    // Current horizontal animation position of the drifting block for each player (0 to 100)
    const p: Record<number, number> = {};
    players.forEach(pl => p[pl.id] = 10);
    return p;
  });
  const [direction, setDirection] = useState<Record<number, number>>(() => {
    const d: Record<number, number> = {};
    players.forEach(pl => d[pl.id] = 1.5);
    return d;
  });
  const [stacks, setStacks] = useState<Record<number, number[]>>(() => {
    // Stores stacked horizontal offsets (e.g. 50 is perfect center)
    const s: Record<number, number[]> = {};
    players.forEach(pl => s[pl.id] = [50]); // base stack starts at center
    return s;
  });
  const [activeOffset, setActiveOffset] = useState<Record<number, number>>(() => {
    const a: Record<number, number> = {};
    players.forEach(pl => a[pl.id] = 50);
    return a;
  });
  const [feedback, setFeedback] = useState<Record<number, string>>(() => {
    const f: Record<number, string> = {};
    players.forEach(pl => f[pl.id] = '');
    return f;
  });
  const [cooldowns, setCooldowns] = useState<Record<number, boolean>>({});

  // Slide animation loop
  useEffect(() => {
    const interval = setInterval(() => {
      setPositions(prev => {
        const next = { ...prev };
        players.forEach(pl => {
          let pos = prev[pl.id] + direction[pl.id];
          if (pos >= 90) {
            pos = 90;
            setDirection(d => ({ ...d, [pl.id]: -Math.abs(d[pl.id]) }));
          } else if (pos <= 10) {
            pos = 10;
            setDirection(d => ({ ...d, [pl.id]: Math.abs(d[pl.id]) }));
          }
          next[pl.id] = pos;
        });
        return next;
      });
    }, 20);

    return () => clearInterval(interval);
  }, [direction, players]);

  const snapStack = (pId: number) => {
    if (cooldowns[pId]) return;

    setCooldowns(curr => ({ ...curr, [pId]: true }));
    setTimeout(() => {
      setCooldowns(curr => ({ ...curr, [pId]: false }));
    }, 600);

    const currentPos = positions[pId];
    const prevStack = stacks[pId];
    const lastTarget = prevStack[prevStack.length - 1];
    
    // Check distance between current moving block and previous stack block
    const offsetDistance = Math.abs(currentPos - lastTarget);

    if (offsetDistance < 15) {
      // SUCCESS STACK!
      playBoxAudio.playSuccess();
      // Apply a small centering correction factor (0.75 clamp) so subtle misadjustments are tolerated
      const adjustedOffset = lastTarget + (currentPos - lastTarget) * 0.75;
      const nextStacks = [...prevStack, adjustedOffset];
      setStacks(curr => ({ ...curr, [pId]: nextStacks }));
      setFeedback(curr => ({ ...curr, [pId]: offsetDistance < 4.5 ? 'PERFECT! 🎯' : 'STEADY!' }));
      
      if (nextStacks.length - 1 >= 20) {
        onUnlock('survivor');
        setTimeout(() => onWin(pId), 400);
      }
    } else {
      // MISSED SLIDE PENALTY
      playBoxAudio.playSplat();
      setFeedback(curr => ({ ...curr, [pId]: 'WOBBLE OUT! ⚠️' }));
    }

    setTimeout(() => {
      setFeedback(curr => ({ ...curr, [pId]: '' }));
    }, 1000);
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-violet-950/20" id="wobbly-tower-level">
      <div className="flex justify-around bg-black/45 py-2 px-4 rounded-xl text-xs" id="tower-scorecard">
        {players.map(p => (
          <span key={p.id} className="font-semibold text-white">
            {p.name}: <b className="text-yellow-300">Height {(stacks[p.id]?.length || 1) - 1}/20</b>
          </span>
        ))}
      </div>

      {/* Building stages columns side-by-side */}
      <div className="flex-grow grid grid-cols-2 md:grid-cols-4 gap-4 p-2 items-end max-w-2xl mx-auto w-full">
        {players.map(p => {
          const currentPos = positions[p.id];
          const stackList = stacks[p.id] || [];
          const textFeedback = feedback[p.id];

          return (
            <div key={p.id} className="h-full flex flex-col justify-end bg-black/30 rounded-2xl p-2 border border-white/10 relative overflow-hidden">
              {/* Feedback text bubble overlay */}
              {textFeedback && (
                <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-yellow-400 text-primary font-black text-[10px] px-2 py-1 rounded-lg border-2 border-primary rotate-[-4deg] animate-scale-up z-10 w-24 text-center">
                  {textFeedback}
                </div>
              )}

              {/* Player Identifier */}
              <div className="absolute top-2 left-2 flex items-center gap-1.5 opacity-80">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: p.color }} />
                <span className="text-[10px] uppercase font-bold text-white tracking-widest leading-none truncate max-w-[50px]">{p.name}</span>
              </div>

              {/* Drifting Sliding block indicator */}
              <div className="w-full h-8 relative border-b border-white/10 bg-white/5 mb-6">
                <div 
                  className="w-8 h-6 rounded border-2 border-primary shadow-sm absolute top-1 transition-all duration-75"
                  style={{ left: `${currentPos}%`, transform: 'translateX(-50%)', backgroundColor: p.color }}
                />
              </div>

              {/* Tower Stack column container */}
              <div className="flex flex-col-reverse items-center justify-start overflow-hidden flex-grow relative max-h-[160px] pb-2">
                {stackList.map((offset, idx) => (
                  <div 
                    key={idx}
                    className="h-5 rounded border-2 border-[#0f172a] shadow transition-all"
                    style={{ 
                      width: '40px', 
                      marginLeft: `${(offset - 50) * 1.5}px`,
                      backgroundColor: p.color,
                      opacity: 1 - (stackList.length - idx) * 0.12
                    }}
                  />
                ))}
              </div>

              {/* Player push-trigger */}
              <button
                onClick={() => snapStack(p.id)}
                className="w-full mt-2 py-2 text-xs font-black uppercase text-primary bg-yellow-400 border-b-4 border-[#0f172a] hover:bg-yellow-500 rounded-xl"
                id={`tower-stack-btn-${p.id}`}
              >
                STACK!
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// =========================================================================
// 12. MINIGAME: WACKY QUICK MATH (id: 'math')
// =========================================================================
export function WackyMathGame({ players, onWin, onUnlock }: MinigameProps) {
  const [num1, setNum1] = useState(3);
  const [num2, setNum2] = useState(5);
  const [answer, setAnswer] = useState(8);
  const [isCorrectVal, setIsCorrectVal] = useState(true);
  const [scores, setScores] = useState<Record<number, number>>(() => {
    const s: Record<number, number> = {};
    players.forEach(p => s[p.id] = 0);
    return s;
  });

  const nextEquation = () => {
    const n1 = Math.floor(Math.random() * 9) + 1;
    const n2 = Math.floor(Math.random() * 9) + 1;
    const makeTrue = Math.random() > 0.5;
    const res = makeTrue ? (n1 + n2) : (n1 + n2 + (Math.random() > 0.5 ? 1 : -1));
    setNum1(n1);
    setNum2(n2);
    setAnswer(res);
    setIsCorrectVal(makeTrue);
  };

  const handleAnswer = (pId: number, playerChoice: boolean) => {
    if (playerChoice === isCorrectVal) {
      // CORRECT ANSWER!
      playBoxAudio.playSuccess();
      const nextScore = (scores[pId] || 0) + 1;
      setScores(curr => ({ ...curr, [pId]: nextScore }));
      
      if (nextScore >= 5) {
        onUnlock('memory_master');
        setTimeout(() => onWin(pId), 400);
      }
    } else {
      // INCORRECT Penalty
      playBoxAudio.playFail();
      setScores(curr => ({ ...curr, [pId]: Math.max(0, curr[pId] - 1) }));
    }
    nextEquation();
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-emerald-950/20" id="wacky-math-level">
      <div className="flex justify-around bg-black/45 py-2 px-4 rounded-xl text-xs" id="math-scorecard">
        {players.map(p => (
          <span key={p.id} className="font-semibold text-white">
            {p.name}: <b className="text-[#4ade80]">{scores[p.id]}/5 Points</b>
          </span>
        ))}
      </div>

      {/* Equation display board */}
      <div className="flex-grow flex flex-col justify-center items-center py-6 select-none relative" id="math-stage">
        <div className="w-64 h-32 bg-white rounded-3xl border-4 border-primary shadow-[6px_6px_0px_0px_rgba(15,23,42,1)] flex flex-col justify-center items-center p-4">
          <span className="text-[10px] font-black uppercase text-slate-500 tracking-wider">MIGHTY EQUATION</span>
          <h2 className="text-4xl font-black text-primary tracking-tight font-mono mt-1">
            {num1} + {num2} = {answer}
          </h2>
        </div>
      </div>

      {/* Button deck controls side-by-side */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-black/30 p-3 rounded-b-2xl border border-white/10">
        {players.map(p => (
          <div key={p.id} className="flex flex-col gap-1 items-center bg-white/5 p-1.5 rounded-xl border border-white/5">
            <span className="text-[10px] font-sans font-black uppercase text-yellow-300 truncate max-w-[70px]">{p.name}</span>
            <div className="flex gap-2 w-full">
              <button
                onClick={() => handleAnswer(p.id, true)}
                className="flex-grow py-2.5 text-xs font-black text-white bg-green-500 rounded-xl hover:bg-green-600 border-b-4 border-green-700 uppercase"
                id={`math-true-btn-${p.id}`}
              >
                ✔ YES
              </button>
              <button
                onClick={() => handleAnswer(p.id, false)}
                className="flex-grow py-2.5 text-xs font-black text-white bg-red-500 rounded-xl hover:bg-red-600 border-b-4 border-red-700 uppercase"
                id={`math-false-btn-${p.id}`}
              >
                ✘ NO
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// =========================================================================
// 13. MINIGAME: LASER BEAM DODGE (id: 'laser')
// =========================================================================
export function LaserDodgeGame({ players, onWin, onUnlock }: MinigameProps) {
  const [laserY, setLaserY] = useState(50); // percentage height of flying laser
  const [laserSpeed, setLaserSpeed] = useState(1);
  const [laserActive, setLaserActive] = useState(true);
  
  // Players stance states: 'neutral' | 'jumping' | 'ducking'
  const [stances, setStances] = useState<Record<number, 'neutral' | 'jumping' | 'ducking'>>(() => {
    const s: Record<number, 'neutral' | 'jumping' | 'ducking'> = {};
    players.forEach(p => s[p.id] = 'neutral');
    return s;
  });

  const [durability, setDurability] = useState<Record<number, number>>(() => {
    const d: Record<number, number> = {};
    players.forEach(p => d[p.id] = 3); // starts with 3 hearts of electronic lives
    return d;
  });

  // Laser horizontal drift
  const [laserX, setLaserX] = useState(105);

  useEffect(() => {
    const tick = setInterval(() => {
      setLaserX(prev => {
        if (prev <= -10) {
          // Reset laser scan
          playBoxAudio.playWhistle();
          setLaserY(Math.random() > 0.5 ? 25 : 75); // 25: Jump over, 75: Duck under
          setLaserSpeed(s => Math.min(s + 0.1, 2.8));
          return 110;
        }
        return prev - (1.6 * laserSpeed);
      });
    }, 20);

    return () => clearInterval(tick);
  }, [laserSpeed]);

  // Damage trigger detection when laser passes player line (around 20% mark)
  useEffect(() => {
    if (laserX >= 15 && laserX <= 30) {
      players.forEach(p => {
        const stance = stances[p.id];
        const isJumpLaser = laserY === 75; // high laser -> duck under (neutral gets hit)
        const isLowLaser = laserY === 25; // low laser -> jump over

        let hit = false;
        if (isLowLaser && stance !== 'jumping') {
          hit = true;
        } else if (isJumpLaser && stance !== 'ducking') {
          hit = true;
        }

        if (hit) {
          setDurability(curr => {
            if (curr[p.id] <= 0) return curr;
            const nextL = curr[p.id] - 1;
            if (nextL === 0) {
              playBoxAudio.playExplosion();
              // Check surviving contestants
              const alive = Object.entries(curr).filter(([id, lives]) => Number(id) !== p.id && (lives as number) > 0);
              if (alive.length === 1) {
                onUnlock('survivor');
                setTimeout(() => onWin(Number(alive[0][0])), 500);
              } else if (alive.length === 0) {
                setTimeout(() => onWin(players[0].id), 500); // safety fallback
              }
            } else {
              playBoxAudio.playSplat();
            }
            return { ...curr, [p.id]: nextL };
          });
        }
      });
    }
  }, [laserX, laserY, stances, players]);

  const changeStance = (pId: number, nextStance: 'jumping' | 'ducking') => {
    if (durability[pId] <= 0) return;
    playBoxAudio.playJump();
    setStances(curr => ({ ...curr, [pId]: nextStance }));
    setTimeout(() => {
      setStances(curr => ({ ...curr, [pId]: 'neutral' }));
    }, 450);
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-zinc-950/20" id="laser-dodge-level">
      <div className="flex justify-around bg-black/45 py-2 px-4 rounded-xl text-xs" id="laser-scorecard">
        {players.map(p => (
          <span key={p.id} className="font-semibold text-white flex items-center gap-1">
            {p.name}: <b className="text-red-400 font-black">{'❤️'.repeat(Math.max(0, durability[p.id] || 0))}</b>
          </span>
        ))}
      </div>

      {/* Laser threat screen stage */}
      <div className="flex-grow flex items-center justify-between p-4 relative h-48 select-none" id="laser-stage">
        <div className="w-full h-full border-4 border-white/20 bg-black/45 rounded-3xl relative overflow-hidden flex items-end justify-around pb-6">
          
          <span className="absolute top-2 left-1/2 -translate-x-1/2 text-[10px] font-mono uppercase bg-black/60 p-2 rounded tracking-widest text-red-500 animate-pulse">
            🚨 JUMP OVER LOWS, DUCK UNDER HIGHS!
          </span>

          {/* Drifting horizontal neon laser */}
          <div 
            className="absolute right-0 h-4 border-t-4 border-b-4 shadow-[0_0_15px_#f43f5e] transition-all duration-75 flex items-center"
            style={{ 
              width: '100%', 
              transform: `translateX(${-100 + laserX}%)`, 
              top: `${laserY}%`,
              borderColor: laserY === 25 ? '#38bdf8' : '#f43f5e',
              backgroundColor: laserY === 25 ? 'rgba(56,189,248,0.2)' : 'rgba(244,63,94,0.2)'
            }}
          >
            <span className="text-[10px] font-black uppercase text-white pl-4 tracking-widest leading-none">
              ⚠️ DODGE {laserY === 25 ? 'LOW' : 'HIGH'}
            </span>
          </div>

          {/* Active Player Stands */}
          {players.map(p => {
            const stance = stances[p.id];
            const hp = durability[p.id];
            if (hp <= 0) {
              return (
                <div key={p.id} className="flex flex-col items-center opacity-30 select-none animate-pulse">
                  <span className="text-3xl filter grayscale mt-2">💀</span>
                  <span className="text-[9px] font-bold text-slate-500 mt-1 uppercase">{p.name}</span>
                </div>
              );
            }
            return (
              <div 
                key={p.id} 
                className="transition-all duration-100 flex flex-col items-center relative"
                style={{ 
                  transform: stance === 'jumping' ? 'translateY(-50px)' : stance === 'ducking' ? 'scaleY(0.5)' : 'translateY(0)' 
                }}
              >
                {/* Visual Avatar frame */}
                <div className="p-1 rounded-2xl border-4 border-primary shadow-[2px_2px_0px_0px_#0f172a] bg-white">
                  {renderAvatarSvg(p.avatar, 36)}
                </div>
                <span className="text-[9px] font-black uppercase tracking-wider text-slate-300 mt-1">{p.name}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Manual buttons commands */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-black/30 p-3 rounded-b-2xl border border-white/10">
        {players.map(p => (
          <div key={p.id} className="flex flex-col gap-1 items-center bg-white/5 p-1.5 rounded-xl border border-white/5">
            <span className="text-[10px] font-sans font-black uppercase text-yellow-300 truncate max-w-[70px]">{p.name}</span>
            <div className="flex gap-2 w-full">
              <button
                onClick={() => changeStance(p.id, 'jumping')}
                disabled={durability[p.id] <= 0}
                className="flex-grow py-2 text-[10px] font-black text-white bg-sky-500 rounded-xl hover:bg-sky-600 disabled:opacity-20 border-b-4 border-sky-700 uppercase"
                id={`laser-jump-btn-${p.id}`}
              >
                ▲ JUMP
              </button>
              <button
                onClick={() => changeStance(p.id, 'ducking')}
                disabled={durability[p.id] <= 0}
                className="flex-grow py-2 text-[10px] font-black text-white bg-amber-500 rounded-xl hover:bg-amber-600 disabled:opacity-20 border-b-4 border-amber-700 uppercase"
                id={`laser-duck-btn-${p.id}`}
              >
                ▼ DUCK
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// =========================================================================
// 14. MINIGAME: SUSHI TRAIN GRAB (id: 'train')
// =========================================================================
export function SushiTrainGame({ players, onWin, onUnlock }: MinigameProps) {
  const [scores, setScores] = useState<Record<number, number>>(() => {
    const s: Record<number, number> = {};
    players.forEach(p => s[p.id] = 0);
    return s;
  });

  const [sushiX, setSushiX] = useState(0); // percentage progress of sushi on train loop (0 to 100)
  const [currentSushiColor, setCurrentSushiColor] = useState('#ffd700');
  const [grabCooldowned, setGrabCooldowned] = useState<Record<number, boolean>>({});

  useEffect(() => {
    const beltInterval = setInterval(() => {
      setSushiX(prev => {
        if (prev >= 100) {
          // Spawn new colorful sushi plate
          const randCol = players[Math.floor(Math.random() * players.length)].color;
          setCurrentSushiColor(randCol);
          return 0;
        }
        return prev + 1.5;
      });
    }, 25);

    return () => clearInterval(beltInterval);
  }, [players]);

  const grabPlate = (pId: number) => {
    if (grabCooldowned[pId]) return;

    setGrabCooldowned(curr => ({ ...curr, [pId]: true }));
    setTimeout(() => {
      setGrabCooldowned(curr => ({ ...curr, [pId]: false }));
    }, 450);

    const playerCol = players.find(p => p.id === pId)?.color;
    
    // Check if the sushi color matches my color AND matches "The Sweet Zone" (near 45% - 55% belt mark)
    const matchesColor = playerCol === currentSushiColor;
    const insideSweetZone = sushiX >= 40 && sushiX <= 60;

    if (matchesColor && insideSweetZone) {
      playBoxAudio.playSuccess();
      setScores(curr => {
        const next = { ...curr, [pId]: curr[pId] + 5 };
        if (next[pId] >= 15) {
          onUnlock('sushibomb');
          setTimeout(() => onWin(pId), 400);
        }
        return next;
      });
      // teleport sushi plate instantly to recycle next plate
      setSushiX(101);
    } else {
      playBoxAudio.playFail();
      setScores(curr => ({ ...curr, [pId]: Math.max(0, curr[pId] - 2) }));
    }
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-emerald-950/20" id="sushi-train-level">
      <div className="flex justify-around bg-black/45 py-2 px-4 rounded-xl text-xs" id="sushi-scorecard">
        {players.map(p => (
          <span key={p.id} className="font-semibold text-white">
            {p.name}: <b className="text-[#ffd700]">{scores[p.id]}/15 Points</b>
          </span>
        ))}
      </div>

      <div className="flex-grow flex flex-col justify-center items-center py-4 select-none" id="sushi-conveyor">
        <h4 className="text-[10px] font-black uppercase text-yellow-300 animate-pulse tracking-widest mb-3">CONVEYOR BELT ACTIVE</h4>
        
        {/* Horizontal Conveyor belt platform */}
        <div className="w-full max-w-lg h-16 bg-[#0f172a] rounded-3xl border-4 border-primary shadow-[6px_6px_0px_0px_rgba(15,23,42,1)] relative overflow-hidden flex items-center px-6">
          <div className="absolute inset-0 bg-stone-50/10" style={{ backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,0.05) 10px, rgba(255,255,255,0.05) 20px)' }} />

          {/* Golden sweet capture target slot */}
          <div className="absolute top-1 bottom-1 left-1/2 -translate-x-1/2 w-16 bg-gradient-to-r from-yellow-300/10 to-yellow-300/30 rounded-xl border-2 border-dashed border-yellow-400 flex items-center justify-center animate-pulse">
            <span className="text-[8px] font-bold text-yellow-300 uppercase leading-none text-center">GRAB ZONE</span>
          </div>

          {/* The Zooming Sushi plate */}
          <div 
            className="absolute w-12 h-10 rounded-xl border-3 border-primary flex items-center justify-center text-xl transition-all duration-75 p-0.5 shadow-md"
            style={{ 
              left: `${sushiX}%`, 
              transform: 'translateX(-50%)', 
              backgroundColor: currentSushiColor 
            }}
          >
            🍣
          </div>
        </div>
        <p className="text-[10px] text-stone-300 italic text-center leading-relaxed mt-2 uppercase font-bold">
          ⚡ Tap plate when it matches your plastic color AND aligns center!
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-black/30 p-3 rounded-b-2xl border border-white/10">
        {players.map(p => (
          <div key={p.id} className="flex flex-col gap-1 items-center bg-white/5 p-1.5 rounded-xl border border-white/5">
            <span className="text-[10px] uppercase font-black tracking-wide truncate max-w-[70px]" style={{ color: p.color }}>{p.name}</span>
            <button
              onClick={() => grabPlate(p.id)}
              className="w-full py-2 bg-yellow-400 text-primary hover:bg-yellow-500 font-black rounded-lg border-b-4 border-primary uppercase text-[10px] tracking-tight"
              id={`sushi-grab-btn-${p.id}`}
            >
              🍣 GRAB!
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// =========================================================================
// 15. MINIGAME: ROCKET METEOR DRIFT (id: 'space')
// =========================================================================
export function RocketDriftGame({ players, onWin, onUnlock }: MinigameProps) {
  const [rocketPositions, setRocketPositions] = useState<Record<number, number>>(() => {
    // Left/Right position of rockets (percentage: 15 to 85)
    const p: Record<number, number> = {};
    players.forEach(pl => p[pl.id] = 50);
    return p;
  });

  const [meteors, setMeteors] = useState<{ id: number; x: number; y: number; speed: number }[]>([]);

  const [lives, setLives] = useState<Record<number, number>>(() => {
    const l: Record<number, number> = {};
    players.forEach(p => l[p.id] = 3);
    return l;
  });

  // Spawn meteors dynamically
  useEffect(() => {
    const spawnTimer = setInterval(() => {
      setMeteors(curr => [
        ...curr,
        {
          id: Math.random(),
          x: Math.floor(Math.random() * 70) + 15, // center lane limits
          y: -10,
          speed: Math.random() * 2 + 1.5,
        }
      ].slice(-8)); // cap meteor items on layer
    }, 700);

    return () => clearInterval(spawnTimer);
  }, []);

  // Meteor falling and physics drift
  useEffect(() => {
    const physicsLoop = setInterval(() => {
      setMeteors(curr => {
        return curr.map(met => ({ ...met, y: met.y + met.speed })).filter(met => met.y < 105);
      });
    }, 30);

    return () => clearInterval(physicsLoop);
  }, []);

  // Hit test checks (meteors near rocket bottom level around 85%)
  useEffect(() => {
    meteors.forEach(met => {
      if (met.y >= 75 && met.y <= 90) {
        players.forEach(p => {
          if (lives[p.id] <= 0) return;
          const rocketX = rocketPositions[p.id];
          const distance = Math.abs(rocketX - met.x);

          if (distance <= 8) {
            // WHACKED Collision!
            playBoxAudio.playSplat();
            setLives(curr => {
              const nextLives = { ...curr, [p.id]: Math.max(0, curr[p.id] - 1) };
              if (nextLives[p.id] === 0) {
                // Check survivor winner directly
                const survivors = Object.entries(nextLives).filter(([id, liv]) => (liv as number) > 0);
                if (survivors.length === 1) {
                  onUnlock('survivor');
                  setTimeout(() => onWin(Number(survivors[0][0])), 400);
                } else if (survivors.length === 0) {
                  setTimeout(() => onWin(players[0].id), 400); // safety fallback
                }
              }
              return nextLives;
            });
            // recycle meteor instantly
            met.y = 106;
          }
        });
      }
    });
  }, [meteors, rocketPositions, lives, players]);

  const moveRocket = (pId: number, dir: 'L' | 'R') => {
    setRocketPositions(curr => {
      const current = curr[pId];
      const delta = dir === 'L' ? -10 : 10;
      return { ...curr, [pId]: Math.max(15, Math.min(85, current + delta)) };
    });
    playBoxAudio.playFlip();
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-sky-950/20" id="space-drift-level">
      <div className="flex justify-around bg-black/45 py-2 px-4 rounded-xl text-xs" id="space-scorecard">
        {players.map(p => (
          <span key={p.id} className="font-semibold text-white">
            {p.name}: <b className="text-yellow-300">{'⭐'.repeat(lives[p.id] || 0)}</b>
          </span>
        ))}
      </div>

      {/* Deep space coordinate space */}
      <div className="flex-grow flex items-center justify-center p-2 relative h-48 select-none" id="space-stage">
        <div className="w-full h-full border-4 border-white/20 bg-slate-950 rounded-2xl relative overflow-hidden">
          
          <span className="absolute top-2 left-1/2 -translate-x-1/2 text-[9px] font-mono bg-black/50 p-1.5 rounded text-sky-400">
            🌌 DODGE METEORS OR EXPLODE!
          </span>

          {/* Falling meteors falling from top */}
          {meteors.map(met => (
            <div 
              key={met.id} 
              className="absolute text-2xl transition-all duration-75 animate-bounce"
              style={{ left: `${met.x}%`, top: `${met.y}%`, transform: 'translateX(-50%)' }}
            >
              ☄️
            </div>
          ))}

          {/* Bouncing Player Rockets at horizontal line */}
          {players.map(p => {
            const rX = rocketPositions[p.id];
            const hp = lives[p.id];

            if (hp <= 0) return null;

            return (
              <div 
                key={p.id}
                className="absolute transition-all duration-100 flex flex-col items-center"
                style={{ left: `${rX}%`, bottom: '10px', transform: 'translateX(-50%)' }}
              >
                <div className="px-1.5 py-0.5 rounded text-[8px] font-bold text-white uppercase tracking-tighter shadow-sm mb-1 truncate max-w-[44px]" style={{ backgroundColor: p.color }}>
                  {p.name}
                </div>
                <div className="text-2xl animate-pulse">🚀</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Rocket steering commands list */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-black/30 p-3 rounded-b-2xl border border-white/10">
        {players.map(p => (
          <div key={p.id} className="flex flex-col gap-1 items-center bg-white/5 p-1.5 rounded-xl border border-white/5">
            <span className="text-[10px] font-sans font-black uppercase text-yellow-300 truncate max-w-[70px]">{p.name}</span>
            <div className="flex gap-2 w-full">
              <button
                onClick={() => moveRocket(p.id, 'L')}
                disabled={lives[p.id] <= 0}
                className="flex-grow py-2 bg-sky-500 rounded-lg text-xs font-bold hover:bg-sky-600 disabled:opacity-20 border-b-4 border-sky-700 text-white"
                id={`drift-l-btn-${p.id}`}
              >
                ◀
              </button>
              <button
                onClick={() => moveRocket(p.id, 'R')}
                disabled={lives[p.id] <= 0}
                className="flex-grow py-2 bg-sky-500 rounded-lg text-xs font-bold hover:bg-sky-600 disabled:opacity-20 border-b-4 border-sky-700 text-white"
                id={`drift-r-btn-${p.id}`}
              >
                ▶
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// =========================================================================
// 16. MINIGAME: ALIEN INVADER ZAP (id: 'zap')
// =========================================================================
export function AlienInvaderGame({ players, onWin, onUnlock }: MinigameProps) {
  const [laneAliens, setLaneAliens] = useState<Record<number, { id: number; icon: '🛸' | '🐮'; x: number; y: number }[]>>(() => {
    const initial: Record<number, any[]> = {};
    players.forEach(p => {
      initial[p.id] = [];
    });
    return initial;
  });

  const [scores, setScores] = useState<Record<number, number>>(() => {
    const s: Record<number, number> = {};
    players.forEach(p => s[p.id] = 0);
    return s;
  });

  const [lastZap, setLastZap] = useState<Record<number, string>>({});

  // Spawn UFOs/Cows per player lane! Staggered and fun!
  useEffect(() => {
    const spawner = setInterval(() => {
      setLaneAliens(curr => {
        const next = { ...curr };
        players.forEach(p => {
          const types = ['🛸', '🛸', '🐮'] as const;
          const choice = types[Math.floor(Math.random() * types.length)];
          
          if (Math.random() > 0.45) {
            next[p.id] = [
              ...next[p.id],
              {
                id: Math.random(),
                icon: choice,
                x: Math.floor(Math.random() * 55) + 20,
                y: -15, // starts offscreen high and descends
              }
            ].slice(-5);
          }
        });
        return next;
      });
    }, 650);

    return () => clearInterval(spawner);
  }, [players]);

  // Descend UFO logic step
  useEffect(() => {
    const descendLoop = setInterval(() => {
      setLaneAliens(curr => {
        const next = { ...curr };
        players.forEach(p => {
          next[p.id] = next[p.id]
            .map(al => ({ ...al, y: al.y + 2.4 }))
            .filter(al => al.y < 115); // if hits bottom, friendly cows are fine, but UFOs get past!
        });
        return next;
      });
    }, 30);

    return () => clearInterval(descendLoop);
  }, [players]);

  const zapTarget = (pId: number, id: number) => {
    let targetIcon = '';
    setLaneAliens(curr => {
      const next = { ...curr };
      const list = next[pId] || [];
      const found = list.find(al => al.id === id);
      if (found) {
        targetIcon = found.icon;
        next[pId] = list.filter(al => al.id !== id);
      }
      return next;
    });

    if (!targetIcon) return;

    if (targetIcon === '🐮') {
      playBoxAudio.playSplat();
      setScores(curr => ({ ...curr, [pId]: Math.max(0, curr[pId] - 5) }));
      setLastZap(prev => ({ ...prev, [pId]: '💥 COW HIT! -5' }));
    } else {
      playBoxAudio.playSuccess();
      setScores(curr => {
        const next = { ...curr, [pId]: curr[pId] + 5 };
        if (next[pId] >= 25) {
          onUnlock('fashion');
          setTimeout(() => onWin(pId), 400);
        }
        return next;
      });
      setLastZap(prev => ({ ...prev, [pId]: '🛸 BLASTED! +5' }));
    }

    setTimeout(() => {
      setLastZap(prev => ({ ...prev, [pId]: '' }));
    }, 900);
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-[#080d1a] rounded-3xl border-4 border-primary shadow-[6px_6px_0px_0px_#0f172a]" id="alien-invader-level">
      {/* Columns per player */}
      <div 
        className="flex-grow grid gap-4 w-full select-none" 
        style={{ gridTemplateColumns: `repeat(${players.length}, minmax(0, 1fr))` }}
        id="zap-split-grid"
      >
        {players.map(p => {
          const list = laneAliens[p.id] || [];
          const score = scores[p.id];
          const zapText = lastZap[p.id];

          return (
            <div 
              key={p.id}
              className="flex flex-col rounded-2xl border-[3px] bg-slate-950/80 overflow-hidden relative"
              style={{ borderColor: p.color }}
              id={`zap-lane-${p.id}`}
            >
              {/* Header */}
              <div 
                className="p-2 border-b-2 text-center text-xs font-black text-white flex flex-col justify-center"
                style={{ backgroundColor: `${p.color}aa`, borderColor: p.color }}
              >
                <div className="tracking-wider uppercase text-[10px]">{p.name}</div>
                <div className="text-yellow-300 font-bold text-xs">{score}/25 pts</div>
              </div>

              {/* Defense track */}
              <div className="flex-grow relative overflow-hidden bg-indigo-950/10 min-h-[225px]">
                {zapText && (
                  <div className="absolute top-8 left-1/2 -translate-x-1/2 z-10 text-[9px] font-black bg-stone-900 border border-yellow-400 text-yellow-300 rounded px-1.5 py-0.5 text-center animate-bounce uppercase">
                    {zapText}
                  </div>
                )}

                <span className="absolute bottom-1 right-2 text-[8px] opacity-40 text-white font-mono uppercase font-bold">
                  Zap Lane!
                </span>

                {list.map(al => (
                  <div
                    key={al.id}
                    onClick={() => zapTarget(p.id, al.id)}
                    className="absolute text-4xl hover:scale-110 cursor-pointer select-none transition-transform filter drop-shadow animate-pulse"
                    style={{ left: `${al.x}%`, top: `${al.y}%`, transform: 'translate(-50%, -50%)' }}
                  >
                    <div className="relative group">
                      {al.icon}
                      <span className="absolute -bottom-1 -right-1 w-2.5 h-2.5 rounded-full border border-white" style={{ backgroundColor: p.color }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <div className="text-[10px] text-zinc-400 font-bold italic text-center uppercase tracking-wider mt-3">
        🛸 Alien Invader Zap: Blast alien spaceships descending inside your field! Avoid adorable space cows!
      </div>
    </div>
  );
}

// =========================================================================
// 17. MINIGAME: CHEF BURGER STACK (id: 'burger')
// =========================================================================
export function BurgerStackGame({ players, onWin, onUnlock }: MinigameProps) {
  // Ordered sequence of sandwich: 0: Bun bottom, 1: Meat, 2: Cheese, 3: Lettuce, 4: Bun Top
  const burgerSequence = ['🍞', '🥩', '🧀', '🥬', '🍞'];

  const [scores, setScores] = useState<Record<number, number>>(() => {
    const s: Record<number, number> = {};
    players.forEach(p => s[p.id] = 0);
    return s;
  });

  const [currentBaskets, setCurrentBaskets] = useState<Record<number, string[]>>(() => {
    const cb: Record<number, string[]> = {};
    players.forEach(p => cb[p.id] = []);
    return cb;
  });

  const [fallingIngredient, setFallingIngredient] = useState('🍞');
  const [fallingX, setFallingX] = useState(50);
  const [fallingY, setFallingY] = useState(0);

  useEffect(() => {
    const physics = setInterval(() => {
      setFallingY(y => {
        if (y >= 100) {
          // Recycle ingredient
          const items = ['🍞', '🥩', '🧀', '🥬'];
          setFallingIngredient(items[Math.floor(Math.random() * items.length)]);
          setFallingX(Math.floor(Math.random() * 60) + 20);
          return 0;
        }
        return y + 2.5;
      });
    }, 25);

    return () => clearInterval(physics);
  }, []);

  const catchIngredient = (pId: number) => {
    const currentList = currentBaskets[pId] || [];
    const expectedIngredient = burgerSequence[currentList.length];

    if (fallingIngredient === expectedIngredient) {
      // CAUGHT CORRECT STEP!
      playBoxAudio.playSuccess();
      const nextList = [...currentList, fallingIngredient];
      
      if (nextList.length === 5) {
        // Complete glorious burger finished!
        setScores(curr => {
          const nextS = { ...curr, [pId]: curr[pId] + 1 };
          if (nextS[pId] >= 4) {
            onUnlock('survivor');
            setTimeout(() => onWin(pId), 400);
          }
          return nextS;
        });
        setCurrentBaskets(cb => ({ ...cb, [pId]: [] })); // reset basket
      } else {
        setCurrentBaskets(cb => ({ ...cb, [pId]: nextList }));
      }
    } else {
      // CAUGHT INCONGRUOUS ingredient penalty
      playBoxAudio.playFail();
      setCurrentBaskets(cb => ({ ...cb, [pId]: [] })); // crash stack!
    }

    // recycle falling ingredient instantly
    setFallingY(101);
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-orange-950/20" id="burger-stack-level">
      <div className="flex justify-around bg-black/45 py-2 px-4 rounded-xl text-xs" id="burger-scorecard">
        {players.map(p => (
          <span key={p.id} className="font-semibold text-white">
            {p.name}: <b className="text-yellow-300">{scores[p.id]}/4 Burgers</b>
          </span>
        ))}
      </div>

      {/* Physics sandwich board */}
      <div className="flex-grow flex items-center justify-center p-2 relative h-48 select-none" id="burger-stage">
        <div className="w-full h-full border-4 border-white/20 bg-stone-900 rounded-2xl relative overflow-hidden">
          
          <span className="absolute top-2 left-1/2 -translate-x-1/2 text-[9px] font-mono tracking-widest text-[#60a5fa] bg-black/60 p-1.5 rounded">
            🍔 GET BURGERS IN ORDER: BUN ➔ MEAT ➔ CHEESE ➔ VEGGIE ➔ TOP BUN!
          </span>

          {/* Falling stack ingredient */}
          <div 
            className="absolute text-4xl animate-bounce"
            style={{ left: `${fallingX}%`, top: `${fallingY}%`, transform: 'translateX(-50%)' }}
          >
            {fallingIngredient}
          </div>

          {/* Kitchen plates basket stacks */}
          <div className="absolute bottom-2 left-0 right-0 flex justify-around items-end">
            {players.map(p => {
              const basket = currentBaskets[p.id] || [];
              return (
                <div key={p.id} className="flex flex-col items-center gap-1 bg-white/5 px-2 py-1 rounded-xl border border-white/10">
                  <span className="text-[8px] font-semibold text-white truncate max-w-[40px]">{p.name}</span>
                  <div className="flex flex-col-reverse -space-y-1.5">
                    {basket.length === 0 ? (
                      <span className="text-sm">🍽️</span>
                    ) : (
                      basket.map((ing, i) => (
                        <span key={i} className="text-xl">{ing}</span>
                      ))
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Manual buttons inputs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-black/30 p-3 rounded-b-2xl border border-white/10">
        {players.map(p => (
          <div key={p.id} className="flex flex-col gap-1 items-center bg-white/5 p-1 rounded-xl">
            <span className="text-[10px] uppercase font-bold text-yellow-300 leading-none truncate max-w-[65px] mb-1">{p.name}</span>
            <button
              onClick={() => catchIngredient(p.id)}
              className="w-full py-2 bg-yellow-400 hover:bg-yellow-500 font-black rounded-lg border-b-4 border-primary uppercase text-[10px] text-primary"
              id={`burger-grab-btn-${p.id}`}
            >
              ✋ GRAB INF
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// =========================================================================
// 18. MINIGAME: BALLOON POP RUSH (id: 'pop')
// =========================================================================
export function BalloonPopGame({ players, onWin, onUnlock }: MinigameProps) {
  const [inflation, setInflation] = useState<Record<number, number>>(() => {
    // Progress of balloon size (0 to 100 percentage)
    const i: Record<number, number> = {};
    players.forEach(p => i[p.id] = 15);
    return i;
  });

  const pumpBalloon = (pId: number) => {
    playBoxAudio.playJump();
    setInflation(curr => {
      const next = { ...curr };
      next[pId] = Math.min(next[pId] + 3, 100);

      if (next[pId] >= 100) {
        // BALLOON BURST POP! Perfect win!
        playBoxAudio.playExplosion();
        onUnlock('survivor');
        setTimeout(() => onWin(pId), 400);
      }
      return next;
    });
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-purple-950/20" id="balloon-pop-level">
      <div className="flex justify-around bg-black/45 py-2 px-4 rounded-xl text-xs" id="pop-scorecard">
        {players.map(p => (
          <span key={p.id} className="font-semibold text-white">
            {p.name}: <b className="text-yellow-300">{inflation[p.id] || 0}%</b>
          </span>
        ))}
      </div>

      {/* Flapping inflation stages side-by-side */}
      <div className="flex-grow grid grid-cols-2 md:grid-cols-4 gap-4 p-2 items-end max-w-2xl mx-auto w-full" id="balloon-stage">
        {players.map(p => {
          const inf = inflation[p.id] || 15;
          return (
            <div key={p.id} className="h-full flex flex-col justify-between items-center bg-black/30 rounded-2xl p-3 border border-white/15 relative overflow-hidden">
              <span className="text-[10px] font-black uppercase" style={{ color: p.color }}>{p.name}</span>
              
              {/* Balloon vector stretch */}
              <div className="flex-grow flex items-center justify-center relative w-full h-16">
                <div 
                  className="rounded-full transition-all duration-75 relative flex items-center justify-center shadow-lg border-4 border-primary"
                  style={{ 
                    width: `${inf * 0.8 + 24}px`, 
                    height: `${inf * 0.8 + 24}px`, 
                    backgroundColor: p.color 
                  }}
                >
                  <span className="text-xs uppercase font-black text-white px-1 truncate max-w-[50px]">{p.avatar.eyeType === 'happy' ? '😊' : '🤪'}</span>
                  {/* Balloon knot line */}
                  <div className="absolute bottom-[-10px] w-2.5 h-3 bg-primary rounded-b" />
                </div>
              </div>

              {/* Pump Button */}
              <button
                onClick={() => pumpBalloon(p.id)}
                className="w-full py-2 bg-yellow-400 text-primary font-black uppercase border-b-4 border-primary hover:bg-yellow-500 rounded-xl text-[10px]"
                id={`balloon-pump-btn-${p.id}`}
              >
                🎈 PUMP!
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// =========================================================================
// 19. MINIGAME: FRUIT SLASHER (id: 'slash')
// =========================================================================
export function FruitSlashGame({ players, onWin, onUnlock }: MinigameProps) {
  // We keep a separate list of active fruits for each player lane
  const [laneFruits, setLaneFruits] = useState<Record<number, { id: number; icon: string; x: number; y: number; val: number }[]>>(() => {
    const initial: Record<number, any[]> = {};
    players.forEach(p => {
      initial[p.id] = [];
    });
    return initial;
  });

  const [scores, setScores] = useState<Record<number, number>>(() => {
    const s: Record<number, number> = {};
    players.forEach(p => s[p.id] = 0);
    return s;
  });

  const [animations, setAnimations] = useState<Record<number, string>>({}); // play specific slice animations

  // Independent spawner per player!
  useEffect(() => {
    const spawner = setInterval(() => {
      setLaneFruits(curr => {
        const next = { ...curr };
        players.forEach(p => {
          const designs = [
            { icon: '🍉', val: 5 },
            { icon: '🍍', val: 4 },
            { icon: '🍌', val: 2 },
            { icon: '🍎', val: 1 },
            { icon: '💣', val: -5 }
          ];
          const match = designs[Math.floor(Math.random() * designs.length)];
          
          if (Math.random() > 0.3) {
            next[p.id] = [
              ...next[p.id],
              {
                id: Math.random(),
                icon: match.icon,
                x: Math.floor(Math.random() * 60) + 20, // keep centered in lane
                y: 110, // start below lane
                val: match.val,
              }
            ].slice(-5);
          }
        });
        return next;
      });
    }, 600);

    return () => clearInterval(spawner);
  }, [players]);

  // Float logic step loop
  useEffect(() => {
    const floatLoop = setInterval(() => {
      setLaneFruits(curr => {
        const next = { ...curr };
        players.forEach(p => {
          next[p.id] = next[p.id]
            .map(f => ({ ...f, y: f.y - 2.5 }))
            .filter(f => f.y > -15);
        });
        return next;
      });
    }, 30);

    return () => clearInterval(floatLoop);
  }, [players]);

  const sliceFruit = (pId: number, fruitId: number) => {
    const list = laneFruits[pId] || [];
    const target = list.find(f => f.id === fruitId);
    if (!target) return;

    const targetIcon = target.icon;
    const targetVal = target.val;

    // Remove item from active fruits state
    setLaneFruits(curr => ({
      ...curr,
      [pId]: (curr[pId] || []).filter(f => f.id !== fruitId)
    }));

    if (targetIcon === '💣') {
      playBoxAudio.playExplosion();
      setScores(curr => ({ ...curr, [pId]: Math.max(0, curr[pId] - 5) }));
      setAnimations(prev => ({ ...prev, [pId]: '💥 DETONATION! -5' }));
    } else {
      playBoxAudio.playSlap();
      setScores(curr => {
        const next = { ...curr, [pId]: curr[pId] + targetVal };
        if (next[pId] >= 25) {
          onUnlock('sushibomb');
          setTimeout(() => onWin(pId), 400);
        }
        return next;
      });
      setAnimations(prev => ({ ...prev, [pId]: `CHOP ${targetIcon}! +${targetVal}` }));
    }

    setTimeout(() => {
      setAnimations(prev => ({ ...prev, [pId]: '' }));
    }, 850);
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-[#0d1611] rounded-3xl border-4 border-primary shadow-[6px_6px_0px_0px_#0f172a]" id="fruit-slash-level">
      {/* Dynamic split arena panels */}
      <div 
        className="flex-grow grid gap-4 w-full select-none" 
        style={{ gridTemplateColumns: `repeat(${players.length}, minmax(0, 1fr))` }}
        id="slash-split-grid"
      >
        {players.map(p => {
          const list = laneFruits[p.id] || [];
          const score = scores[p.id];
          const anim = animations[p.id];

          return (
            <div 
              key={p.id}
              className="flex-col rounded-2xl border-[3px] border-primary bg-slate-900/60 overflow-hidden relative flex"
              style={{ borderColor: p.color }}
              id={`slash-lane-${p.id}`}
            >
              {/* Lane Header */}
              <div 
                className="p-2 border-b-2 text-center text-xs font-black text-white flex flex-col gap-0.5 justify-center"
                style={{ backgroundColor: `${p.color}aa`, borderColor: p.color }}
              >
                <div className="tracking-wider uppercase text-[10px]">{p.name}</div>
                <div className="text-yellow-300 font-bold text-xs">{score}/25 pts</div>
              </div>

              {/* Lane Stage */}
              <div className="flex-grow relative overflow-hidden bg-emerald-950/10 min-h-[220px]">
                {anim && (
                  <div className="absolute top-8 left-1/2 -translate-x-1/2 z-10 text-[9px] font-black bg-stone-900 text-yellow-300 border border-yellow-300 rounded px-1.5 py-0.5 text-center animate-bounce uppercase overflow-visible whitespace-nowrap">
                    {anim}
                  </div>
                )}

                <span className="absolute bottom-1 right-2 text-[8px] opacity-40 text-white font-mono uppercase font-bold">
                  Tap Lane/Fruit!
                </span>

                {list.map(f => (
                  <div
                    key={f.id}
                    onClick={() => sliceFruit(p.id, f.id)}
                    className="absolute text-4xl hover:scale-110 cursor-pointer select-none transition-transform filter drop-shadow animate-pulse"
                    style={{ left: `${f.x}%`, top: `${f.y}%`, transform: 'translate(-50%, -50%)' }}
                  >
                    <div className="relative group">
                      {f.icon}
                      <span className="absolute -bottom-1 -right-1 w-2.5 h-2.5 rounded-full border border-white" style={{ backgroundColor: p.color }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <div className="text-[10px] text-zinc-400 font-bold italic text-center uppercase tracking-wider mt-3">
        🍎 Mega Fruit Chop: Slash items descending inside your OWN colored lane to beat competitors!
      </div>
    </div>
  );
}

// =========================================================================
// 20. MINIGAME: SIMON SAYS GLOW (id: 'simon')
// =========================================================================
export function SimonGlowGame({ players, onWin, onUnlock }: MinigameProps) {
  const [colorsList] = useState(['#ef4444', '#3b82f6', '#10b981', '#f59e0b']); // Red, Blue, Green, Yellow targets
  const [sequence, setSequence] = useState<number[]>([]);
  const [currentPlayIdx, setCurrentPlayIdx] = useState(0);
  const [playerInputs, setPlayerInputs] = useState<Record<number, number[]>>(() => {
    const i: Record<number, number[]> = {};
    players.forEach(p => i[p.id] = []);
    return i;
  });

  const [scores, setScores] = useState<Record<number, number>>(() => {
    const s: Record<number, number> = {};
    players.forEach(p => s[p.id] = 0);
    return s;
  });

  const [activeInstruction, setActiveInstruction] = useState('WATCH CLOSELY!');
  const [glowingLight, setGlowingLight] = useState<number | null>(null);

  const triggerStepList = (seqIdx: number[], step: number) => {
    if (step >= seqIdx.length) {
      setGlowingLight(null);
      setActiveInstruction('REPEAT SEQS!');
      return;
    }

    setGlowingLight(seqIdx[step]);
    playBoxAudio.playJump();

    setTimeout(() => {
      setGlowingLight(null);
      setTimeout(() => {
        triggerStepList(seqIdx, step + 1);
      }, 250);
    }, 450);
  };

  const startNextSequence = () => {
    setActiveInstruction('WATCH CLOSELY!');
    const nextItem = Math.floor(Math.random() * 4);
    const nextSeq = [...sequence, nextItem];
    setSequence(nextSeq);

    // Reset players inputs
    const freshIn: Record<number, number[]> = {};
    players.forEach(p => freshIn[p.id] = []);
    setPlayerInputs(freshIn);

    setTimeout(() => {
      triggerStepList(nextSeq, 0);
    }, 850);
  };

  // Run start round on startup
  useEffect(() => {
    startNextSequence();
  }, []);

  const pressJelly = (pId: number, colorIdx: number) => {
    if (activeInstruction !== 'REPEAT SEQS!') return;

    playBoxAudio.playFlip();
    const currIn = playerInputs[pId] || [];
    const nextIn = [...currIn, colorIdx];
    setPlayerInputs(curr => ({ ...curr, [pId]: nextIn }));

    // Verify input matching
    const lastExpectedIdx = currIn.length;
    if (colorIdx !== sequence[lastExpectedIdx]) {
      // FAULT SEQUENCE Crashed!
      playBoxAudio.playFail();
      setActiveInstruction('FAILED! REWINDING...');
      setTimeout(() => {
        startNextSequence();
      }, 1200);
      return;
    }

    if (nextIn.length === sequence.length) {
      // PERFECT ROUND ROUND ROUND!
      playBoxAudio.playSuccess();
      setScores(curr => {
        const next = { ...curr, [pId]: curr[pId] + 5 };
        if (next[pId] >= 15) {
          onUnlock('memory_master');
          setTimeout(() => onWin(pId), 400);
        }
        return next;
      });

      setActiveInstruction('SPLENDID MATCH! EXPANDING...');
      setTimeout(() => {
        startNextSequence();
      }, 1200);
    }
  };

  return (
    <div className="flex-grow flex flex-col justify-between w-full h-full p-4 bg-amber-950/20" id="simon-Says-level">
      <div className="flex justify-around bg-black/45 py-2 px-4 rounded-xl text-xs" id="simon-scorecard">
        {players.map(p => (
          <span key={p.id} className="font-semibold text-white">
            {p.name}: <b className="text-yellow-300">{scores[p.id]}/15 Points</b>
          </span>
        ))}
      </div>

      <div className="flex-grow flex flex-col justify-center items-center py-4 select-none" id="simon-says-stage">
        <h3 className="bg-[#0f172a] text-yellow-300 font-black text-xs px-3 py-1.5 rounded-xl border-3 border-primary animate-pulse tracking-widest mb-4">
          {activeInstruction}
        </h3>

        {/* Circular panel loop */}
        <div className="grid grid-cols-2 gap-3 w-40 h-40">
          {colorsList.map((col, idx) => (
            <div 
              key={idx}
              className="rounded-2xl border-4 border-primary transition-all duration-150 relative cursor-pointer active:scale-95 shadow-md"
              style={{ 
                backgroundColor: glowingLight === idx ? col : `${col}40`,
                borderColor: glowingLight === idx ? '#ffffff' : '#0f172a',
                boxShadow: glowingLight === idx ? '0 0 15px currentColor' : 'none'
              }}
              title={`Glow ${idx + 1}`}
            />
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-black/30 p-3 rounded-b-2xl border border-white/10">
        {players.map(p => (
          <div key={p.id} className="flex flex-col gap-1 items-center bg-white/5 p-1 rounded-xl">
            <span className="text-[10px] uppercase font-bold text-yellow-300 mr-2 truncate max-w-[65px]">{p.name}</span>
            <div className="grid grid-cols-4 gap-1 w-full">
              {colorsList.map((col, cIdx) => (
                <button
                  key={cIdx}
                  onClick={() => pressJelly(p.id, cIdx)}
                  disabled={activeInstruction !== 'REPEAT SEQS!'}
                  className="h-8 rounded-lg border-2 border-primary transition-transform active:scale-95 disabled:opacity-40"
                  style={{ backgroundColor: col }}
                  title={`Color jelly select ${cIdx}`}
                  id={`simon-color-${p.id}-${cIdx}`}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
