/**
 * Types & Interfaces for PlayBox Game
 */

export interface Player {
  id: number;
  name: string;
  color: string; // Tailwind class color or Hex code
  score: number;
  coins: number;
  avatar: {
    faceColor: string;
    eyeType: 'happy' | 'wacky' | 'sunglasses' | 'angry' | 'dizzy';
    mouthType: 'smile' | 'gasp' | 'silly' | 'mustache' | 'grump';
    accessory: 'none' | 'crown' | 'party' | 'chef' | 'horns' | 'halo' | 'ninja';
  };
}

export type FpsCap = 30 | 60 | 120 | 'unlimited';
export type ResolutionScale = 'low' | 'medium' | 'high';
export type GameDifficulty = 'easy' | 'medium' | 'hard';

export interface GameSettings {
  fpsCap: FpsCap;
  resolutionScale: ResolutionScale;
  soundEnabled: boolean;
  scoreLimit: number; // e.g., first to 3 points in a tournament wins!
  difficulty: GameDifficulty;
}

export interface Minigame {
  id: string;
  name: string;
  emoji: string;
  desc: string;
  color: string; // theme color
  bgColor: string;
}

export interface Award {
  id: string;
  title: string;
  desc: string;
  icon: string;
  unlocked: boolean;
  condition: string;
}

export interface StoreItem {
  id: string;
  name: string;
  cost: number;
  type: 'accessory' | 'eye' | 'mouth' | 'color';
  value: string;
  emoji: string;
  unlocked: boolean;
}
