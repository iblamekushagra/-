import React, { useState, useEffect, useRef } from 'react';
import { Player, Minigame, GameSettings } from './types';
import playBoxAudio from './utils/audio';
import PlayBoxHome from './components/PlayBoxHome';
import PlayBoxStore from './components/PlayBoxStore';
import PlayBoxAwards from './components/PlayBoxAwards';
import SettingsPanel from './components/SettingsPanel';
import GameScreen from './components/GameScreen';

// Initialize 4 wacky, adorable default starting players
const DEFAULT_PLAYERS: Player[] = [
  {
    id: 1,
    name: 'Bluey',
    color: '#00658d',
    score: 0,
    coins: 10, // give some initial starting coins to play with!
    avatar: {
      faceColor: '#00658d',
      eyeType: 'happy',
      mouthType: 'smile',
      accessory: 'party',
    },
  },
  {
    id: 2,
    name: 'Orangey',
    color: '#a04100',
    score: 0,
    coins: 10,
    avatar: {
      faceColor: '#a04100',
      eyeType: 'wacky',
      mouthType: 'silly',
      accessory: 'horns',
    },
  },
  {
    id: 3,
    name: 'Limey',
    color: '#16a34a',
    score: 0,
    coins: 10,
    avatar: {
      faceColor: '#16a34a',
      eyeType: 'angry',
      mouthType: 'gasp',
      accessory: 'halo',
    },
  },
  {
    id: 4,
    name: 'Pinky',
    color: '#db2777',
    score: 0,
    coins: 10,
    avatar: {
      faceColor: '#db2777',
      eyeType: 'dizzy',
      mouthType: 'grump',
      accessory: 'none',
    },
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'play' | 'store' | 'awards'>('play');
  const [players, setPlayers] = useState<Player[]>(() => {
    const saved = localStorage.getItem('playbox_players');
    return saved ? JSON.parse(saved) : DEFAULT_PLAYERS;
  });

  const [selectedCount, setSelectedCount] = useState<number>(2); // Default to 2 players as seen on reference image!
  const [unlockedAccessories, setUnlockedAccessories] = useState<string[]>(['none', 'party', 'horns']);
  const [unlockedAwards, setUnlockedAwards] = useState<string[]>([]);
  const [showSettings, setShowSettings] = useState(false);
  const [soundMuted, setSoundMuted] = useState(false);

  // Settings state
  const [settings, setSettings] = useState<GameSettings>({
    fpsCap: 'unlimited',
    resolutionScale: 'medium',
    soundEnabled: true,
    scoreLimit: 3,
    difficulty: 'medium',
  });

  // Selected minigame state
  const [activeGame, setActiveGame] = useState<Minigame | null>(null);
  const scrollPosRef = useRef(0);

  // Sync state to localStorage to keep data persistent
  useEffect(() => {
    localStorage.setItem('playbox_players', JSON.stringify(players));
  }, [players]);

  // Dynamically control Home/Lobby background music
  useEffect(() => {
    if (settings.soundEnabled && !activeGame) {
      playBoxAudio.startBGM('home');
    } else {
      if (!activeGame) {
        playBoxAudio.stopBGM();
      }
    }
    return () => {
      if (!activeGame) {
        playBoxAudio.stopBGM();
      }
    };
  }, [activeGame, settings.soundEnabled, activeTab]);

  // Handle global key sound bindings
  const handleToggleSound = () => {
    const isMuted = playBoxAudio.toggleMute();
    setSoundMuted(isMuted);
    setSettings(prev => ({ ...prev, soundEnabled: !isMuted }));
  };

  const handleUnlockAccessory = (acc: string, cost: number) => {
    // Deduct cost and unlock accessory
    setPlayers(prev => prev.map(p => ({ ...p, coins: Math.max(0, p.coins - cost) })));
    setUnlockedAccessories(prev => {
      const next = [...prev, acc];
      localStorage.setItem('playbox_unlocked_accessories', JSON.stringify(next));
      return next;
    });
    // Trigger fashion achievement!
    handleUnlockAward('fashion');
  };

  const handleUnlockAward = (awardId: string) => {
    setUnlockedAwards(prev => {
      if (prev.includes(awardId)) return prev;
      const next = [...prev, awardId];
      localStorage.setItem('playbox_unlocked_awards', JSON.stringify(next));
      return next;
    });
    playBoxAudio.playSuccess();
  };

  const handleGameOver = (winnerId: number, coinsEarned: number) => {
    // Distribute winner coins
    setPlayers(prev => prev.map(p => {
      if (p.id === winnerId) {
        return { ...p, score: p.score + 1, coins: p.coins + coinsEarned };
      }
      return p;
    }));
    handleUnlockAward('milestone_match');
  };

  return (
    <div className="bg-background text-on-background min-h-screen pb-[100px] flex flex-col font-sans overflow-x-hidden" id="playbox-app-root">
      
      {/* TopAppBar - Sticky Header styled with rich premium Bento look */}
      <header className="sticky top-4 z-40 mx-auto w-full max-w-4xl px-4 mt-4">
        <div className="flex justify-between items-center bg-white border-4 md:border-[6px] border-primary rounded-3xl p-4 md:p-5 shadow-[8px_8px_0px_0px_rgba(15,23,42,1)]" id="bento-header">
          {/* Mute toggle option */}
          <button 
            onClick={handleToggleSound}
            className="text-primary hover:scale-105 transition-all duration-100 flex items-center justify-center w-12 h-12 rounded-2xl bg-white border-4 border-primary hover:bg-slate-100 shadow-[4px_4px_0px_0px_rgba(15,23,42,1)] active:translate-x-[2px] active:translate-y-[2px] active:shadow-[2px_2px_0px_0px_rgba(15,23,42,1)]"
            title={soundMuted ? 'Unmute PlayBox' : 'Mute PlayBox'}
            id="global-mute-btn"
          >
            <span className="material-symbols-outlined text-[28px]" style={{ fontVariationSettings: "'FILL' 1" }}>
              {soundMuted ? 'volume_off' : 'volume_up'}
            </span>
          </button>

          {/* Central Logo */}
          <h1 
            onClick={() => setActiveGame(null)} 
            className="font-black text-3xl md:text-5xl tracking-tighter italic uppercase text-primary flex items-center gap-2.5 cursor-pointer leading-none select-none hover:opacity-95"
            id="playbox-main-logo"
          >
            <div className="bg-pink-400 p-1.5 md:p-2 rounded-2xl border-4 border-primary shadow-[2px_2px_0px_0px_rgba(15,23,42,1)]">
              <span className="text-xl md:text-2xl">🌀</span>
            </div>
            PlayBox!
          </h1>

          {/* Settings triggering button */}
          <button 
            onClick={() => setShowSettings(true)}
            className="text-primary hover:scale-105 transition-all duration-100 flex items-center justify-center w-12 h-12 rounded-2xl bg-white border-4 border-primary hover:bg-slate-100 shadow-[4px_4px_0px_0px_rgba(15,23,42,1)] active:translate-x-[2px] active:translate-y-[2px] active:shadow-[2px_2px_0px_0px_rgba(15,23,42,1)]"
            title="Options panel"
            id="global-settings-btn"
          >
            <span className="material-symbols-outlined text-[28px]" style={{ fontVariationSettings: "'FILL' 1" }}>
              settings
            </span>
          </button>
        </div>
      </header>

      {/* Main Container Stage Body */}
      <main className="flex-grow flex flex-col items-center px-4 py-6 gap-6 max-w-4xl mx-auto w-full">
        
        {activeGame ? (
          /* Locked in Arena Game Mode */
          <GameScreen
            players={players.slice(0, selectedCount)}
            settings={settings}
            activeGame={activeGame}
            onExit={() => {
              setActiveGame(null);
              playBoxAudio.playWhistle();
              setTimeout(() => {
                window.scrollTo({ top: scrollPosRef.current, behavior: 'auto' });
              }, 40);
            }}
            onGameOver={handleGameOver}
            onUnlockMilestone={handleUnlockAward}
          />
        ) : (
          /* General Dashboard navigation view tabs */
          <>
            {activeTab === 'play' && (
              <PlayBoxHome
                players={players}
                onUpdatePlayers={setPlayers}
                selectedCount={selectedCount}
                onSelectCount={setSelectedCount}
                onLaunchGame={(game) => {
                  scrollPosRef.current = window.scrollY;
                  setActiveGame(game);
                }}
                onOpenSettings={() => setShowSettings(true)}
                unlockedAccessories={unlockedAccessories}
                activeBgm={settings.soundEnabled}
                onToggleBgm={handleToggleSound}
              />
            )}

            {activeTab === 'store' && (
              <PlayBoxStore
                coins={players[0]?.coins || 0}
                onUnlockAccessory={handleUnlockAccessory}
                unlockedList={unlockedAccessories}
              />
            )}

            {activeTab === 'awards' && (
              <PlayBoxAwards unlockedAwards={unlockedAwards} />
            )}
          </>
        )}
      </main>

      {/* Settings Dialog Overlay popup */}
      {showSettings && (
        <SettingsPanel
          settings={settings}
          onUpdate={(s) => {
            setSettings(s);
            setSoundMuted(!s.soundEnabled);
            playBoxAudio.setMute(!s.soundEnabled);
          }}
          onClose={() => setShowSettings(false)}
        />
      )}

      {/* Offline Console Bottom Navigation - Locked out when actively in minigame */}
      {!activeGame && (
        <>
          {/* Mobile Navigation bar */}
          <nav className="fixed bottom-0 left-0 w-full z-40 flex justify-around items-center px-4 pb-2 pt-1 h-[78px] bg-white border-t-4 border-primary shadow-[0_-6px_0px_0px_rgba(15,23,42,1)] rounded-t-3xl md:hidden" id="mobile-nav">
            {/* Play Button */}
            <button 
              onClick={() => {
                setActiveTab('play');
                playBoxAudio.playFlip();
              }}
              className={`flex flex-col items-center justify-center rounded-2xl px-5 py-1.5 transition-all duration-75 border-[3px] border-primary ${
                activeTab === 'play' 
                  ? 'bg-yellow-400 text-primary shadow-[3px_3px_0px_0px_rgba(15,23,42,1)] font-black translate-y-[-2px]' 
                  : 'bg-stone-50 text-stone-500 hover:bg-stone-100'
              }`}
              id="mobile-nav-play"
            >
              <span className="material-symbols-outlined text-[24px]" style={{ fontVariationSettings: activeTab === 'play' ? "'FILL' 1" : "'FILL' 0" }}>sports_esports</span>
              <span className="text-[10px] font-sans mt-0.5 uppercase tracking-tight font-black">Play</span>
            </button>

            {/* Store Button */}
            <button 
              onClick={() => {
                setActiveTab('store');
                playBoxAudio.playFlip();
              }}
              className={`flex flex-col items-center justify-center rounded-2xl px-5 py-1.5 transition-all duration-75 border-[3px] border-primary ${
                activeTab === 'store' 
                  ? 'bg-yellow-400 text-primary shadow-[3px_3px_0px_0px_rgba(15,23,42,1)] font-black translate-y-[-2px]' 
                  : 'bg-stone-50 text-stone-500 hover:bg-stone-100'
              }`}
              id="mobile-nav-store"
            >
              <span className="material-symbols-outlined text-[24px]" style={{ fontVariationSettings: activeTab === 'store' ? "'FILL' 1" : "'FILL' 0" }}>local_mall</span>
              <span className="text-[10px] font-sans mt-0.5 uppercase tracking-tight font-black">Store</span>
            </button>

            {/* Awards Button */}
            <button 
              onClick={() => {
                setActiveTab('awards');
                playBoxAudio.playFlip();
              }}
              className={`flex flex-col items-center justify-center rounded-2xl px-5 py-1.5 transition-all duration-75 border-[3px] border-primary ${
                activeTab === 'awards' 
                  ? 'bg-yellow-400 text-primary shadow-[3px_3px_0px_0px_rgba(15,23,42,1)] font-black translate-y-[-2px]' 
                  : 'bg-stone-50 text-stone-500 hover:bg-stone-100'
              }`}
              id="mobile-nav-awards"
            >
              <span className="material-symbols-outlined text-[24px]" style={{ fontVariationSettings: activeTab === 'awards' ? "'FILL' 1" : "'FILL' 0" }}>emoji_events</span>
              <span className="text-[10px] font-sans mt-0.5 uppercase tracking-tight font-black">Awards</span>
            </button>
          </nav>

          {/* Desktop Right Panel navigation bar */}
          <nav className="hidden md:flex fixed top-1/2 -translate-y-1/2 right-6 flex-col gap-5 bg-white p-4 rounded-3xl shadow-[8px_8px_0px_0px_rgba(15,23,42,1)] border-[4px] border-primary z-40" id="desktop-nav">
            <button 
              onClick={() => {
                setActiveTab('play');
                playBoxAudio.playFlip();
              }}
              className={`flex flex-col items-center justify-center w-14 h-14 rounded-2xl transition-all duration-100 border-4 border-primary ${
                activeTab === 'play' 
                  ? 'bg-yellow-400 text-primary shadow-[4px_4px_0px_0px_rgba(15,23,42,1)] translate-y-[-2px]' 
                  : 'bg-stone-50 hover:bg-stone-100 hover:translate-y-[-1px]'
              }`}
              title="Play compiling arena"
              id="desktop-nav-play"
            >
              <span className="material-symbols-outlined text-[28px]" style={{ fontVariationSettings: "'FILL' 1" }}>sports_esports</span>
            </button>

            <button 
              onClick={() => {
                setActiveTab('store');
                playBoxAudio.playFlip();
              }}
              className={`flex flex-col items-center justify-center w-14 h-14 rounded-2xl transition-all duration-100 border-4 border-primary ${
                activeTab === 'store' 
                  ? 'bg-yellow-400 text-primary shadow-[4px_4px_0px_0px_rgba(15,23,42,1)] translate-y-[-2px]' 
                  : 'bg-stone-50 hover:bg-stone-100 hover:translate-y-[-1px]'
              }`}
              title="Unlock premium toppings"
              id="desktop-nav-store"
            >
              <span className="material-symbols-outlined text-[28px]" style={{ fontVariationSettings: "'FILL' 1" }}>local_mall</span>
            </button>

            <button 
              onClick={() => {
                setActiveTab('awards');
                playBoxAudio.playFlip();
              }}
              className={`flex flex-col items-center justify-center w-14 h-14 rounded-2xl transition-all duration-100 border-4 border-primary ${
                activeTab === 'awards' 
                  ? 'bg-yellow-400 text-primary shadow-[4px_4px_0px_0px_rgba(15,23,42,1)] translate-y-[-2px]' 
                  : 'bg-stone-50 hover:bg-stone-100 hover:translate-y-[-1px]'
              }`}
              title="Bragging milestones hall of fame"
              id="desktop-nav-awards"
            >
              <span className="material-symbols-outlined text-[28px]" style={{ fontVariationSettings: "'FILL' 1" }}>emoji_events</span>
            </button>
          </nav>
        </>
      )}
    </div>
  );
}
